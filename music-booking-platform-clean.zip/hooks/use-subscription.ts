"use client"

import { useState, useEffect } from "react"
import { useAuth } from "@/contexts/auth-context"
import { checkFeatureAccess } from "@/app/actions/stripe-actions"

export function useSubscription() {
  const { profile } = useAuth()
  const [isLoading, setIsLoading] = useState(true)
  const [subscriptionData, setSubscriptionData] = useState<{
    status: string
    plan: string
    periodEnd: string | null
  }>({
    status: "free",
    plan: "free",
    periodEnd: null,
  })

  useEffect(() => {
    if (profile) {
      setSubscriptionData({
        status: profile.subscription_status || "free",
        plan: profile.subscription_plan || "free",
        periodEnd: profile.subscription_period_end || null,
      })
      setIsLoading(false)
    }
  }, [profile])

  const checkAccess = async (featureKey: string) => {
    try {
      const result = await checkFeatureAccess(featureKey)
      return result
    } catch (error) {
      console.error("Error checking feature access:", error)
      return { hasAccess: false, reason: "Error checking access" }
    }
  }

  return {
    isLoading,
    subscription: subscriptionData,
    checkAccess,
    isSubscribed: subscriptionData.status === "active",
    isPro: subscriptionData.plan === "pro" && subscriptionData.status === "active",
    isBusiness: subscriptionData.plan === "business" && subscriptionData.status === "active",
  }
}
