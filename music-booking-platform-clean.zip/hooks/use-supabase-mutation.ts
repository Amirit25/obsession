"use client"

import { useState, useCallback } from "react"
import { useSupabase } from "@/contexts/supabase-context"
import type { PostgrestError } from "@supabase/supabase-js"

type MutationOptions = {
  table: string
  onSuccess?: (data: any) => void
  onError?: (error: PostgrestError) => void
}

type MutationResult<T> = {
  insert: (data: T | T[]) => Promise<{ data: any; error: PostgrestError | null }>
  update: (
    data: Partial<T>,
    match: { column: string; value: any },
  ) => Promise<{ data: any; error: PostgrestError | null }>
  upsert: (data: T | T[]) => Promise<{ data: any; error: PostgrestError | null }>
  remove: (match: { column: string; value: any }) => Promise<{ data: any; error: PostgrestError | null }>
  isLoading: boolean
  error: PostgrestError | null
}

export function useSupabaseMutation<T = any>(options: MutationOptions): MutationResult<T> {
  const { supabase, isReady } = useSupabase()
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<PostgrestError | null>(null)

  const createErrorObject = (message: string): PostgrestError => {
    return { message, details: "", hint: "", code: "" }
  }

  const insert = useCallback(
    async (data: T | T[]) => {
      if (!supabase || !isReady) {
        return { data: null, error: createErrorObject("Supabase client not ready") }
      }

      try {
        setIsLoading(true)
        setError(null)

        const { data: result, error: insertError } = await supabase.from(options.table).insert(data).select()

        if (insertError) {
          setError(insertError)
          options.onError?.(insertError)
          return { data: null, error: insertError }
        }

        options.onSuccess?.(result)
        return { data: result, error: null }
      } catch (err: any) {
        console.error("Error in insert mutation:", err)
        const errorObj = createErrorObject(err.message || "Unknown error")
        setError(errorObj)
        options.onError?.(errorObj)
        return { data: null, error: errorObj }
      } finally {
        setIsLoading(false)
      }
    },
    [supabase, isReady, options],
  )

  const update = useCallback(
    async (data: Partial<T>, match: { column: string; value: any }) => {
      if (!supabase || !isReady) {
        return { data: null, error: createErrorObject("Supabase client not ready") }
      }

      try {
        setIsLoading(true)
        setError(null)

        const { data: result, error: updateError } = await supabase
          .from(options.table)
          .update(data)
          .eq(match.column, match.value)
          .select()

        if (updateError) {
          setError(updateError)
          options.onError?.(updateError)
          return { data: null, error: updateError }
        }

        options.onSuccess?.(result)
        return { data: result, error: null }
      } catch (err: any) {
        console.error("Error in update mutation:", err)
        const errorObj = createErrorObject(err.message || "Unknown error")
        setError(errorObj)
        options.onError?.(errorObj)
        return { data: null, error: errorObj }
      } finally {
        setIsLoading(false)
      }
    },
    [supabase, isReady, options],
  )

  const upsert = useCallback(
    async (data: T | T[]) => {
      if (!supabase || !isReady) {
        return { data: null, error: createErrorObject("Supabase client not ready") }
      }

      try {
        setIsLoading(true)
        setError(null)

        const { data: result, error: upsertError } = await supabase.from(options.table).upsert(data).select()

        if (upsertError) {
          setError(upsertError)
          options.onError?.(upsertError)
          return { data: null, error: upsertError }
        }

        options.onSuccess?.(result)
        return { data: result, error: null }
      } catch (err: any) {
        console.error("Error in upsert mutation:", err)
        const errorObj = createErrorObject(err.message || "Unknown error")
        setError(errorObj)
        options.onError?.(errorObj)
        return { data: null, error: errorObj }
      } finally {
        setIsLoading(false)
      }
    },
    [supabase, isReady, options],
  )

  const remove = useCallback(
    async (match: { column: string; value: any }) => {
      if (!supabase || !isReady) {
        return { data: null, error: createErrorObject("Supabase client not ready") }
      }

      try {
        setIsLoading(true)
        setError(null)

        const { data: result, error: deleteError } = await supabase
          .from(options.table)
          .delete()
          .eq(match.column, match.value)
          .select()

        if (deleteError) {
          setError(deleteError)
          options.onError?.(deleteError)
          return { data: null, error: deleteError }
        }

        options.onSuccess?.(result)
        return { data: result, error: null }
      } catch (err: any) {
        console.error("Error in delete mutation:", err)
        const errorObj = createErrorObject(err.message || "Unknown error")
        setError(errorObj)
        options.onError?.(errorObj)
        return { data: null, error: errorObj }
      } finally {
        setIsLoading(false)
      }
    },
    [supabase, isReady, options],
  )

  return {
    insert,
    update,
    upsert,
    remove,
    isLoading,
    error,
  }
}
