"use client"

import { useState, useEffect, useCallback } from "react"
import { useSupabase } from "@/contexts/supabase-context"
import type { PostgrestError } from "@supabase/supabase-js"

type QueryOptions<T> = {
  table: string
  columns?: string
  filters?: {
    column: string
    operator: "eq" | "neq" | "gt" | "lt" | "gte" | "lte" | "like" | "ilike" | "is"
    value: any
  }[]
  orderBy?: {
    column: string
    ascending?: boolean
  }
  limit?: number
  single?: boolean
  dependencies?: any[]
  enabled?: boolean
}

type QueryResult<T> = {
  data: T | null
  error: PostgrestError | null
  isLoading: boolean
  isError: boolean
  refetch: () => Promise<void>
}

export function useSupabaseQuery<T = any>(options: QueryOptions<T>): QueryResult<T> {
  const { supabase, isReady } = useSupabase()
  const [data, setData] = useState<T | null>(null)
  const [error, setError] = useState<PostgrestError | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  const dependencies = options.dependencies || []
  const enabled = options.enabled !== false

  const fetchData = useCallback(async () => {
    if (!supabase || !isReady || !enabled) {
      return
    }

    try {
      setIsLoading(true)
      setError(null)

      let query = supabase.from(options.table).select(options.columns || "*")

      // Apply filters
      if (options.filters && options.filters.length > 0) {
        options.filters.forEach((filter) => {
          if (filter.operator === "eq") {
            query = query.eq(filter.column, filter.value)
          } else if (filter.operator === "neq") {
            query = query.neq(filter.column, filter.value)
          } else if (filter.operator === "gt") {
            query = query.gt(filter.column, filter.value)
          } else if (filter.operator === "lt") {
            query = query.lt(filter.column, filter.value)
          } else if (filter.operator === "gte") {
            query = query.gte(filter.column, filter.value)
          } else if (filter.operator === "lte") {
            query = query.lte(filter.column, filter.value)
          } else if (filter.operator === "like") {
            query = query.like(filter.column, filter.value)
          } else if (filter.operator === "ilike") {
            query = query.ilike(filter.column, filter.value)
          } else if (filter.operator === "is") {
            query = query.is(filter.column, filter.value)
          }
        })
      }

      // Apply ordering
      if (options.orderBy) {
        query = query.order(options.orderBy.column, {
          ascending: options.orderBy.ascending !== false,
        })
      }

      // Apply limit
      if (options.limit) {
        query = query.limit(options.limit)
      }

      // Execute query
      const { data: result, error: queryError } = options.single ? await query.single() : await query

      if (queryError) {
        setError(queryError)
        setData(null)
      } else {
        setData(result as T)
        setError(null)
      }
    } catch (err: any) {
      console.error("Error in useSupabaseQuery:", err)
      setError(err)
      setData(null)
    } finally {
      setIsLoading(false)
    }
  }, [supabase, isReady, enabled, options.table, options.columns, options.single, options.limit, ...dependencies])

  useEffect(() => {
    let isMounted = true

    const execute = async () => {
      await fetchData()
    }

    execute()

    return () => {
      isMounted = false
    }
  }, [fetchData])

  return {
    data,
    error,
    isLoading,
    isError: error !== null,
    refetch: fetchData,
  }
}
