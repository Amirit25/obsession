export interface CalendarEvent {
  id: string
  title: string
  description: string
  location: string
  startTime: string // ISO date string
  endTime: string // ISO date string
  organizer?: {
    name: string
    email: string
  }
  attendees?: Array<{
    name: string
    email: string
  }>
}

export type CalendarProvider = "google" | "apple" | "outlook" | "ical"

export interface CalendarIntegrationProps {
  event: CalendarEvent
  className?: string
}
