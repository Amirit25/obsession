export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[]

export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string
          user_id: string
          email: string
          full_name: string
          avatar_url: string | null
          bio: string | null
          location: string | null
          website: string | null
          created_at: string
          updated_at: string
          role: "artist" | "promoter"
        }
        Insert: {
          id?: string
          user_id: string
          email: string
          full_name: string
          avatar_url?: string | null
          bio?: string | null
          location?: string | null
          website?: string | null
          created_at?: string
          updated_at?: string
          role: "artist" | "promoter"
        }
        Update: {
          id?: string
          user_id?: string
          email?: string
          full_name?: string
          avatar_url?: string | null
          bio?: string | null
          location?: string | null
          website?: string | null
          created_at?: string
          updated_at?: string
          role?: "artist" | "promoter"
        }
      }
      artist_profiles: {
        Row: {
          id: string
          profile_id: string
          artist_name: string | null
          genres: string[] | null
          band_size: number | null
          years_active: number | null
          performance_type: string[] | null
          fee_range: Json | null
          technical_requirements: string | null
          travel_distance: number | null
          available_for_touring: boolean
          social_links: Json | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          profile_id: string
          artist_name?: string | null
          genres?: string[] | null
          band_size?: number | null
          years_active?: number | null
          performance_type?: string[] | null
          fee_range?: Json | null
          technical_requirements?: string | null
          travel_distance?: number | null
          available_for_touring?: boolean
          social_links?: Json | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          profile_id?: string
          artist_name?: string | null
          genres?: string[] | null
          band_size?: number | null
          years_active?: number | null
          performance_type?: string[] | null
          fee_range?: Json | null
          technical_requirements?: string | null
          travel_distance?: number | null
          available_for_touring?: boolean
          social_links?: Json | null
          created_at?: string
          updated_at?: string
        }
      }
      promoter_profiles: {
        Row: {
          id: string
          profile_id: string
          company_name: string | null
          company_type: string | null
          venue_name: string | null
          venue_capacity: number | null
          event_types: string[] | null
          booking_frequency: string | null
          social_links: Json | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          profile_id: string
          company_name?: string | null
          company_type?: string | null
          venue_name?: string | null
          venue_capacity?: number | null
          event_types?: string[] | null
          booking_frequency?: string | null
          social_links?: Json | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          profile_id?: string
          company_name?: string | null
          company_type?: string | null
          venue_name?: string | null
          venue_capacity?: number | null
          event_types?: string[] | null
          booking_frequency?: string | null
          social_links?: Json | null
          created_at?: string
          updated_at?: string
        }
      }
      gig_listings: {
        Row: {
          id: string
          promoter_id: string
          title: string
          description: string
          event_date: string
          application_deadline: string
          location: string
          venue: string | null
          genres: string[] | null
          fee_range: Json | null
          audience_size: number | null
          duration: number | null
          requirements: string | null
          perks: string | null
          status: "open" | "closed" | "cancelled" | "filled"
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          promoter_id: string
          title: string
          description: string
          event_date: string
          application_deadline: string
          location: string
          venue?: string | null
          genres?: string[] | null
          fee_range?: Json | null
          audience_size?: number | null
          duration?: number | null
          requirements?: string | null
          perks?: string | null
          status?: "open" | "closed" | "cancelled" | "filled"
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          promoter_id?: string
          title?: string
          description?: string
          event_date?: string
          application_deadline?: string
          location?: string
          venue?: string | null
          genres?: string[] | null
          fee_range?: Json | null
          audience_size?: number | null
          duration?: number | null
          requirements?: string | null
          perks?: string | null
          status?: "open" | "closed" | "cancelled" | "filled"
          created_at?: string
          updated_at?: string
        }
      }
      applications: {
        Row: {
          id: string
          gig_id: string
          artist_id: string
          message: string | null
          proposed_fee: Json | null
          status: "pending" | "accepted" | "rejected" | "withdrawn"
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          gig_id: string
          artist_id: string
          message?: string | null
          proposed_fee?: Json | null
          status?: "pending" | "accepted" | "rejected" | "withdrawn"
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          gig_id?: string
          artist_id?: string
          message?: string | null
          proposed_fee?: Json | null
          status?: "pending" | "accepted" | "rejected" | "withdrawn"
          created_at?: string
          updated_at?: string
        }
      }
      booking_requests: {
        Row: {
          id: string
          requester_id: string
          artist_id: string
          event_name: string
          event_date: string
          event_location: string
          event_venue: string | null
          event_description: string | null
          budget: string | null
          contact_email: string
          contact_phone: string | null
          status: "pending" | "accepted" | "rejected" | "cancelled" | "completed"
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          requester_id: string
          artist_id: string
          event_name: string
          event_date: string
          event_location: string
          event_venue?: string | null
          event_description?: string | null
          budget?: string | null
          contact_email: string
          contact_phone?: string | null
          status?: "pending" | "accepted" | "rejected" | "cancelled" | "completed"
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          requester_id?: string
          artist_id?: string
          event_name?: string
          event_date?: string
          event_location?: string
          event_venue?: string | null
          event_description?: string | null
          budget?: string | null
          contact_email?: string
          contact_phone?: string | null
          status?: "pending" | "accepted" | "rejected" | "cancelled" | "completed"
          created_at?: string
          updated_at?: string
        }
      }
    }
  }
}
