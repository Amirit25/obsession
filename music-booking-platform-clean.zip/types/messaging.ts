export type Conversation = {
  id: string
  created_at: string
  updated_at: string
  participants: ConversationParticipant[]
  lastMessage?: Message
  unreadCount?: number
}

export type ConversationParticipant = {
  id: string
  conversation_id: string
  profile_id: string
  created_at: string
  profile: {
    id: string
    full_name: string
    avatar_url: string | null
    role: "artist" | "promoter"
  }
}

export type Message = {
  id: string
  conversation_id: string
  sender_id: string
  content: string
  read: boolean
  created_at: string
  updated_at: string
  sender?: {
    id: string
    full_name: string
    avatar_url: string | null
  }
}

export type NewMessage = {
  conversation_id: string
  content: string
}

export type NewConversation = {
  recipient_id: string
  initial_message: string
}
