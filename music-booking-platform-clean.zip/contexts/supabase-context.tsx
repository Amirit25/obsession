"use client"

import { createContext, useContext, useEffect, useState, type ReactNode } from "react"
import { getSupabaseBrowserClient } from "@/lib/supabase"
import type { SupabaseClient } from "@supabase/supabase-js"
import type { Database } from "@/types/supabase"

type SupabaseContextType = {
  supabase: SupabaseClient<Database> | null
  isReady: boolean
}

const SupabaseContext = createContext<SupabaseContextType>({
  supabase: null,
  isReady: false,
})

export function SupabaseProvider({ children }: { children: ReactNode }) {
  const [supabase, setSupabase] = useState<SupabaseClient<Database> | null>(null)
  const [isReady, setIsReady] = useState(false)

  useEffect(() => {
    try {
      // Only initialize Supabase on the client side
      if (typeof window !== "undefined") {
        const client = getSupabaseBrowserClient()
        setSupabase(client)
        setIsReady(true)
        console.log("Supabase client initialized successfully")
      }
    } catch (error) {
      console.error("Failed to initialize Supabase client:", error)
      // Don't set isReady to true if initialization failed
    }
  }, [])

  return <SupabaseContext.Provider value={{ supabase, isReady }}>{children}</SupabaseContext.Provider>
}

export function useSupabase() {
  const context = useContext(SupabaseContext)

  if (context === undefined) {
    throw new Error("useSupabase must be used within a SupabaseProvider")
  }

  return context
}
