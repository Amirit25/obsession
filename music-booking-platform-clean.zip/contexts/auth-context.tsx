"use client"

import { createContext, useContext, useEffect, useState, type ReactNode } from "react"
import { useSupabase } from "./supabase-context"
import { useToast } from "@/hooks/use-toast"
import { useRouter } from "next/navigation"

type User = {
  id: string
  email: string
}

type Profile = {
  id: string
  user_id: string
  full_name: string
  email: string
  avatar_url?: string
  role?: string
  location?: string
  bio?: string
}

type AuthContextType = {
  user: User | null
  profile: Profile | null
  isLoading: boolean
  isAuthenticated: boolean
  error: string | null
  signIn: (email: string, password: string) => Promise<{ success: boolean; error: string | null }>
  signUp: (email: string, password: string, fullName: string) => Promise<{ success: boolean; error: string | null }>
  signOut: () => Promise<void>
  resetPassword: (email: string) => Promise<{ success: boolean; error: string | null }>
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  profile: null,
  isLoading: true,
  isAuthenticated: false,
  error: null,
  signIn: async () => ({ success: false, error: "AuthContext not initialized" }),
  signUp: async () => ({ success: false, error: "AuthContext not initialized" }),
  signOut: async () => {},
  resetPassword: async () => ({ success: false, error: "AuthContext not initialized" }),
})

export function AuthProvider({ children }: { children: ReactNode }) {
  const { supabase, isReady } = useSupabase()
  const [user, setUser] = useState<User | null>(null)
  const [profile, setProfile] = useState<Profile | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const { toast } = useToast()
  const router = useRouter()

  // Initialize auth state
  useEffect(() => {
    if (!supabase || !isReady) {
      console.log("Supabase not ready yet, skipping auth initialization")
      return
    }

    const fetchUser = async () => {
      try {
        setIsLoading(true)
        setError(null)
        console.log("Fetching auth session...")

        // Get current session
        const {
          data: { session },
          error: sessionError,
        } = await supabase.auth.getSession()

        if (sessionError) {
          console.error("Session error:", sessionError)
          throw sessionError
        }

        console.log("Session retrieved:", session ? "Valid session" : "No session")

        if (!session) {
          setUser(null)
          setProfile(null)
          setIsLoading(false)
          return
        }

        // Set user from session
        setUser({
          id: session.user.id,
          email: session.user.email || "",
        })

        try {
          // Fetch user profile
          console.log("Fetching user profile...")
          const { data: profileData, error: profileError } = await supabase
            .from("profiles")
            .select("*")
            .eq("user_id", session.user.id)
            .single()

          if (profileError) {
            if (profileError.code === "PGRST116") {
              // No profile found - this is fine for new users
              console.log("No profile found for user")
            } else {
              console.error("Profile fetch error:", profileError)
            }
          } else {
            console.log("Profile retrieved successfully")
            setProfile(profileData)
          }
        } catch (profileErr) {
          console.error("Error in profile fetch:", profileErr)
          // Don't throw here, we can continue without a profile
        }
      } catch (err: any) {
        console.error("Error fetching auth state:", err)
        setError(err.message || "Failed to initialize authentication")
      } finally {
        setIsLoading(false)
      }
    }

    fetchUser()

    try {
      // Set up auth state change listener
      console.log("Setting up auth state change listener")
      const {
        data: { subscription },
      } = supabase.auth.onAuthStateChange(async (event, session) => {
        console.log("Auth state changed:", event, session ? "session exists" : "no session")

        if (session) {
          setUser({
            id: session.user.id,
            email: session.user.email || "",
          })

          try {
            // Fetch user profile on auth change
            const { data: profileData } = await supabase
              .from("profiles")
              .select("*")
              .eq("user_id", session.user.id)
              .single()

            setProfile(profileData)
          } catch (err) {
            console.error("Error fetching profile on auth change:", err)
          }
        } else {
          setUser(null)
          setProfile(null)
        }
      })

      return () => {
        console.log("Cleaning up auth subscription")
        subscription.unsubscribe()
      }
    } catch (err) {
      console.error("Error setting up auth subscription:", err)
    }
  }, [supabase, isReady, toast])

  // Sign in with email and password
  const signIn = async (email: string, password: string) => {
    if (!supabase) {
      console.error("Supabase client not initialized")
      return { success: false, error: "Authentication service not available" }
    }

    try {
      setIsLoading(true)
      console.log("Attempting sign in with email:", email)

      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      })

      if (error) {
        console.error("Sign in error:", error)
        return { success: false, error: error.message }
      }

      console.log("Sign in successful:", data.user?.id)

      // Redirect to appropriate page based on user role
      if (data.user) {
        try {
          const { data: profileData } = await supabase
            .from("profiles")
            .select("role")
            .eq("user_id", data.user.id)
            .single()

          if (profileData?.role === "artist") {
            router.push("/artist")
          } else if (profileData?.role === "promoter") {
            router.push("/promoter")
          } else {
            router.push("/")
          }
        } catch (err) {
          console.error("Error fetching profile after login:", err)
          // Default redirect if profile fetch fails
          router.push("/")
        }
      }

      return { success: true, error: null }
    } catch (err: any) {
      console.error("Sign in exception:", err)
      return { success: false, error: err.message || "An unexpected error occurred" }
    } finally {
      setIsLoading(false)
    }
  }

  // Sign up with email and password
  const signUp = async (email: string, password: string, fullName: string) => {
    if (!supabase) {
      return { success: false, error: "Authentication service not available" }
    }

    try {
      setIsLoading(true)
      console.log("Attempting sign up with email:", email)

      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            full_name: fullName,
          },
        },
      })

      if (error) {
        console.error("Sign up error:", error)
        return { success: false, error: error.message }
      }

      console.log("Sign up successful:", data.user?.id)

      // Create profile record
      if (data.user) {
        try {
          const { error: profileError } = await supabase.from("profiles").insert({
            user_id: data.user.id,
            full_name: fullName,
            email: email,
          })

          if (profileError) {
            console.error("Error creating profile:", profileError)
            return { success: true, error: "Account created but profile setup failed" }
          }
        } catch (err) {
          console.error("Exception creating profile:", err)
          // Continue even if profile creation fails
        }
      }

      return { success: true, error: null }
    } catch (err: any) {
      console.error("Sign up exception:", err)
      return { success: false, error: err.message || "An unexpected error occurred" }
    } finally {
      setIsLoading(false)
    }
  }

  // Sign out
  const signOut = async () => {
    if (!supabase) {
      console.error("Supabase client not initialized")
      return
    }

    try {
      setIsLoading(true)
      console.log("Signing out user")
      await supabase.auth.signOut()
      router.push("/auth/login")
    } catch (err: any) {
      console.error("Sign out error:", err)
      toast({
        title: "Error",
        description: "Failed to sign out. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  // Reset password
  const resetPassword = async (email: string) => {
    if (!supabase) {
      return { success: false, error: "Authentication service not available" }
    }

    try {
      console.log("Requesting password reset for:", email)
      const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: `${window.location.origin}/auth/reset-password`,
      })

      if (error) {
        console.error("Reset password error:", error)
        return { success: false, error: error.message }
      }

      return { success: true, error: null }
    } catch (err: any) {
      console.error("Reset password exception:", err)
      return { success: false, error: err.message || "An unexpected error occurred" }
    }
  }

  const value = {
    user,
    profile,
    isLoading,
    isAuthenticated: !!user,
    error,
    signIn,
    signUp,
    signOut,
    resetPassword,
  }

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export function useAuth() {
  const context = useContext(AuthContext)

  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }

  return context
}
