"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { MultiSelect } from "@/components/multi-select"
import { useToast } from "@/hooks/use-toast"

// African music genres
const africanGenreOptions = [
  { label: "Afrobeat", value: "afrobeat" },
  { label: "Highlife", value: "highlife" },
  { label: "Afro-fusion", value: "afro-fusion" },
  { label: "Amapiano", value: "amapiano" },
  { label: "Soukous", value: "soukous" },
  { label: "Mbalax", value: "mbalax" },
  { label: "Bongo Flava", value: "bongo-flava" },
  { label: "Kwaito", value: "kwaito" },
  { label: "Jùjú", value: "juju" },
  { label: "Fuji", value: "fuji" },
  { label: "Afro-jazz", value: "afro-jazz" },
  { label: "Gnawa", value: "gnawa" },
  { label: "Rai", value: "rai" },
  { label: "Chimurenga", value: "chimurenga" },
  { label: "Benga", value: "benga" },
  { label: "Ethio-jazz", value: "ethio-jazz" },
  { label: "Taarab", value: "taarab" },
  { label: "Afro-house", value: "afro-house" },
  { label: "Coupe-Decale", value: "coupe-decale" },
  { label: "Ndombolo", value: "ndombolo" },
]

// African regions
const africanRegions = [
  { label: "West Africa", value: "west-africa" },
  { label: "East Africa", value: "east-africa" },
  { label: "North Africa", value: "north-africa" },
  { label: "Central Africa", value: "central-africa" },
  { label: "Southern Africa", value: "southern-africa" },
]

// African countries
const africanCountries = [
  { label: "Nigeria", value: "nigeria" },
  { label: "South Africa", value: "south-africa" },
  { label: "Ghana", value: "ghana" },
  { label: "Kenya", value: "kenya" },
  { label: "Tanzania", value: "tanzania" },
  { label: "Ethiopia", value: "ethiopia" },
  { label: "Senegal", value: "senegal" },
  { label: "Côte d'Ivoire", value: "cote-divoire" },
  { label: "Democratic Republic of Congo", value: "dr-congo" },
  { label: "Mali", value: "mali" },
  { label: "Morocco", value: "morocco" },
  { label: "Egypt", value: "egypt" },
  { label: "Algeria", value: "algeria" },
  { label: "Angola", value: "angola" },
  { label: "Zimbabwe", value: "zimbabwe" },
  { label: "Uganda", value: "uganda" },
  { label: "Rwanda", value: "rwanda" },
  { label: "Cameroon", value: "cameroon" },
  { label: "Mozambique", value: "mozambique" },
  { label: "Zambia", value: "zambia" },
]

// African languages
const africanLanguages = [
  { label: "Swahili", value: "swahili" },
  { label: "Yoruba", value: "yoruba" },
  { label: "Igbo", value: "igbo" },
  { label: "Hausa", value: "hausa" },
  { label: "Amharic", value: "amharic" },
  { label: "Zulu", value: "zulu" },
  { label: "Xhosa", value: "xhosa" },
  { label: "Twi", value: "twi" },
  { label: "Wolof", value: "wolof" },
  { label: "Arabic", value: "arabic" },
  { label: "Lingala", value: "lingala" },
  { label: "Shona", value: "shona" },
  { label: "Somali", value: "somali" },
  { label: "Oromo", value: "oromo" },
  { label: "English", value: "english" },
  { label: "French", value: "french" },
  { label: "Portuguese", value: "portuguese" },
]

// Traditional instruments
const traditionalInstruments = [
  { label: "Kora", value: "kora" },
  { label: "Djembe", value: "djembe" },
  { label: "Talking Drum", value: "talking-drum" },
  { label: "Mbira", value: "mbira" },
  { label: "Balafon", value: "balafon" },
  { label: "Ngoni", value: "ngoni" },
  { label: "Marimba", value: "marimba" },
  { label: "Oud", value: "oud" },
  { label: "Kalimba", value: "kalimba" },
  { label: "Shekere", value: "shekere" },
]

// Performance types
const performanceTypes = [
  { label: "Live Band", value: "live-band" },
  { label: "Solo Performance", value: "solo" },
  { label: "Festival", value: "festival" },
  { label: "Corporate Event", value: "corporate" },
  { label: "Wedding", value: "wedding" },
  { label: "Cultural Ceremony", value: "cultural-ceremony" },
  { label: "Club Performance", value: "club" },
  { label: "Traditional Ceremony", value: "traditional-ceremony" },
  { label: "Concert", value: "concert" },
  { label: "Studio Session", value: "studio-session" },
]

export default function EditArtistProfilePage() {
  // Mock data for demonstration - in a real app, this would be fetched from the database
  const mockArtistData = {
    artistName: "Femi Koya",
    bio: "Blending West African highlife with modern jazz, Femi Koya is a saxophonist, vocalist and composer known for his electrifying performances that celebrate the rich musical heritage of Africa.",
    region: "west-africa",
    country: "nigeria",
    genres: ["afrobeat", "highlife", "afro-jazz"],
    languages: ["english", "yoruba", "igbo"],
    traditionalInfluences: "Yoruba traditional music, Highlife, Palm-wine music",
    traditionalInstruments: ["talking-drum", "shekere"],
    yearsActive: 12,
    bandSize: 6,
    performanceTypes: ["live-band", "festival", "corporate"],
    culturalAffiliations: "Yoruba",
    diasporaConnections: "UK, France, USA",
    socialLinks: {
      instagram: "https://instagram.com/femikoya",
      twitter: "https://twitter.com/femikoya",
      youtube: "https://youtube.com/femikoya",
      spotify: "https://open.spotify.com/artist/femikoya",
    },
  }

  const [formData, setFormData] = useState({
    artistName: mockArtistData.artistName,
    bio: mockArtistData.bio,
    region: mockArtistData.region,
    country: mockArtistData.country,
    traditionalInfluences: mockArtistData.traditionalInfluences,
    yearsActive: mockArtistData.yearsActive,
    bandSize: mockArtistData.bandSize,
    culturalAffiliations: mockArtistData.culturalAffiliations,
    diasporaConnections: mockArtistData.diasporaConnections,
    instagram: mockArtistData.socialLinks.instagram,
    twitter: mockArtistData.socialLinks.twitter,
    youtube: mockArtistData.socialLinks.youtube,
    spotify: mockArtistData.socialLinks.spotify,
  })

  const [selectedGenres, setSelectedGenres] = useState<string[]>(mockArtistData.genres)
  const [selectedLanguages, setSelectedLanguages] = useState<string[]>(mockArtistData.languages)
  const [selectedInstruments, setSelectedInstruments] = useState<string[]>(mockArtistData.traditionalInstruments)
  const [selectedPerformanceTypes, setSelectedPerformanceTypes] = useState<string[]>(mockArtistData.performanceTypes)
  const [isLoading, setIsLoading] = useState(false)
  const { toast } = useToast()

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSelectChange = (name: string, value: string) => {
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      // In a real app, this would be an API call to update the profile
      await new Promise((resolve) => setTimeout(resolve, 1000))

      toast({
        title: "Profile updated",
        description: "Your artist profile has been updated successfully.",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update profile. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <header className="border-b bg-white dark:bg-gray-950"></header>

      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center mb-8">
          <Button variant="ghost" size="sm" className="mr-2" asChild>
            <Link href="/artist/profile">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Profile
            </Link>
          </Button>
          <h1 className="text-2xl font-bold">Edit Artist Profile</h1>
        </div>

        <div className="max-w-4xl mx-auto">
          <form onSubmit={handleSubmit}>
            <div className="space-y-8">
              <Card>
                <CardHeader>
                  <CardTitle>Basic Information</CardTitle>
                  <CardDescription>Update your artist profile information</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="artistName">Artist/Band Name</Label>
                    <Input
                      id="artistName"
                      name="artistName"
                      value={formData.artistName}
                      onChange={handleChange}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="bio">Bio</Label>
                    <Textarea id="bio" name="bio" value={formData.bio} onChange={handleChange} rows={4} required />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="region">African Region</Label>
                      <Select value={formData.region} onValueChange={(value) => handleSelectChange("region", value)}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select region" />
                        </SelectTrigger>
                        <SelectContent>
                          {africanRegions.map((region) => (
                            <SelectItem key={region.value} value={region.value}>
                              {region.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="country">Country</Label>
                      <Select value={formData.country} onValueChange={(value) => handleSelectChange("country", value)}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select country" />
                        </SelectTrigger>
                        <SelectContent>
                          {africanCountries.map((country) => (
                            <SelectItem key={country.value} value={country.value}>
                              {country.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>Music Genres</Label>
                    <MultiSelect
                      options={africanGenreOptions}
                      selected={selectedGenres}
                      onChange={setSelectedGenres}
                      placeholder="Select your music genres"
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="yearsActive">Years Active</Label>
                      <Input
                        id="yearsActive"
                        name="yearsActive"
                        type="number"
                        value={formData.yearsActive}
                        onChange={handleChange}
                        min={0}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="bandSize">Band Size</Label>
                      <Input
                        id="bandSize"
                        name="bandSize"
                        type="number"
                        value={formData.bandSize}
                        onChange={handleChange}
                        min={1}
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Cultural Information</CardTitle>
                  <CardDescription>Share your cultural background and influences</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="culturalAffiliations">Cultural Affiliations</Label>
                    <Input
                      id="culturalAffiliations"
                      name="culturalAffiliations"
                      value={formData.culturalAffiliations}
                      onChange={handleChange}
                      placeholder="e.g. Yoruba, Zulu, Akan"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="traditionalInfluences">Traditional Influences</Label>
                    <Textarea
                      id="traditionalInfluences"
                      name="traditionalInfluences"
                      value={formData.traditionalInfluences}
                      onChange={handleChange}
                      placeholder="Describe the traditional music styles that influence your work"
                      rows={3}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Languages</Label>
                    <MultiSelect
                      options={africanLanguages}
                      selected={selectedLanguages}
                      onChange={setSelectedLanguages}
                      placeholder="Select languages you perform in"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Traditional Instruments</Label>
                    <MultiSelect
                      options={traditionalInstruments}
                      selected={selectedInstruments}
                      onChange={setSelectedInstruments}
                      placeholder="Select traditional instruments you play"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="diasporaConnections">Diaspora Connections</Label>
                    <Input
                      id="diasporaConnections"
                      name="diasporaConnections"
                      value={formData.diasporaConnections}
                      onChange={handleChange}
                      placeholder="e.g. UK, USA, France"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Performance Types</Label>
                    <MultiSelect
                      options={performanceTypes}
                      selected={selectedPerformanceTypes}
                      onChange={setSelectedPerformanceTypes}
                      placeholder="Select types of performances you offer"
                    />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Social Media</CardTitle>
                  <CardDescription>Connect your social media accounts</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="instagram">Instagram</Label>
                      <Input
                        id="instagram"
                        name="instagram"
                        value={formData.instagram}
                        onChange={handleChange}
                        placeholder="https://instagram.com/yourusername"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="twitter">Twitter</Label>
                      <Input
                        id="twitter"
                        name="twitter"
                        value={formData.twitter}
                        onChange={handleChange}
                        placeholder="https://twitter.com/yourusername"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="youtube">YouTube</Label>
                      <Input
                        id="youtube"
                        name="youtube"
                        value={formData.youtube}
                        onChange={handleChange}
                        placeholder="https://youtube.com/yourchannel"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="spotify">Spotify</Label>
                      <Input
                        id="spotify"
                        name="spotify"
                        value={formData.spotify}
                        onChange={handleChange}
                        placeholder="https://open.spotify.com/artist/yourid"
                      />
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button type="submit" className="w-full" disabled={isLoading}>
                    {isLoading ? "Saving Changes..." : "Save Changes"}
                  </Button>
                </CardFooter>
              </Card>
            </div>
          </form>
        </div>
      </div>
    </div>
  )
}
