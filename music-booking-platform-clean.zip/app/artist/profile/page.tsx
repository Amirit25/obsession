"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Edit, Music, Globe, MapPin, Languages, Drum, Calendar, Users, Mic } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { useToast } from "@/hooks/use-toast"
import { useAuth } from "@/contexts/auth-context"
import { getSupabaseBrowserClient } from "@/lib/supabase"
import { BookingDialog } from "@/components/booking-dialog"
import { VideoImportDialog } from "@/components/video-import-dialog"

// African regions map for display
const regionMap = {
  "west-africa": "West Africa",
  "east-africa": "East Africa",
  "north-africa": "North Africa",
  "central-africa": "Central Africa",
  "southern-africa": "Southern Africa",
}

// African countries map for display
const countryMap = {
  nigeria: "Nigeria",
  "south-africa": "South Africa",
  ghana: "Ghana",
  kenya: "Kenya",
  tanzania: "Tanzania",
  ethiopia: "Ethiopia",
  senegal: "Senegal",
  "cote-divoire": "Côte d'Ivoire",
  "dr-congo": "Democratic Republic of Congo",
  mali: "Mali",
  morocco: "Morocco",
  egypt: "Egypt",
  algeria: "Algeria",
  angola: "Angola",
  zimbabwe: "Zimbabwe",
  uganda: "Uganda",
  rwanda: "Rwanda",
  cameroon: "Cameroon",
  mozambique: "Mozambique",
  zambia: "Zambia",
}

// African languages
const africanLanguages = [
  { label: "Swahili", value: "swahili" },
  { label: "Yoruba", value: "yoruba" },
  { label: "Igbo", value: "igbo" },
  { label: "Hausa", value: "hausa" },
  { label: "Amharic", value: "amharic" },
  { label: "Zulu", value: "zulu" },
  { label: "Xhosa", value: "xhosa" },
  { label: "Twi", value: "twi" },
  { label: "Wolof", value: "wolof" },
  { label: "Arabic", value: "arabic" },
  { label: "Lingala", value: "lingala" },
  { label: "Shona", value: "shona" },
  { label: "Somali", value: "somali" },
  { label: "Oromo", value: "oromo" },
]

// Traditional instruments
const traditionalInstruments = [
  { label: "Kora", value: "kora" },
  { label: "Djembe", value: "djembe" },
  { label: "Talking Drum", value: "talking-drum" },
  { label: "Mbira", value: "mbira" },
  { label: "Balafon", value: "balafon" },
  { label: "Ngoni", value: "ngoni" },
  { label: "Marimba", value: "marimba" },
  { label: "Oud", value: "oud" },
  { label: "Kalimba", value: "kalimba" },
  { label: "Shekere", value: "shekere" },
]

export default function ArtistProfilePage() {
  const { user, profile } = useAuth()
  const [artistProfile, setArtistProfile] = useState<any>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [isCurrentUser, setIsCurrentUser] = useState(false)
  const { toast } = useToast()
  const [supabase, setSupabase] = useState<any>(null)
  const [error, setError] = useState<string | null>(null)

  // Get artist ID from URL if present
  const getArtistIdFromUrl = () => {
    if (typeof window !== "undefined") {
      const urlParams = new URLSearchParams(window.location.search)
      return urlParams.get("id")
    }
    return null
  }

  const artistId = getArtistIdFromUrl()

  // Initialize Supabase client only on the client side
  useEffect(() => {
    if (typeof window !== "undefined") {
      try {
        const client = getSupabaseBrowserClient()
        setSupabase(client)
      } catch (err: any) {
        console.error("Failed to initialize Supabase client:", err)
        setError("Failed to initialize database connection")
        setIsLoading(false)
      }
    } else {
      // During SSR, set loading to false to avoid hydration issues
      setIsLoading(false)
    }
  }, [])

  useEffect(() => {
    // Skip if we're in SSR or if Supabase client isn't initialized yet
    if (typeof window === "undefined" || !supabase) {
      return
    }

    const fetchArtistProfile = async () => {
      try {
        if (artistId) {
          // Viewing someone else's profile
          const { data: artistData, error: artistError } = await supabase
            .from("artist_profiles")
            .select("*")
            .eq("id", artistId)
            .single()

          if (artistError) throw artistError

          // Get the profile data
          const { data: profileData, error: profileError } = await supabase
            .from("profiles")
            .select("*")
            .eq("id", artistData.profile_id)
            .single()

          if (profileError) throw profileError

          setArtistProfile({
            ...artistData,
            profiles: profileData,
          })

          // Check if this is the current user's profile
          setIsCurrentUser(profile?.id === artistData.profile_id)
        } else if (profile) {
          // Viewing own profile
          setIsCurrentUser(true)

          // Get the artist profile
          const { data: artistData, error: artistError } = await supabase
            .from("artist_profiles")
            .select(`
              *,
              profiles:profile_id (
                id, 
                full_name, 
                email, 
                location, 
                avatar_url, 
                bio
              )
            `)
            .eq("profile_id", profile.id)
            .single()

          if (artistError && artistError.code !== "PGRST116") {
            // PGRST116 is "no rows returned" - this is fine for new users
            throw artistError
          }

          setArtistProfile(
            artistData || {
              profile_id: profile.id,
              profiles: {
                id: profile.id,
                full_name: profile.full_name,
                email: profile.email,
                location: profile.location,
                avatar_url: profile.avatar_url,
                bio: profile.bio,
              },
            },
          )
        } else {
          throw new Error("No profile or artist ID provided")
        }
      } catch (error: any) {
        console.error("Error fetching artist profile:", error)
        toast({
          title: "Error",
          description: "Failed to load artist profile",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }

    if (user || artistId) {
      fetchArtistProfile()
    } else {
      setIsLoading(false)
    }
  }, [profile, supabase, toast, user, artistId])

  // Show error state if there's an error
  if (error) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardContent className="py-8">
            <p className="text-center mb-4 text-destructive">{error}</p>
            <Button asChild className="w-full">
              <Link href="/">Go Home</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4">Loading profile...</p>
        </div>
      </div>
    )
  }

  if (!artistProfile && !artistId) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardContent className="py-8">
            <p className="text-center mb-4">Please log in to view your profile</p>
            <Button asChild className="w-full">
              <Link href="/auth/login">Log In</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  if (!artistProfile && artistId) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardContent className="py-8">
            <p className="text-center mb-4">Artist profile not found</p>
            <Button asChild className="w-full">
              <Link href="/">Go Home</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  // Mock data for demonstration - in a real app, this would come from the database
  const mockArtistData = {
    artistName: artistProfile.artist_name || artistProfile.profiles?.full_name || "New Artist",
    bio: artistProfile.profiles?.bio || "No bio available yet.",
    region: artistProfile.region || "west-africa",
    country: artistProfile.country || "nigeria",
    genres: artistProfile.genres || ["afrobeat", "highlife", "afro-jazz"],
    languages: artistProfile.languages || ["english", "yoruba", "igbo"],
    traditionalInfluences:
      artistProfile.traditional_influences || "Yoruba traditional music, Highlife, Palm-wine music",
    traditionalInstruments: artistProfile.traditional_instruments || ["talking-drum", "shekere"],
    yearsActive: artistProfile.years_active || 0,
    bandSize: artistProfile.band_size || 1,
    performanceTypes: artistProfile.performance_type || ["live-band", "festival", "corporate"],
    culturalAffiliations: artistProfile.cultural_affiliations || "Yoruba",
    diasporaConnections: artistProfile.diaspora_connections || "UK, France, USA",
    completionPercentage: 85,
    socialLinks: artistProfile.social_links || {
      instagram: "https://instagram.com/artist",
      twitter: "https://twitter.com/artist",
      youtube: "https://youtube.com/artist",
      spotify: "https://open.spotify.com/artist/id",
    },
    audioSamples: [
      { title: "Lagos Groove", url: "#", duration: "3:45" },
      { title: "Ancestral Calling", url: "#", duration: "4:12" },
      { title: "Jùjú Fusion", url: "#", duration: "5:30" },
    ],
    videoSamples: [
      { title: "Live at Africa Music Festival", url: "#", thumbnail: "/placeholder.svg?height=180&width=320" },
      { title: "Cultural Heritage Performance", url: "#", thumbnail: "/placeholder.svg?height=180&width=320" },
    ],
    upcomingGigs: [
      { title: "African Rhythms Night", date: "2025-06-15", location: "Accra, Ghana" },
      { title: "World Music Festival", date: "2025-07-22", location: "Paris, France" },
    ],
    pastGigs: [
      { title: "Lagos Jazz Festival", date: "2024-11-10", location: "Lagos, Nigeria" },
      { title: "Cultural Exchange Program", date: "2024-09-05", location: "Nairobi, Kenya" },
      { title: "African Unity Concert", date: "2024-05-25", location: "Johannesburg, South Africa" },
    ],
  }

  // In a real app, we would use the actual artist profile data instead of mock data
  const artistData = {
    ...mockArtistData,
    artistName: artistProfile.artist_name || artistProfile.profiles?.full_name || mockArtistData.artistName,
    bio: artistProfile.profiles?.bio || mockArtistData.bio,
    region: artistProfile.region || mockArtistData.region,
    country: artistProfile.country || mockArtistData.country,
    genres: artistProfile.genres || mockArtistData.genres,
    languages: artistProfile.languages || mockArtistData.languages,
    traditionalInfluences: artistProfile.traditional_influences || mockArtistData.traditionalInfluences,
    traditionalInstruments: artistProfile.traditional_instruments || mockArtistData.traditionalInstruments,
    yearsActive: artistProfile.years_active || mockArtistData.yearsActive,
    bandSize: artistProfile.band_size || mockArtistData.bandSize,
    performanceTypes: artistProfile.performance_type || mockArtistData.performanceTypes,
    culturalAffiliations: artistProfile.cultural_affiliations || mockArtistData.culturalAffiliations,
    diasporaConnections: artistProfile.diaspora_connections || mockArtistData.diasporaConnections,
    socialLinks: artistProfile.social_links || mockArtistData.socialLinks,
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center mb-8">
          <h1 className="text-2xl font-bold">Artist Profile</h1>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Profile Summary */}
          <div className="lg:col-span-1 space-y-6">
            <Card>
              <CardHeader className="pb-2">
                <div className="flex justify-between items-start">
                  <div className="flex flex-col">
                    <CardTitle>{artistData.artistName}</CardTitle>
                    <CardDescription className="flex items-center mt-1">
                      <MapPin className="w-4 h-4 mr-1" />
                      {countryMap[artistData.country as keyof typeof countryMap] || artistData.country},{" "}
                      {regionMap[artistData.region as keyof typeof regionMap] || artistData.region}
                    </CardDescription>
                  </div>
                  {isCurrentUser && (
                    <Button variant="ghost" size="icon" className="h-8 w-8" asChild>
                      <Link href="/artist/profile/edit">
                        <Edit className="h-4 w-4" />
                        <span className="sr-only">Edit Profile</span>
                      </Link>
                    </Button>
                  )}
                </div>
              </CardHeader>
              <CardContent className="pb-2">
                <div className="flex justify-center mb-6">
                  <Avatar className="h-32 w-32">
                    <AvatarImage
                      src={artistProfile.profiles?.avatar_url || "/placeholder.svg?height=128&width=128"}
                      alt={artistData.artistName}
                    />
                    <AvatarFallback>{artistData.artistName.charAt(0)}</AvatarFallback>
                  </Avatar>
                </div>

                <div className="space-y-4">
                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground mb-2">Bio</h3>
                    <p className="text-sm">{artistData.bio}</p>
                  </div>

                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground mb-2">Genres</h3>
                    <div className="flex flex-wrap gap-1">
                      {artistData.genres.map((genre: string) => (
                        <Badge key={genre} variant="secondary">
                          {genre.charAt(0).toUpperCase() + genre.slice(1).replace("-", " ")}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground mb-2">Languages</h3>
                    <div className="flex flex-wrap gap-1">
                      {artistData.languages.map((language: string) => (
                        <Badge key={language} variant="outline">
                          {language.charAt(0).toUpperCase() + language.slice(1)}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground mb-2">Cultural Affiliations</h3>
                    <p className="text-sm">{artistData.culturalAffiliations}</p>
                  </div>

                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground mb-2">Traditional Influences</h3>
                    <p className="text-sm">{artistData.traditionalInfluences}</p>
                  </div>

                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground mb-2">Traditional Instruments</h3>
                    <div className="flex flex-wrap gap-1">
                      {artistData.traditionalInstruments.map((instrument: string) => (
                        <Badge key={instrument} variant="outline">
                          {instrument
                            .split("-")
                            .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
                            .join(" ")}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground mb-2">Diaspora Connections</h3>
                    <p className="text-sm">{artistData.diasporaConnections}</p>
                  </div>

                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground mb-2">Performance Details</h3>
                    <div className="grid grid-cols-2 gap-2 text-sm">
                      <div>
                        <span className="text-muted-foreground">Years Active:</span> {artistData.yearsActive}
                      </div>
                      <div>
                        <span className="text-muted-foreground">Band Size:</span> {artistData.bandSize}
                      </div>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground mb-2">Performance Types</h3>
                    <div className="flex flex-wrap gap-1">
                      {artistData.performanceTypes.map((type: string) => (
                        <Badge key={type} variant="secondary">
                          {type
                            .split("-")
                            .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
                            .join(" ")}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground mb-2">Social Media</h3>
                    <div className="flex space-x-2">
                      <Button variant="outline" size="icon" className="h-8 w-8" asChild>
                        <a href={artistData.socialLinks.instagram} target="_blank" rel="noopener noreferrer">
                          <svg
                            className="h-4 w-4"
                            fill="currentColor"
                            viewBox="0 0 24 24"
                            xmlns="http://www.w3.org/2000/svg"
                          >
                            <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z" />
                          </svg>
                        </a>
                      </Button>
                      <Button variant="outline" size="icon" className="h-8 w-8" asChild>
                        <a href={artistData.socialLinks.twitter} target="_blank" rel="noopener noreferrer">
                          <svg
                            className="h-4 w-4"
                            fill="currentColor"
                            viewBox="0 0 24 24"
                            xmlns="http://www.w3.org/2000/svg"
                          >
                            <path d="M24 4.557c-.883.392-1.832.656-2.828.775 1.017-.609 1.798-1.574 2.165-2.724-.951.564-2.005.974-3.127 1.195-.897-.957-2.178-1.555-3.594-1.555-3.179 0-5.515 2.966-4.797 6.045-4.091-.205-7.719-2.165-10.148-5.144-1.29 2.213-.669 5.108 1.523 6.574-.806-.026-1.566-.247-2.229-.616-.054 2.281 1.581 4.415 3.949 4.89-.693.188-1.452.232-2.224.084.626 1.956 2.444 3.379 4.6 3.419-2.07 1.623-4.678 2.348-7.29 2.04 2.179 1.397 4.768 2.212 7.548 2.212 9.142 0 14.307-7.721 13.995-14.646.962-.695 1.797-1.562 2.457-2.549z" />
                          </svg>
                        </a>
                      </Button>
                      <Button variant="outline" size="icon" className="h-8 w-8" asChild>
                        <a href={artistData.socialLinks.youtube} target="_blank" rel="noopener noreferrer">
                          <svg
                            className="h-4 w-4"
                            fill="currentColor"
                            viewBox="0 0 24 24"
                            xmlns="http://www.w3.org/2000/svg"
                          >
                            <path d="M19.615 3.184c-3.604-.246-11.631-.245-15.23 0-3.897.266-4.356 2.62-4.385 8.816.029 6.185.484 8.549 4.385 8.816 3.6.245 11.626.246 15.23 0 3.897-.266 4.356-2.62 4.385-8.816-.029-6.185-.484-8.549-4.385-8.816zm-10.615 12.816v-8l8 3.993-8 4.007z" />
                          </svg>
                        </a>
                      </Button>
                      <Button variant="outline" size="icon" className="h-8 w-8" asChild>
                        <a href={artistData.socialLinks.spotify} target="_blank" rel="noopener noreferrer">
                          <svg
                            className="h-4 w-4"
                            fill="currentColor"
                            viewBox="0 0 24 24"
                            xmlns="http://www.w3.org/2000/svg"
                          >
                            <path d="M12 0C5.4 0 0 5.4 0 12s5.4 12 12 12 12-5.4 12-12S18.66 0 12 0zm5.521 17.34c-.24.359-.66.48-1.021.24-2.82-1.74-6.36-2.101-10.561-1.141-.418.122-.779-.179-.899-.539-.12-.421.18-.78.54-.9 4.56-1.021 8.52-.6 11.64 1.32.42.18.479.659.301 1.02zm1.44-3.3c-.301.42-.841.6-1.262.3-3.239-1.98-8.159-2.58-11.939-1.38-.479.12-1.02-.12-1.14-.6-.12-.48.12-1.021.6-1.141C9.6 9.9 15 10.561 18.72 12.84c.361.181.54.78.241 1.2zm.12-3.36C15.24 8.4 8.82 8.16 5.16 9.301c-.6.179-1.2-.181-1.38-.721-.18-.601.18-1.2.72-1.381 4.26-1.26 11.28-1.02 15.721 1.621.539.3.719 1.02.419 1.56-.299.421-1.02.599-1.559.3z" />
                          </svg>
                        </a>
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                {!isCurrentUser && (
                  <BookingDialog
                    artistId={artistId || artistProfile.id}
                    artistName={artistData.artistName}
                    buttonLabel="Book This Artist"
                    className="w-full"
                  />
                )}
                {isCurrentUser && (
                  <div className="w-full">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm font-medium">Profile Completion</span>
                      <span className="text-sm font-medium">{artistData.completionPercentage}%</span>
                    </div>
                    <Progress value={artistData.completionPercentage} className="h-2" />
                  </div>
                )}
              </CardFooter>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Upcoming Gigs</CardTitle>
              </CardHeader>
              <CardContent>
                {artistData.upcomingGigs.length > 0 ? (
                  <ul className="space-y-3">
                    {artistData.upcomingGigs.map((gig: any, index: number) => (
                      <li key={index} className="flex justify-between items-center">
                        <div>
                          <p className="font-medium">{gig.title}</p>
                          <p className="text-sm text-muted-foreground">{gig.location}</p>
                        </div>
                        <div className="text-sm">
                          {new Date(gig.date).toLocaleDateString("en-US", {
                            year: "numeric",
                            month: "short",
                            day: "numeric",
                          })}
                        </div>
                      </li>
                    ))}
                  </ul>
                ) : (
                  <p className="text-sm text-muted-foreground">No upcoming gigs scheduled.</p>
                )}
              </CardContent>
              {isCurrentUser && (
                <CardFooter>
                  <Button variant="outline" className="w-full" asChild>
                    <Link href="/artist/gigs/add">
                      <Calendar className="mr-2 h-4 w-4" />
                      Add Gig
                    </Link>
                  </Button>
                </CardFooter>
              )}
            </Card>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-2">
            <Tabs defaultValue="media">
              <TabsList className="mb-6">
                <TabsTrigger value="media">Media</TabsTrigger>
                <TabsTrigger value="performances">Performances</TabsTrigger>
                <TabsTrigger value="cultural">Cultural Heritage</TabsTrigger>
                <TabsTrigger value="reviews">Reviews</TabsTrigger>
              </TabsList>

              <TabsContent value="media" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Music className="mr-2 h-5 w-5" />
                      Audio Samples
                    </CardTitle>
                    <CardDescription>Listen to samples of your music</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {artistData.audioSamples.map((audio: any, index: number) => (
                        <div key={index} className="flex items-center justify-between">
                          <div className="flex items-center">
                            <div className="h-10 w-10 rounded-md bg-primary/10 flex items-center justify-center mr-3">
                              <Music className="h-5 w-5 text-primary" />
                            </div>
                            <div>
                              <p className="font-medium">{audio.title}</p>
                              <p className="text-sm text-muted-foreground">{audio.duration}</p>
                            </div>
                          </div>
                          <Button variant="ghost" size="sm">
                            Play
                          </Button>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                  {isCurrentUser && (
                    <CardFooter>
                      <Button variant="outline" className="w-full">
                        Upload New Audio
                      </Button>
                    </CardFooter>
                  )}
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Video Samples</CardTitle>
                    <CardDescription>Showcase your performances</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {artistData.videoSamples.map((video: any, index: number) => (
                        <div key={index} className="space-y-2">
                          <div className="relative aspect-video rounded-md overflow-hidden">
                            <img
                              src={video.thumbnail || "/placeholder.svg"}
                              alt={video.title}
                              className="object-cover w-full h-full"
                            />
                            <div className="absolute inset-0 flex items-center justify-center">
                              <div className="h-12 w-12 rounded-full bg-black/70 flex items-center justify-center">
                                <svg className="h-6 w-6 text-white" fill="currentColor" viewBox="0 0 24 24">
                                  <path d="M8 5v14l11-7z" />
                                </svg>
                              </div>
                            </div>
                          </div>
                          <p className="font-medium">{video.title}</p>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                  {isCurrentUser && (
                    <CardFooter>
                      <VideoImportDialog
                        buttonLabel="Import Video from YouTube/Vimeo"
                        buttonVariant="outline"
                        className="w-full"
                        onSuccess={(url, title, platform) => {
                          toast({
                            title: "Video Imported",
                            description: `Successfully imported ${title} from ${platform}`,
                          })
                        }}
                      />
                    </CardFooter>
                  )}
                </Card>
              </TabsContent>

              <TabsContent value="performances" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Past Performances</CardTitle>
                    <CardDescription>Your performance history</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {artistData.pastGigs.map((gig: any, index: number) => (
                        <div key={index} className="border-b pb-4 last:border-0 last:pb-0">
                          <div className="flex justify-between items-start">
                            <div>
                              <h3 className="font-medium">{gig.title}</h3>
                              <p className="text-sm text-muted-foreground">{gig.location}</p>
                            </div>
                            <Badge variant="outline">
                              {new Date(gig.date).toLocaleDateString("en-US", {
                                year: "numeric",
                                month: "short",
                                day: "numeric",
                              })}
                            </Badge>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                  {isCurrentUser && (
                    <CardFooter>
                      <Button variant="outline" className="w-full">
                        <Calendar className="mr-2 h-4 w-4" />
                        Add Past Performance
                      </Button>
                    </CardFooter>
                  )}
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Mic className="mr-2 h-5 w-5" />
                      Performance Types
                    </CardTitle>
                    <CardDescription>Types of events you perform at</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {artistData.performanceTypes.map((type: string) => (
                        <div key={type} className="flex items-start space-x-3">
                          <div className="h-10 w-10 rounded-md bg-primary/10 flex items-center justify-center">
                            {type === "live-band" ? (
                              <Users className="h-5 w-5 text-primary" />
                            ) : type === "festival" ? (
                              <Music className="h-5 w-5 text-primary" />
                            ) : (
                              <Mic className="h-5 w-5 text-primary" />
                            )}
                          </div>
                          <div>
                            <p className="font-medium">
                              {type
                                .split("-")
                                .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
                                .join(" ")}
                            </p>
                            <p className="text-sm text-muted-foreground">
                              {type === "live-band"
                                ? "Full band performances at venues"
                                : type === "festival"
                                  ? "Festival and large event performances"
                                  : type === "corporate"
                                    ? "Corporate and private events"
                                    : "Various performance types"}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="cultural" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Globe className="mr-2 h-5 w-5" />
                      Cultural Heritage
                    </CardTitle>
                    <CardDescription>Showcase your cultural background and influences</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-6">
                      <div>
                        <h3 className="text-sm font-medium mb-2">Cultural Background</h3>
                        <p>
                          {artistData.culturalAffiliations} traditions heavily influence my musical style and
                          performance. My connection to my heritage is a central part of my artistic identity and
                          creative expression.
                        </p>
                      </div>

                      <div>
                        <h3 className="text-sm font-medium mb-2">Traditional Instruments</h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          {artistData.traditionalInstruments.map((instrument: string) => (
                            <div key={instrument} className="flex items-center space-x-3">
                              <div className="h-10 w-10 rounded-md bg-primary/10 flex items-center justify-center">
                                <Drum className="h-5 w-5 text-primary" />
                              </div>
                              <div>
                                <p className="font-medium">
                                  {instrument
                                    .split("-")
                                    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
                                    .join(" ")}
                                </p>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>

                      <div>
                        <h3 className="text-sm font-medium mb-2">Languages</h3>
                        <div className="flex flex-wrap gap-2">
                          {artistData.languages.map((language: string) => (
                            <div key={language} className="flex items-center space-x-2 border rounded-md px-3 py-1">
                              <Languages className="h-4 w-4 text-muted-foreground" />
                              <span>{language.charAt(0).toUpperCase() + language.slice(1)}</span>
                            </div>
                          ))}
                        </div>
                      </div>

                      <div>
                        <h3 className="text-sm font-medium mb-2">Diaspora Connections</h3>
                        <p>
                          My music has reached and connected with African diaspora communities in{" "}
                          {artistData.diasporaConnections}. These connections have enriched my musical journey and
                          expanded my artistic horizons.
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="reviews" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Reviews & Testimonials</CardTitle>
                    <CardDescription>What promoters and venues say about you</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-6">
                      <div className="border-b pb-4">
                        <div className="flex items-center mb-2">
                          <div className="flex mr-2">
                            {[1, 2, 3, 4, 5].map((star) => (
                              <svg key={star} className="w-4 h-4 text-yellow-400 fill-current" viewBox="0 0 24 24">
                                <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" />
                              </svg>
                            ))}
                          </div>
                          <span className="text-sm font-medium">Lagos Jazz Festival</span>
                        </div>
                        <p className="text-sm">
                          "Femi's performance was the highlight of our festival. His fusion of traditional African
                          rhythms with contemporary jazz captivated our audience. His band's energy was infectious and
                          their technical skill was impressive."
                        </p>
                        <p className="text-sm text-muted-foreground mt-1">November 2024</p>
                      </div>

                      <div className="border-b pb-4">
                        <div className="flex items-center mb-2">
                          <div className="flex mr-2">
                            {[1, 2, 3, 4, 5].map((star) => (
                              <svg key={star} className="w-4 h-4 text-yellow-400 fill-current" viewBox="0 0 24 24">
                                <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" />
                              </svg>
                            ))}
                          </div>
                          <span className="text-sm font-medium">Cultural Exchange Program, Nairobi</span>
                        </div>
                        <p className="text-sm">
                          "Working with Femi and his band was a pleasure. They were professional, punctual, and
                          delivered an outstanding performance that beautifully represented West African musical
                          traditions while creating bridges with East African sounds."
                        </p>
                        <p className="text-sm text-muted-foreground mt-1">September 2024</p>
                      </div>

                      <div>
                        <div className="flex items-center mb-2">
                          <div className="flex mr-2">
                            {[1, 2, 3, 4].map((star) => (
                              <svg key={star} className="w-4 h-4 text-yellow-400 fill-current" viewBox="0 0 24 24">
                                <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" />
                              </svg>
                            ))}
                            <svg className="w-4 h-4 text-gray-300 fill-current" viewBox="0 0 24 24">
                              <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" />
                            </svg>
                          </div>
                          <span className="text-sm font-medium">African Unity Concert, Johannesburg</span>
                        </div>
                        <p className="text-sm">
                          "Femi's performance was well-received by our audience. His blend of traditional and
                          contemporary African sounds created a unique atmosphere. The only challenge was some technical
                          issues with sound equipment, but the band adapted professionally."
                        </p>
                        <p className="text-sm text-muted-foreground mt-1">May 2024</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </div>
  )
}
