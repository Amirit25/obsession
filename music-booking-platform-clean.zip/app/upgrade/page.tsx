"use client"

import { useState, useEffect } from "react"
import { Check, HelpCircle, Loader2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Separator } from "@/components/ui/separator"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { toast } from "@/hooks/use-toast"
import { useSearchParams } from "next/navigation"
import { createCheckoutSession } from "@/app/actions/stripe-actions"

export default function UpgradePage() {
  const [billingCycle, setBillingCycle] = useState<"monthly" | "yearly">("monthly")
  const [selectedPlan, setSelectedPlan] = useState<"pro" | "business">("pro")

  const [isLoading, setIsLoading] = useState(false)
  const searchParams = useSearchParams()

  useEffect(() => {
    // Check if the URL has success or canceled params
    const success = searchParams.get("success")
    const canceled = searchParams.get("canceled")
    const sessionId = searchParams.get("session_id")

    if (success && sessionId) {
      console.log("Subscription successful! Session ID:", sessionId)
      toast({
        title: "Subscription successful!",
        description: "Thank you for upgrading your account.",
      })
    } else if (canceled) {
      toast({
        title: "Subscription canceled",
        description: "You can upgrade your account anytime.",
        variant: "destructive",
      })
    }
  }, [searchParams])

  const handleUpgrade = async () => {
    setIsLoading(true)
    console.log("Starting subscription upgrade process...")

    // Define price IDs based on plan and billing cycle
    // Note: These should be PRICE IDs (starting with price_), not product IDs
    const priceIds = {
      pro: {
        // Replace these with actual price IDs from your Stripe dashboard
        monthly: "price_pro_monthly", // Create this price for product prod_SK5O5SOFPQhFJq
        yearly: "price_pro_yearly", // Create this price for product prod_SK5O5SOFPQhFJq
      },
      business: {
        // Replace these with actual price IDs from your Stripe dashboard
        monthly: "price_business_monthly", // Create this price for product prod_SK5OHsMfCjdK8v
        yearly: "price_business_yearly", // Create this price for product prod_SK5OHsMfCjdK8v
      },
    }

    try {
      console.log("Selected plan:", selectedPlan, "Billing cycle:", billingCycle)
      console.log("Using price ID:", priceIds[selectedPlan][billingCycle])

      const result = await createCheckoutSession({
        priceId: priceIds[selectedPlan][billingCycle],
        planName: selectedPlan.toUpperCase(),
        billingCycle,
        returnUrl: window.location.href.split("?")[0], // Remove any existing query params
      })

      console.log("Checkout session result:", result)

      if (result.error) {
        console.error("Checkout error:", result.error)
        toast({
          title: "Error",
          description: result.error,
          variant: "destructive",
        })
      } else if (result.url) {
        console.log("Redirecting to Stripe checkout:", result.url)
        // Redirect to Stripe Checkout
        window.location.href = result.url
      }
    } catch (error: any) {
      console.error("Subscription upgrade error:", error)
      toast({
        title: "Error",
        description: error.message || "Something went wrong",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  // Rest of the component remains the same
  return (
    <div className="container max-w-6xl py-10">
      <div className="mx-auto mb-10 text-center">
        <h1 className="text-3xl font-bold tracking-tight">Upgrade Your ArtistPulse Experience</h1>
        <p className="mt-2 text-muted-foreground">
          Choose the plan that best fits your needs and take your music career to the next level
        </p>
      </div>

      <div className="mb-8 flex justify-center">
        <Tabs
          defaultValue="monthly"
          className="w-[400px]"
          onValueChange={(v) => setBillingCycle(v as "monthly" | "yearly")}
        >
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="monthly">Monthly</TabsTrigger>
            <TabsTrigger value="yearly">
              Yearly <Badge className="ml-2 bg-green-500 hover:bg-green-600">Save 20%</Badge>
            </TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Free Plan */}
        <Card className={`border-muted`}>
          <CardHeader>
            <CardTitle>Free</CardTitle>
            <CardDescription>Basic features for individual artists</CardDescription>
            <div className="mt-4">
              <span className="text-3xl font-bold">$0</span>
              <span className="text-muted-foreground">/month</span>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground">Includes:</p>
            <ul className="space-y-2 text-sm">
              <li className="flex items-center">
                <Check className="mr-2 h-4 w-4 text-green-500" />
                <span>Basic analytics dashboard</span>
              </li>
              <li className="flex items-center">
                <Check className="mr-2 h-4 w-4 text-green-500" />
                <span>Connect up to 3 platforms</span>
              </li>
              <li className="flex items-center">
                <Check className="mr-2 h-4 w-4 text-green-500" />
                <span>7-day data history</span>
              </li>
              <li className="flex items-center">
                <Check className="mr-2 h-4 w-4 text-green-500" />
                <span>Basic resources library</span>
              </li>
            </ul>
          </CardContent>
          <CardFooter>
            <Button variant="outline" className="w-full" disabled>
              Current Plan
            </Button>
          </CardFooter>
        </Card>

        {/* Pro Plan */}
        <Card className={`${selectedPlan === "pro" ? "border-primary" : "border-muted"} relative`}>
          {selectedPlan === "pro" && (
            <div className="absolute -top-3 left-0 right-0 mx-auto w-fit rounded-full bg-primary px-3 py-1 text-xs font-medium text-primary-foreground">
              Selected
            </div>
          )}
          <CardHeader>
            <CardTitle>Pro</CardTitle>
            <CardDescription>Advanced features for growing artists</CardDescription>
            <div className="mt-4">
              <span className="text-3xl font-bold">${billingCycle === "monthly" ? "19.99" : "15.99"}</span>
              <span className="text-muted-foreground">/month</span>
              {billingCycle === "yearly" && (
                <Badge variant="outline" className="ml-2 text-green-500">
                  Billed annually
                </Badge>
              )}
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground">Everything in Free, plus:</p>
            <ul className="space-y-2 text-sm">
              <li className="flex items-center">
                <Check className="mr-2 h-4 w-4 text-green-500" />
                <span>Advanced analytics with insights</span>
              </li>
              <li className="flex items-center">
                <Check className="mr-2 h-4 w-4 text-green-500" />
                <span>Connect unlimited platforms</span>
              </li>
              <li className="flex items-center">
                <Check className="mr-2 h-4 w-4 text-green-500" />
                <span>1-year data history</span>
              </li>
              <li className="flex items-center">
                <Check className="mr-2 h-4 w-4 text-green-500" />
                <span>Full resources library</span>
              </li>
              <li className="flex items-center">
                <Check className="mr-2 h-4 w-4 text-green-500" />
                <span>Custom reports and exports</span>
              </li>
              <li className="flex items-center">
                <Check className="mr-2 h-4 w-4 text-green-500" />
                <span>Priority support</span>
              </li>
            </ul>
          </CardContent>
          <CardFooter>
            <RadioGroup
              value={selectedPlan}
              className="w-full"
              onValueChange={(v) => setSelectedPlan(v as "pro" | "business")}
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="pro" id="pro" />
                <Label htmlFor="pro" className="flex-1 cursor-pointer">
                  Select Pro Plan
                </Label>
              </div>
            </RadioGroup>
          </CardFooter>
        </Card>

        {/* Business Plan */}
        <Card className={`${selectedPlan === "business" ? "border-primary" : "border-muted"} relative`}>
          {selectedPlan === "business" && (
            <div className="absolute -top-3 left-0 right-0 mx-auto w-fit rounded-full bg-primary px-3 py-1 text-xs font-medium text-primary-foreground">
              Selected
            </div>
          )}
          <CardHeader>
            <CardTitle>Business</CardTitle>
            <CardDescription>Premium features for professional artists</CardDescription>
            <div className="mt-4">
              <span className="text-3xl font-bold">${billingCycle === "monthly" ? "49.99" : "39.99"}</span>
              <span className="text-muted-foreground">/month</span>
              {billingCycle === "yearly" && (
                <Badge variant="outline" className="ml-2 text-green-500">
                  Billed annually
                </Badge>
              )}
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground">Everything in Pro, plus:</p>
            <ul className="space-y-2 text-sm">
              <li className="flex items-center">
                <Check className="mr-2 h-4 w-4 text-green-500" />
                <span>AI-powered performance predictions</span>
              </li>
              <li className="flex items-center">
                <Check className="mr-2 h-4 w-4 text-green-500" />
                <span>Team collaboration (up to 5 members)</span>
              </li>
              <li className="flex items-center">
                <Check className="mr-2 h-4 w-4 text-green-500" />
                <span>Unlimited data history</span>
              </li>
              <li className="flex items-center">
                <Check className="mr-2 h-4 w-4 text-green-500" />
                <span>Advanced audience insights</span>
              </li>
              <li className="flex items-center">
                <Check className="mr-2 h-4 w-4 text-green-500" />
                <span>Competitor analysis</span>
              </li>
              <li className="flex items-center">
                <Check className="mr-2 h-4 w-4 text-green-500" />
                <span>Dedicated account manager</span>
              </li>
            </ul>
          </CardContent>
          <CardFooter>
            <RadioGroup
              value={selectedPlan}
              className="w-full"
              onValueChange={(v) => setSelectedPlan(v as "pro" | "business")}
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="business" id="business" />
                <Label htmlFor="business" className="flex-1 cursor-pointer">
                  Select Business Plan
                </Label>
              </div>
            </RadioGroup>
          </CardFooter>
        </Card>
      </div>

      <div className="mt-10">
        <Card>
          <CardHeader>
            <CardTitle>Plan Comparison</CardTitle>
            <CardDescription>Detailed feature comparison between plans</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b">
                    <th className="text-left py-3 px-4">Feature</th>
                    <th className="text-center py-3 px-4">Free</th>
                    <th className="text-center py-3 px-4">Pro</th>
                    <th className="text-center py-3 px-4">Business</th>
                  </tr>
                </thead>
                <tbody>
                  <tr className="border-b">
                    <td className="py-3 px-4">
                      <div className="flex items-center">
                        <span>Platform Connections</span>
                        <TooltipProvider>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <HelpCircle className="ml-1 h-4 w-4 text-muted-foreground" />
                            </TooltipTrigger>
                            <TooltipContent>
                              <p>Number of streaming and social platforms you can connect</p>
                            </TooltipContent>
                          </Tooltip>
                        </TooltipProvider>
                      </div>
                    </td>
                    <td className="text-center py-3 px-4">Up to 3</td>
                    <td className="text-center py-3 px-4">Unlimited</td>
                    <td className="text-center py-3 px-4">Unlimited</td>
                  </tr>
                  <tr className="border-b">
                    <td className="py-3 px-4">
                      <div className="flex items-center">
                        <span>Data History</span>
                        <TooltipProvider>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <HelpCircle className="ml-1 h-4 w-4 text-muted-foreground" />
                            </TooltipTrigger>
                            <TooltipContent>
                              <p>How long we store your historical data</p>
                            </TooltipContent>
                          </Tooltip>
                        </TooltipProvider>
                      </div>
                    </td>
                    <td className="text-center py-3 px-4">7 days</td>
                    <td className="text-center py-3 px-4">1 year</td>
                    <td className="text-center py-3 px-4">Unlimited</td>
                  </tr>
                  <tr className="border-b">
                    <td className="py-3 px-4">Analytics Depth</td>
                    <td className="text-center py-3 px-4">Basic</td>
                    <td className="text-center py-3 px-4">Advanced</td>
                    <td className="text-center py-3 px-4">Premium</td>
                  </tr>
                  <tr className="border-b">
                    <td className="py-3 px-4">Custom Reports</td>
                    <td className="text-center py-3 px-4">❌</td>
                    <td className="text-center py-3 px-4">✅</td>
                    <td className="text-center py-3 px-4">✅</td>
                  </tr>
                  <tr className="border-b">
                    <td className="py-3 px-4">Team Members</td>
                    <td className="text-center py-3 px-4">1</td>
                    <td className="text-center py-3 px-4">1</td>
                    <td className="text-center py-3 px-4">Up to 5</td>
                  </tr>
                  <tr className="border-b">
                    <td className="py-3 px-4">AI Insights</td>
                    <td className="text-center py-3 px-4">❌</td>
                    <td className="text-center py-3 px-4">Basic</td>
                    <td className="text-center py-3 px-4">Advanced</td>
                  </tr>
                  <tr>
                    <td className="py-3 px-4">Support</td>
                    <td className="text-center py-3 px-4">Email</td>
                    <td className="text-center py-3 px-4">Priority Email</td>
                    <td className="text-center py-3 px-4">Dedicated Manager</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="mt-10 flex justify-center">
        <div className="max-w-md w-full">
          <Card>
            <CardHeader>
              <CardTitle>Ready to upgrade?</CardTitle>
              <CardDescription>
                Get access to premium features and take your music career to the next level
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between">
                  <span>Plan:</span>
                  <span className="font-medium">{selectedPlan === "pro" ? "Pro" : "Business"}</span>
                </div>
                <div className="flex justify-between">
                  <span>Billing:</span>
                  <span className="font-medium">{billingCycle === "monthly" ? "Monthly" : "Yearly (20% off)"}</span>
                </div>
                <Separator />
                <div className="flex justify-between">
                  <span>Total:</span>
                  <span className="font-medium">
                    $
                    {selectedPlan === "pro"
                      ? billingCycle === "monthly"
                        ? "19.99"
                        : "191.88"
                      : billingCycle === "monthly"
                        ? "49.99"
                        : "479.88"}
                    {billingCycle === "yearly" ? "/year" : "/month"}
                  </span>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button className="w-full" onClick={handleUpgrade} disabled={isLoading}>
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Processing...
                  </>
                ) : (
                  "Upgrade Now"
                )}
              </Button>
            </CardFooter>
          </Card>
        </div>
      </div>

      <div className="mt-10 text-center">
        <h2 className="text-xl font-semibold mb-2">Frequently Asked Questions</h2>
        <div className="max-w-3xl mx-auto mt-6 space-y-4">
          <div>
            <h3 className="font-medium">Can I change plans later?</h3>
            <p className="text-sm text-muted-foreground mt-1">
              Yes, you can upgrade, downgrade, or cancel your plan at any time from your account settings.
            </p>
          </div>
          <div>
            <h3 className="font-medium">Is there a free trial for paid plans?</h3>
            <p className="text-sm text-muted-foreground mt-1">
              Yes, we offer a 14-day free trial for both Pro and Business plans. No credit card required.
            </p>
          </div>
          <div>
            <h3 className="font-medium">What payment methods do you accept?</h3>
            <p className="text-sm text-muted-foreground mt-1">
              We accept all major credit cards, PayPal, and Apple Pay.
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
