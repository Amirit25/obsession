"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/contexts/auth-context"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { toast } from "@/hooks/use-toast"
import { AlertCircle, CheckCircle, Clock, CreditCard, FileText, Loader2, RefreshCw } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import Link from "next/link"
import {
  cancelSubscription,
  reactivateSubscription,
  getSubscriptionInvoices,
  getUpcomingInvoice,
} from "@/app/actions/stripe-actions"
import { getSupabaseBrowserClient } from "@/lib/supabase"

export default function SubscriptionPage() {
  const { user, profile, isLoading: authLoading } = useAuth()
  const [subscriptionData, setSubscriptionData] = useState<any>(null)
  const [invoices, setInvoices] = useState<any[]>([])
  const [upcomingInvoice, setUpcomingInvoice] = useState<any>(null)
  const [subscriptionHistory, setSubscriptionHistory] = useState<any[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isCanceling, setIsCanceling] = useState(false)
  const [isReactivating, setIsReactivating] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const router = useRouter()

  useEffect(() => {
    // Only run in the browser
    if (typeof window === "undefined") return

    const fetchSubscriptionData = async () => {
      if (!user || !profile) return

      try {
        setIsLoading(true)
        setError(null)

        const supabase = getSupabaseBrowserClient()

        // Fetch invoices
        const { data: invoiceData, error: invoiceError } = await getSubscriptionInvoices()
        if (invoiceError) {
          console.error("Error fetching invoices:", invoiceError)
        } else if (invoiceData) {
          setInvoices(invoiceData)
        }

        // Fetch upcoming invoice if subscription is active
        if (profile.subscription_status === "active" || profile.subscription_status === "canceling") {
          const { data: upcomingData, error: upcomingError } = await getUpcomingInvoice()
          if (upcomingError) {
            console.error("Error fetching upcoming invoice:", upcomingError)
          } else if (upcomingData) {
            setUpcomingInvoice(upcomingData)
          }
        }

        // Fetch subscription history with proper error handling
        const { data: historyData, error: historyError } = await supabase
          .from("subscription_history")
          .select("*")
          .eq("profile_id", profile.id)
          .order("created_at", { ascending: false })

        if (historyError) {
          console.error("Error fetching subscription history:", historyError)
          throw new Error(`Failed to fetch subscription history: ${historyError.message}`)
        } else {
          setSubscriptionHistory(historyData || [])
        }

        // Set subscription data from profile
        setSubscriptionData({
          status: profile.subscription_status || "free",
          plan: profile.subscription_plan || "free",
          periodEnd: profile.subscription_period_end,
          createdAt: profile.subscription_created_at,
        })
      } catch (error: any) {
        console.error("Error fetching subscription data:", error)
        setError(error.message || "Failed to load subscription data")
        toast({
          title: "Error",
          description: error.message || "Failed to load subscription data",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }

    if (user && profile && !authLoading) {
      fetchSubscriptionData()
    } else if (!authLoading && !user) {
      router.push("/auth/login")
    }
  }, [user, profile, authLoading, router])

  const handleCancelSubscription = async () => {
    try {
      setIsCanceling(true)
      const { success, error, message } = await cancelSubscription()

      if (error) {
        toast({
          title: "Error",
          description: error,
          variant: "destructive",
        })
        return
      }

      if (success) {
        toast({
          title: "Subscription Canceled",
          description: message,
        })

        // Update local state
        setSubscriptionData({
          ...subscriptionData,
          status: "canceling",
        })
      }
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to cancel subscription",
        variant: "destructive",
      })
    } finally {
      setIsCanceling(false)
    }
  }

  const handleReactivateSubscription = async () => {
    try {
      setIsReactivating(true)
      const { success, error, message } = await reactivateSubscription()

      if (error) {
        toast({
          title: "Error",
          description: error,
          variant: "destructive",
        })
        return
      }

      if (success) {
        toast({
          title: "Subscription Reactivated",
          description: message,
        })

        // Update local state
        setSubscriptionData({
          ...subscriptionData,
          status: "active",
        })
      }
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to reactivate subscription",
        variant: "destructive",
      })
    } finally {
      setIsReactivating(false)
    }
  }

  if (authLoading || isLoading) {
    return (
      <div className="container mx-auto py-10 flex justify-center items-center min-h-[60vh]">
        <div className="flex flex-col items-center gap-2">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <p className="text-muted-foreground">Loading subscription data...</p>
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="container mx-auto py-10">
        <Alert variant="destructive" className="mb-6">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
        <Button onClick={() => window.location.reload()}>Try Again</Button>
      </div>
    )
  }

  if (!user || !profile) {
    return null // Router will redirect to login
  }

  const formatDate = (dateString: string) => {
    if (!dateString) return "N/A"
    return new Date(dateString).toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    })
  }

  const formatCurrency = (amount: number, currency: string) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: currency.toUpperCase(),
    }).format(amount)
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "active":
        return <Badge className="bg-green-500">Active</Badge>
      case "canceling":
        return <Badge className="bg-yellow-500">Canceling</Badge>
      case "canceled":
        return <Badge className="bg-red-500">Canceled</Badge>
      case "free":
        return <Badge className="bg-gray-500">Free Plan</Badge>
      default:
        return <Badge>{status}</Badge>
    }
  }

  const getPlanBadge = (plan: string) => {
    switch (plan) {
      case "pro":
        return <Badge className="bg-blue-500">Pro</Badge>
      case "business":
        return <Badge className="bg-purple-500">Business</Badge>
      case "free":
        return <Badge className="bg-gray-500">Free</Badge>
      default:
        return <Badge>{plan}</Badge>
    }
  }

  const getEventTypeBadge = (eventType: string) => {
    switch (eventType) {
      case "subscription_created":
        return <Badge className="bg-green-500">Subscription Created</Badge>
      case "payment_succeeded":
        return <Badge className="bg-blue-500">Payment Succeeded</Badge>
      case "subscription_updated":
        return <Badge className="bg-yellow-500">Subscription Updated</Badge>
      case "subscription_canceled":
        return <Badge className="bg-red-500">Subscription Canceled</Badge>
      default:
        return <Badge>{eventType}</Badge>
    }
  }

  return (
    <div className="container mx-auto py-10">
      <div className="mb-8">
        <h1 className="text-3xl font-bold tracking-tight">Subscription Management</h1>
        <p className="text-muted-foreground mt-2">
          View and manage your subscription details, billing history, and plan options
        </p>
      </div>

      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="billing">Billing History</TabsTrigger>
          <TabsTrigger value="history">Subscription History</TabsTrigger>
          <TabsTrigger value="features">Plan Features</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>Current Subscription</span>
                {getStatusBadge(subscriptionData?.status || "free")}
              </CardTitle>
              <CardDescription>Your current plan and subscription details</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Plan</h3>
                  <p className="text-lg font-semibold flex items-center gap-2">
                    {subscriptionData?.plan ? (
                      <>
                        {subscriptionData.plan.charAt(0).toUpperCase() + subscriptionData.plan.slice(1)}
                        {getPlanBadge(subscriptionData.plan)}
                      </>
                    ) : (
                      "Free Plan"
                    )}
                  </p>
                </div>

                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Status</h3>
                  <p className="text-lg font-semibold capitalize">{subscriptionData?.status || "free"}</p>
                </div>

                {subscriptionData?.status !== "free" && (
                  <>
                    <div>
                      <h3 className="text-sm font-medium text-muted-foreground">Started On</h3>
                      <p className="text-lg font-semibold">{formatDate(subscriptionData?.createdAt)}</p>
                    </div>

                    <div>
                      <h3 className="text-sm font-medium text-muted-foreground">
                        {subscriptionData?.status === "canceling" ? "Ends On" : "Current Period Ends"}
                      </h3>
                      <p className="text-lg font-semibold">{formatDate(subscriptionData?.periodEnd)}</p>
                    </div>
                  </>
                )}
              </div>

              {subscriptionData?.status === "canceling" && (
                <Alert className="bg-yellow-50 border-yellow-200 text-yellow-800 dark:bg-yellow-900/20 dark:border-yellow-900 dark:text-yellow-400">
                  <Clock className="h-4 w-4" />
                  <AlertTitle>Subscription Canceling</AlertTitle>
                  <AlertDescription>
                    Your subscription will remain active until {formatDate(subscriptionData?.periodEnd)}, after which
                    you'll be moved to the Free plan.
                  </AlertDescription>
                </Alert>
              )}

              {subscriptionData?.status === "active" && upcomingInvoice && (
                <div className="bg-gray-50 dark:bg-gray-800/50 p-4 rounded-md">
                  <h3 className="font-medium mb-2 flex items-center gap-2">
                    <CreditCard className="h-4 w-4" />
                    Upcoming Payment
                  </h3>
                  <p>
                    Your next payment of {formatCurrency(upcomingInvoice.amount, upcomingInvoice.currency)} will be
                    processed on {formatDate(upcomingInvoice.next_payment_attempt || upcomingInvoice.period_end)}.
                  </p>
                </div>
              )}
            </CardContent>
            <CardFooter className="flex flex-col sm:flex-row gap-3">
              {subscriptionData?.status === "free" && (
                <Button asChild className="w-full sm:w-auto">
                  <Link href="/upgrade">Upgrade Plan</Link>
                </Button>
              )}

              {subscriptionData?.status === "active" && (
                <Dialog>
                  <DialogTrigger asChild>
                    <Button variant="outline" className="w-full sm:w-auto">
                      Cancel Subscription
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Cancel Subscription</DialogTitle>
                      <DialogDescription>
                        Are you sure you want to cancel your subscription? You'll still have access to your current plan
                        until the end of your billing period.
                      </DialogDescription>
                    </DialogHeader>
                    <div className="py-4">
                      <Alert variant="destructive">
                        <AlertCircle className="h-4 w-4" />
                        <AlertTitle>Important</AlertTitle>
                        <AlertDescription>
                          After cancellation, your subscription will remain active until{" "}
                          {formatDate(subscriptionData?.periodEnd)}. After that date, you'll be moved to the Free plan.
                        </AlertDescription>
                      </Alert>
                    </div>
                    <DialogFooter>
                      <Button variant="ghost" onClick={() => {}}>
                        Cancel
                      </Button>
                      <Button variant="destructive" onClick={handleCancelSubscription} disabled={isCanceling}>
                        {isCanceling ? (
                          <>
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                            Processing...
                          </>
                        ) : (
                          "Confirm Cancellation"
                        )}
                      </Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              )}

              {subscriptionData?.status === "canceling" && (
                <Button onClick={handleReactivateSubscription} className="w-full sm:w-auto" disabled={isReactivating}>
                  {isReactivating ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Processing...
                    </>
                  ) : (
                    <>
                      <RefreshCw className="mr-2 h-4 w-4" />
                      Reactivate Subscription
                    </>
                  )}
                </Button>
              )}

              {subscriptionData?.status !== "free" && (
                <Button variant="outline" asChild className="w-full sm:w-auto">
                  <Link href="/upgrade">Change Plan</Link>
                </Button>
              )}
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="billing" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Billing History</CardTitle>
              <CardDescription>View your past invoices and payment history</CardDescription>
            </CardHeader>
            <CardContent>
              {invoices.length === 0 ? (
                <div className="text-center py-8">
                  <p className="text-muted-foreground">No billing history available</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left py-3 px-4">Date</th>
                        <th className="text-left py-3 px-4">Amount</th>
                        <th className="text-left py-3 px-4">Status</th>
                        <th className="text-left py-3 px-4">Period</th>
                        <th className="text-left py-3 px-4">Invoice</th>
                      </tr>
                    </thead>
                    <tbody>
                      {invoices.map((invoice) => (
                        <tr key={invoice.id} className="border-b">
                          <td className="py-3 px-4">{formatDate(invoice.created)}</td>
                          <td className="py-3 px-4">{formatCurrency(invoice.amount, invoice.currency)}</td>
                          <td className="py-3 px-4 capitalize">
                            {invoice.status === "paid" ? (
                              <span className="flex items-center gap-1 text-green-600">
                                <CheckCircle className="h-4 w-4" />
                                Paid
                              </span>
                            ) : (
                              invoice.status
                            )}
                          </td>
                          <td className="py-3 px-4">
                            {formatDate(invoice.period_start)} - {formatDate(invoice.period_end)}
                          </td>
                          <td className="py-3 px-4">
                            <Button variant="ghost" size="sm" asChild>
                              <a href={invoice.invoice_url} target="_blank" rel="noopener noreferrer">
                                <FileText className="h-4 w-4 mr-1" />
                                View
                              </a>
                            </Button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="history" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Subscription History</CardTitle>
              <CardDescription>View your subscription events and changes</CardDescription>
            </CardHeader>
            <CardContent>
              {subscriptionHistory.length === 0 ? (
                <div className="text-center py-8">
                  <p className="text-muted-foreground">No subscription history available</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left py-3 px-4">Date</th>
                        <th className="text-left py-3 px-4">Event</th>
                        <th className="text-left py-3 px-4">Plan</th>
                        <th className="text-left py-3 px-4">Status</th>
                        <th className="text-left py-3 px-4">Amount</th>
                      </tr>
                    </thead>
                    <tbody>
                      {subscriptionHistory.map((event) => (
                        <tr key={event.id} className="border-b">
                          <td className="py-3 px-4">{formatDate(event.created_at)}</td>
                          <td className="py-3 px-4">{getEventTypeBadge(event.event_type)}</td>
                          <td className="py-3 px-4 capitalize">{event.plan || "N/A"}</td>
                          <td className="py-3 px-4 capitalize">{event.status || "N/A"}</td>
                          <td className="py-3 px-4">
                            {event.amount && event.currency ? formatCurrency(event.amount, event.currency) : "N/A"}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="features" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Plan Features</CardTitle>
              <CardDescription>Features and limits included in your current plan</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-medium mb-4">
                    Your{" "}
                    {subscriptionData?.plan
                      ? subscriptionData.plan.charAt(0).toUpperCase() + subscriptionData.plan.slice(1)
                      : "Free"}{" "}
                    Plan Includes:
                  </h3>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* Free Plan Features */}
                    {(!subscriptionData?.plan || subscriptionData.plan === "free") && (
                      <>
                        <div className="flex items-start gap-2">
                          <CheckCircle className="h-5 w-5 text-green-500 mt-0.5" />
                          <div>
                            <p className="font-medium">Basic Analytics</p>
                            <p className="text-sm text-muted-foreground">Access to basic analytics dashboard</p>
                          </div>
                        </div>
                        <div className="flex items-start gap-2">
                          <CheckCircle className="h-5 w-5 text-green-500 mt-0.5" />
                          <div>
                            <p className="font-medium">Limited Connections</p>
                            <p className="text-sm text-muted-foreground">Connect up to 3 platforms</p>
                          </div>
                        </div>
                        <div className="flex items-start gap-2">
                          <CheckCircle className="h-5 w-5 text-green-500 mt-0.5" />
                          <div>
                            <p className="font-medium">7-Day Data History</p>
                            <p className="text-sm text-muted-foreground">Access to last 7 days of data</p>
                          </div>
                        </div>
                        <div className="flex items-start gap-2">
                          <CheckCircle className="h-5 w-5 text-green-500 mt-0.5" />
                          <div>
                            <p className="font-medium">Basic Resources</p>
                            <p className="text-sm text-muted-foreground">Access to basic resources library</p>
                          </div>
                        </div>
                      </>
                    )}

                    {/* Pro Plan Features */}
                    {subscriptionData?.plan === "pro" && (
                      <>
                        <div className="flex items-start gap-2">
                          <CheckCircle className="h-5 w-5 text-green-500 mt-0.5" />
                          <div>
                            <p className="font-medium">Advanced Analytics</p>
                            <p className="text-sm text-muted-foreground">Access to advanced analytics with insights</p>
                          </div>
                        </div>
                        <div className="flex items-start gap-2">
                          <CheckCircle className="h-5 w-5 text-green-500 mt-0.5" />
                          <div>
                            <p className="font-medium">Unlimited Connections</p>
                            <p className="text-sm text-muted-foreground">Connect unlimited platforms</p>
                          </div>
                        </div>
                        <div className="flex items-start gap-2">
                          <CheckCircle className="h-5 w-5 text-green-500 mt-0.5" />
                          <div>
                            <p className="font-medium">1-Year Data History</p>
                            <p className="text-sm text-muted-foreground">Access to 1 year of historical data</p>
                          </div>
                        </div>
                        <div className="flex items-start gap-2">
                          <CheckCircle className="h-5 w-5 text-green-500 mt-0.5" />
                          <div>
                            <p className="font-medium">Full Resources</p>
                            <p className="text-sm text-muted-foreground">Access to full resources library</p>
                          </div>
                        </div>
                        <div className="flex items-start gap-2">
                          <CheckCircle className="h-5 w-5 text-green-500 mt-0.5" />
                          <div>
                            <p className="font-medium">Custom Reports</p>
                            <p className="text-sm text-muted-foreground">Create and export custom reports</p>
                          </div>
                        </div>
                        <div className="flex items-start gap-2">
                          <CheckCircle className="h-5 w-5 text-green-500 mt-0.5" />
                          <div>
                            <p className="font-medium">Priority Support</p>
                            <p className="text-sm text-muted-foreground">Get priority email support</p>
                          </div>
                        </div>
                      </>
                    )}

                    {/* Business Plan Features */}
                    {subscriptionData?.plan === "business" && (
                      <>
                        <div className="flex items-start gap-2">
                          <CheckCircle className="h-5 w-5 text-green-500 mt-0.5" />
                          <div>
                            <p className="font-medium">Premium Analytics</p>
                            <p className="text-sm text-muted-foreground">
                              Access to premium analytics with AI insights
                            </p>
                          </div>
                        </div>
                        <div className="flex items-start gap-2">
                          <CheckCircle className="h-5 w-5 text-green-500 mt-0.5" />
                          <div>
                            <p className="font-medium">Unlimited Connections</p>
                            <p className="text-sm text-muted-foreground">Connect unlimited platforms</p>
                          </div>
                        </div>
                        <div className="flex items-start gap-2">
                          <CheckCircle className="h-5 w-5 text-green-500 mt-0.5" />
                          <div>
                            <p className="font-medium">Unlimited Data History</p>
                            <p className="text-sm text-muted-foreground">Access to unlimited historical data</p>
                          </div>
                        </div>
                        <div className="flex items-start gap-2">
                          <CheckCircle className="h-5 w-5 text-green-500 mt-0.5" />
                          <div>
                            <p className="font-medium">Team Collaboration</p>
                            <p className="text-sm text-muted-foreground">Add up to 5 team members</p>
                          </div>
                        </div>
                        <div className="flex items-start gap-2">
                          <CheckCircle className="h-5 w-5 text-green-500 mt-0.5" />
                          <div>
                            <p className="font-medium">Advanced Audience Insights</p>
                            <p className="text-sm text-muted-foreground">Get detailed audience analytics</p>
                          </div>
                        </div>
                        <div className="flex items-start gap-2">
                          <CheckCircle className="h-5 w-5 text-green-500 mt-0.5" />
                          <div>
                            <p className="font-medium">Competitor Analysis</p>
                            <p className="text-sm text-muted-foreground">Compare your performance with competitors</p>
                          </div>
                        </div>
                        <div className="flex items-start gap-2">
                          <CheckCircle className="h-5 w-5 text-green-500 mt-0.5" />
                          <div>
                            <p className="font-medium">Dedicated Account Manager</p>
                            <p className="text-sm text-muted-foreground">
                              Get personalized support from a dedicated manager
                            </p>
                          </div>
                        </div>
                      </>
                    )}
                  </div>
                </div>

                <Separator />

                <div className="text-center">
                  <h3 className="text-lg font-medium mb-4">Looking for more?</h3>
                  <p className="text-muted-foreground mb-4">
                    {subscriptionData?.plan === "free"
                      ? "Upgrade to a paid plan to unlock more features and capabilities."
                      : subscriptionData?.plan === "pro"
                        ? "Upgrade to our Business plan for premium features and team collaboration."
                        : "You're on our highest tier plan. Enjoy all the premium features!"}
                  </p>

                  {subscriptionData?.plan !== "business" && (
                    <Button asChild>
                      <Link href="/upgrade">
                        {subscriptionData?.plan === "free" ? "Upgrade Now" : "Upgrade to Business"}
                      </Link>
                    </Button>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
