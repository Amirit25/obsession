import Link from "next/link"
import { Button } from "@/components/ui/button"

export default function LandingPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <main className="flex-1">
        <section className="py-20">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto text-center">
              <h1 className="text-4xl md:text-5xl font-bold mb-6">Your Music Career Dashboard</h1>
              <p className="text-xl mb-8 text-muted-foreground">
                Track your music career growth and performance metrics across all platforms
              </p>
              <div className="flex flex-col sm:flex-row justify-center gap-4">
                <Link href="/auth/register">
                  <Button size="lg">Get Started</Button>
                </Link>
                <Link href="/auth/login">
                  <Button size="lg" variant="outline">
                    Login
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </section>

        <section className="py-20 bg-muted/50">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12">Features</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="bg-card rounded-lg p-6 shadow-sm">
                <h3 className="text-xl font-bold mb-3">Analytics Dashboard</h3>
                <p className="text-muted-foreground">
                  Track your performance across Spotify, Apple Music, YouTube, and more from a single dashboard.
                </p>
              </div>
              <div className="bg-card rounded-lg p-6 shadow-sm">
                <h3 className="text-xl font-bold mb-3">Audience Insights</h3>
                <p className="text-muted-foreground">
                  Understand who your listeners are, where they're located, and how they discover your music.
                </p>
              </div>
              <div className="bg-card rounded-lg p-6 shadow-sm">
                <h3 className="text-xl font-bold mb-3">Booking Management</h3>
                <p className="text-muted-foreground">
                  Manage your bookings, events, and performances all in one place.
                </p>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t py-6">
        <div className="container mx-auto px-4 text-center text-sm text-muted-foreground">
          &copy; {new Date().getFullYear()} obsession. All rights reserved.
        </div>
      </footer>
    </div>
  )
}
