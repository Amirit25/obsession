"use client"

import { useState, useEffect } from "react"
import { useAuth } from "@/contexts/auth-context"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { toast } from "@/hooks/use-toast"
import { Loader2, Plus, Save, Trash2 } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { getSupabaseBrowserClient } from "@/lib/supabase"

export default function AdminSubscriptionPage() {
  const { user, profile, isLoading: authLoading } = useAuth()
  const [isLoading, setIsLoading] = useState(true)
  const [isAdmin, setIsAdmin] = useState(false)
  const [features, setFeatures] = useState<any[]>([])
  const [subscriptions, setSubscriptions] = useState<any[]>([])
  const [newFeature, setNewFeature] = useState({
    plan: "free",
    feature_key: "",
    feature_value: "",
  })
  const [editingFeature, setEditingFeature] = useState<any>(null)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [error, setError] = useState<string | null>(null)

  // Initialize supabase client only on the client side
  const [supabase, setSupabase] = useState<any>(null)

  useEffect(() => {
    // Only initialize Supabase in the browser
    if (typeof window !== "undefined") {
      try {
        const client = getSupabaseBrowserClient()
        setSupabase(client)
      } catch (err: any) {
        console.error("Failed to initialize Supabase client:", err)
        setError("Failed to initialize database connection")
        setIsLoading(false)
      }
    } else {
      // During SSR, set loading to false to avoid hydration issues
      setIsLoading(false)
    }
  }, [])

  useEffect(() => {
    // Skip if we're in SSR or if Supabase client isn't initialized
    if (typeof window === "undefined" || !supabase) return

    const checkAdminStatus = async () => {
      if (!user) return

      try {
        const { data, error } = await supabase.from("profiles").select("role").eq("user_id", user.id).single()

        if (error) {
          console.error("Error checking admin status:", error)
          return
        }

        setIsAdmin(data?.role === "admin")
      } catch (error) {
        console.error("Error checking admin status:", error)
      }
    }

    const fetchData = async () => {
      if (!user) return

      try {
        setIsLoading(true)

        // Fetch subscription features
        const { data: featuresData, error: featuresError } = await supabase
          .from("subscription_features")
          .select("*")
          .order("plan", { ascending: true })
          .order("feature_key", { ascending: true })

        if (featuresError) {
          console.error("Error fetching features:", featuresError)
          toast({
            title: "Error",
            description: "Failed to load subscription features",
            variant: "destructive",
          })
        } else {
          setFeatures(featuresData || [])
        }

        // Fetch subscription data
        const { data: subscriptionsData, error: subscriptionsError } = await supabase
          .from("profiles")
          .select("id, full_name, email, subscription_status, subscription_plan, subscription_period_end")
          .not("subscription_status", "is", null)

        if (subscriptionsError) {
          console.error("Error fetching subscriptions:", subscriptionsError)
        } else {
          setSubscriptions(subscriptionsData || [])
        }
      } catch (error) {
        console.error("Error fetching data:", error)
        toast({
          title: "Error",
          description: "Failed to load data",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }

    // Only run these effects in the browser, not during build/SSR
    if (user && !authLoading) {
      checkAdminStatus()
      fetchData()
    }
  }, [user, authLoading, supabase])

  const handleAddFeature = async () => {
    if (!supabase) {
      toast({
        title: "Error",
        description: "Database connection not available",
        variant: "destructive",
      })
      return
    }

    try {
      setIsSubmitting(true)

      // Validate inputs
      if (!newFeature.plan || !newFeature.feature_key || !newFeature.feature_value) {
        toast({
          title: "Validation Error",
          description: "All fields are required",
          variant: "destructive",
        })
        return
      }

      // Format feature value as JSON
      let formattedValue
      try {
        // Check if it's a JSON string already
        if (
          (newFeature.feature_value.startsWith("[") && newFeature.feature_value.endsWith("]")) ||
          (newFeature.feature_value.startsWith("{") && newFeature.feature_value.endsWith("}"))
        ) {
          formattedValue = JSON.parse(newFeature.feature_value)
        } else if (
          newFeature.feature_value.toLowerCase() === "true" ||
          newFeature.feature_value.toLowerCase() === "false"
        ) {
          // Handle boolean values
          formattedValue = newFeature.feature_value.toLowerCase() === "true"
        } else if (!isNaN(Number(newFeature.feature_value))) {
          // Handle numeric values
          formattedValue = Number(newFeature.feature_value)
        } else {
          // Handle string values
          formattedValue = newFeature.feature_value
        }
      } catch (e) {
        // If parsing fails, use as string
        formattedValue = newFeature.feature_value
      }

      // Insert new feature
      const { error } = await supabase.from("subscription_features").insert({
        plan: newFeature.plan,
        feature_key: newFeature.feature_key,
        feature_value: formattedValue,
      })

      if (error) {
        console.error("Error adding feature:", error)
        toast({
          title: "Error",
          description: error.message || "Failed to add feature",
          variant: "destructive",
        })
        return
      }

      toast({
        title: "Success",
        description: "Feature added successfully",
      })

      // Reset form and refresh data
      setNewFeature({
        plan: "free",
        feature_key: "",
        feature_value: "",
      })

      // Refresh features list
      const { data: refreshedData } = await supabase
        .from("subscription_features")
        .select("*")
        .order("plan", { ascending: true })
        .order("feature_key", { ascending: true })

      setFeatures(refreshedData || [])
    } catch (error: any) {
      console.error("Error adding feature:", error)
      toast({
        title: "Error",
        description: error.message || "An unexpected error occurred",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleUpdateFeature = async () => {
    if (!editingFeature || !supabase) return

    try {
      setIsSubmitting(true)

      // Format feature value as JSON
      let formattedValue
      try {
        // Check if it's a JSON string already
        if (
          (editingFeature.feature_value.startsWith("[") && editingFeature.feature_value.endsWith("]")) ||
          (editingFeature.feature_value.startsWith("{") && editingFeature.feature_value.endsWith("}"))
        ) {
          formattedValue = JSON.parse(editingFeature.feature_value)
        } else if (
          editingFeature.feature_value.toLowerCase() === "true" ||
          editingFeature.feature_value.toLowerCase() === "false"
        ) {
          // Handle boolean values
          formattedValue = editingFeature.feature_value.toLowerCase() === "true"
        } else if (!isNaN(Number(editingFeature.feature_value))) {
          // Handle numeric values
          formattedValue = Number(editingFeature.feature_value)
        } else {
          // Handle string values
          formattedValue = editingFeature.feature_value
        }
      } catch (e) {
        // If parsing fails, use as string
        formattedValue = editingFeature.feature_value
      }

      // Update feature
      const { error } = await supabase
        .from("subscription_features")
        .update({
          feature_value: formattedValue,
        })
        .eq("id", editingFeature.id)

      if (error) {
        console.error("Error updating feature:", error)
        toast({
          title: "Error",
          description: error.message || "Failed to update feature",
          variant: "destructive",
        })
        return
      }

      toast({
        title: "Success",
        description: "Feature updated successfully",
      })

      // Reset editing state and refresh data
      setEditingFeature(null)

      // Refresh features list
      const { data: refreshedData } = await supabase
        .from("subscription_features")
        .select("*")
        .order("plan", { ascending: true })
        .order("feature_key", { ascending: true })

      setFeatures(refreshedData || [])
    } catch (error: any) {
      console.error("Error updating feature:", error)
      toast({
        title: "Error",
        description: error.message || "An unexpected error occurred",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleDeleteFeature = async (id: string) => {
    if (!supabase) return

    try {
      setIsSubmitting(true)

      // Delete feature
      const { error } = await supabase.from("subscription_features").delete().eq("id", id)

      if (error) {
        console.error("Error deleting feature:", error)
        toast({
          title: "Error",
          description: error.message || "Failed to delete feature",
          variant: "destructive",
        })
        return
      }

      toast({
        title: "Success",
        description: "Feature deleted successfully",
      })

      // Refresh features list
      const { data: refreshedData } = await supabase
        .from("subscription_features")
        .select("*")
        .order("plan", { ascending: true })
        .order("feature_key", { ascending: true })

      setFeatures(refreshedData || [])
    } catch (error: any) {
      console.error("Error deleting feature:", error)
      toast({
        title: "Error",
        description: error.message || "An unexpected error occurred",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  // Show error state if there's an error
  if (error) {
    return (
      <div className="container mx-auto py-10">
        <Card>
          <CardHeader>
            <CardTitle>Error</CardTitle>
            <CardDescription>There was a problem loading the subscription management page.</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-destructive">{error}</p>
            <Button className="mt-4" onClick={() => window.location.reload()}>
              Try Again
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  if (authLoading || isLoading) {
    return (
      <div className="container mx-auto py-10 flex justify-center items-center min-h-[60vh]">
        <div className="flex flex-col items-center gap-2">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    )
  }

  if (!isAdmin) {
    return (
      <div className="container mx-auto py-10">
        <Card>
          <CardHeader>
            <CardTitle>Access Denied</CardTitle>
            <CardDescription>You do not have permission to access this page.</CardDescription>
          </CardHeader>
          <CardContent>
            <p>This page is restricted to administrators only.</p>
          </CardContent>
        </Card>
      </div>
    )
  }

  const formatValue = (value: any) => {
    if (typeof value === "object") {
      return JSON.stringify(value)
    }
    return String(value)
  }

  const getPlanColor = (plan: string) => {
    switch (plan) {
      case "free":
        return "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-200"
      case "pro":
        return "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300"
      case "business":
        return "bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-300"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-200"
    }
  }

  const formatDate = (dateString: string) => {
    if (!dateString) return "N/A"
    return new Date(dateString).toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    })
  }

  return (
    <div className="container mx-auto py-10">
      <div className="mb-8">
        <h1 className="text-3xl font-bold tracking-tight">Subscription Management</h1>
        <p className="text-muted-foreground mt-2">Manage subscription features and view subscriber information</p>
      </div>

      <Tabs defaultValue="features" className="space-y-6">
        <TabsList>
          <TabsTrigger value="features">Subscription Features</TabsTrigger>
          <TabsTrigger value="subscribers">Subscribers</TabsTrigger>
        </TabsList>

        <TabsContent value="features" className="space-y-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Subscription Features</CardTitle>
                <CardDescription>Manage features available in each subscription plan</CardDescription>
              </div>
              <Dialog>
                <DialogTrigger asChild>
                  <Button>
                    <Plus className="mr-2 h-4 w-4" />
                    Add Feature
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Add Subscription Feature</DialogTitle>
                    <DialogDescription>
                      Add a new feature to a subscription plan. Feature values can be strings, numbers, booleans, or
                      JSON arrays.
                    </DialogDescription>
                  </DialogHeader>
                  <div className="grid gap-4 py-4">
                    <div className="grid gap-2">
                      <Label htmlFor="plan">Subscription Plan</Label>
                      <Select
                        value={newFeature.plan}
                        onValueChange={(value) => setNewFeature({ ...newFeature, plan: value })}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select plan" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="free">Free</SelectItem>
                          <SelectItem value="pro">Pro</SelectItem>
                          <SelectItem value="business">Business</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="feature_key">Feature Key</Label>
                      <Input
                        id="feature_key"
                        value={newFeature.feature_key}
                        onChange={(e) => setNewFeature({ ...newFeature, feature_key: e.target.value })}
                        placeholder="e.g., max_connections, analytics_retention_days"
                      />
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="feature_value">Feature Value</Label>
                      <Textarea
                        id="feature_value"
                        value={newFeature.feature_value}
                        onChange={(e) => setNewFeature({ ...newFeature, feature_value: e.target.value })}
                        placeholder="e.g., 10, true, unlimited, [&quot;csv&quot;, &quot;pdf&quot;]"
                        rows={3}
                      />
                      <p className="text-sm text-muted-foreground">
                        Enter a string, number, boolean, or JSON array. For example: &quot;10&quot;, &quot;true&quot;,
                        &quot;unlimited&quot;, or &quot;[&quot;csv&quot;, &quot;pdf&quot;]&quot;
                      </p>
                    </div>
                  </div>
                  <DialogFooter>
                    <Button onClick={handleAddFeature} disabled={isSubmitting}>
                      {isSubmitting ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Adding...
                        </>
                      ) : (
                        "Add Feature"
                      )}
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left py-3 px-4">Plan</th>
                      <th className="text-left py-3 px-4">Feature Key</th>
                      <th className="text-left py-3 px-4">Value</th>
                      <th className="text-right py-3 px-4">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {features.length === 0 ? (
                      <tr>
                        <td colSpan={4} className="py-6 text-center text-muted-foreground">
                          No subscription features found
                        </td>
                      </tr>
                    ) : (
                      features.map((feature) => (
                        <tr key={feature.id} className="border-b">
                          <td className="py-3 px-4">
                            <span
                              className={`inline-block px-2 py-1 rounded text-xs font-medium ${getPlanColor(
                                feature.plan,
                              )}`}
                            >
                              {feature.plan.charAt(0).toUpperCase() + feature.plan.slice(1)}
                            </span>
                          </td>
                          <td className="py-3 px-4">{feature.feature_key}</td>
                          <td className="py-3 px-4 font-mono text-sm">{formatValue(feature.feature_value)}</td>
                          <td className="py-3 px-4 text-right">
                            <div className="flex justify-end gap-2">
                              <Dialog>
                                <DialogTrigger asChild>
                                  <Button variant="outline" size="sm">
                                    Edit
                                  </Button>
                                </DialogTrigger>
                                <DialogContent>
                                  <DialogHeader>
                                    <DialogTitle>Edit Feature</DialogTitle>
                                    <DialogDescription>
                                      Update the value for <span className="font-semibold">{feature.feature_key}</span>{" "}
                                      in the{" "}
                                      <span className="font-semibold">
                                        {feature.plan.charAt(0).toUpperCase() + feature.plan.slice(1)}
                                      </span>{" "}
                                      plan.
                                    </DialogDescription>
                                  </DialogHeader>
                                  <div className="grid gap-4 py-4">
                                    <div className="grid gap-2">
                                      <Label htmlFor="edit_feature_value">Feature Value</Label>
                                      <Textarea
                                        id="edit_feature_value"
                                        value={
                                          editingFeature?.id === feature.id
                                            ? editingFeature.feature_value
                                            : formatValue(feature.feature_value)
                                        }
                                        onChange={(e) =>
                                          setEditingFeature({
                                            ...feature,
                                            feature_value: e.target.value,
                                          })
                                        }
                                        onClick={() =>
                                          !editingFeature &&
                                          setEditingFeature({
                                            ...feature,
                                            feature_value: formatValue(feature.feature_value),
                                          })
                                        }
                                        rows={3}
                                      />
                                      <p className="text-sm text-muted-foreground">
                                        Enter a string, number, boolean, or JSON array.
                                      </p>
                                    </div>
                                  </div>
                                  <DialogFooter>
                                    <Button onClick={handleUpdateFeature} disabled={isSubmitting}>
                                      {isSubmitting ? (
                                        <>
                                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                          Updating...
                                        </>
                                      ) : (
                                        <>
                                          <Save className="mr-2 h-4 w-4" />
                                          Save Changes
                                        </>
                                      )}
                                    </Button>
                                  </DialogFooter>
                                </DialogContent>
                              </Dialog>
                              <Button
                                variant="destructive"
                                size="sm"
                                onClick={() => handleDeleteFeature(feature.id)}
                                disabled={isSubmitting}
                              >
                                {isSubmitting ? (
                                  <Loader2 className="h-4 w-4 animate-spin" />
                                ) : (
                                  <Trash2 className="h-4 w-4" />
                                )}
                              </Button>
                            </div>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="subscribers" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Subscribers</CardTitle>
              <CardDescription>View and manage user subscriptions</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left py-3 px-4">User</th>
                      <th className="text-left py-3 px-4">Email</th>
                      <th className="text-left py-3 px-4">Plan</th>
                      <th className="text-left py-3 px-4">Status</th>
                      <th className="text-left py-3 px-4">Expires</th>
                    </tr>
                  </thead>
                  <tbody>
                    {subscriptions.length === 0 ? (
                      <tr>
                        <td colSpan={5} className="py-6 text-center text-muted-foreground">
                          No subscriptions found
                        </td>
                      </tr>
                    ) : (
                      subscriptions.map((subscription) => (
                        <tr key={subscription.id} className="border-b">
                          <td className="py-3 px-4">{subscription.full_name || "N/A"}</td>
                          <td className="py-3 px-4">{subscription.email || "N/A"}</td>
                          <td className="py-3 px-4">
                            <span
                              className={`inline-block px-2 py-1 rounded text-xs font-medium ${getPlanColor(
                                subscription.subscription_plan || "free",
                              )}`}
                            >
                              {subscription.subscription_plan
                                ? subscription.subscription_plan.charAt(0).toUpperCase() +
                                  subscription.subscription_plan.slice(1)
                                : "Free"}
                            </span>
                          </td>
                          <td className="py-3 px-4 capitalize">{subscription.subscription_status || "free"}</td>
                          <td className="py-3 px-4">{formatDate(subscription.subscription_period_end)}</td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
