import type React from "react"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Admin Dashboard",
  description: "Admin dashboard for managing the platform",
}

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <div className="py-4 border-b bg-white dark:bg-gray-950">
        <div className="container mx-auto">
          <h1 className="text-2xl font-bold">Admin Dashboard</h1>
        </div>
      </div>
      {children}
    </div>
  )
}
