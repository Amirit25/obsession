"use client"

import { useState } from "react"
import { useAuth } from "@/contexts/auth-context"
import { useSupabase } from "@/contexts/supabase-context"
import { useSupabaseQuery } from "@/hooks/use-supabase-query"
import { useSupabaseMutation } from "@/hooks/use-supabase-mutation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useToast } from "@/hooks/use-toast"
import { Loader2, MapPin, Plus, Save, Trash2, Users, AlertCircle } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Textarea } from "@/components/ui/textarea"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { ErrorBoundary } from "@/components/error-boundary"

type Venue = {
  id: string
  name: string
  description: string | null
  address: string
  city: string
  state: string | null
  country: string
  capacity: number | null
  website: string | null
  contact_email: string | null
  contact_phone: string | null
  promoter_id: string | null
  created_at: string
  updated_at: string | null
  profiles?: {
    full_name: string
    email: string
  } | null
}

type NewVenue = Omit<Venue, "id" | "created_at" | "updated_at" | "profiles">

export default function ClientVenueManager() {
  const { user } = useAuth()
  const { isReady } = useSupabase()
  const { toast } = useToast()
  const [isAdmin, setIsAdmin] = useState<boolean | null>(null)
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [editingVenue, setEditingVenue] = useState<Venue | null>(null)
  const [newVenue, setNewVenue] = useState<Partial<NewVenue>>({
    name: "",
    description: "",
    address: "",
    city: "",
    state: "",
    country: "",
    capacity: null,
    website: "",
    contact_email: "",
    contact_phone: "",
  })

  // Check if user is admin
  const {
    data: adminData,
    isLoading: isCheckingAdmin,
    error: adminError,
  } = useSupabaseQuery({
    table: "profiles",
    columns: "role",
    filters: [{ column: "user_id", operator: "eq", value: user?.id || "" }],
    single: true,
    enabled: !!user && isReady,
    dependencies: [user?.id],
  })

  // Set admin status when data is loaded
  if (adminData && isAdmin === null) {
    setIsAdmin(adminData.role === "admin")
  }

  // Fetch venues
  const {
    data: venues,
    isLoading: isLoadingVenues,
    error: venuesError,
    refetch: refetchVenues,
  } = useSupabaseQuery<Venue[]>({
    table: "venues",
    columns: "*, profiles(full_name, email)",
    orderBy: { column: "name", ascending: true },
    enabled: isAdmin === true && isReady,
    dependencies: [isAdmin],
  })

  // Venue mutations
  const { insert: insertVenue, isLoading: isInserting } = useSupabaseMutation<NewVenue>({
    table: "venues",
    onSuccess: () => {
      toast({ title: "Success", description: "Venue added successfully" })
      setNewVenue({
        name: "",
        description: "",
        address: "",
        city: "",
        state: "",
        country: "",
        capacity: null,
        website: "",
        contact_email: "",
        contact_phone: "",
      })
      setIsDialogOpen(false)
      refetchVenues()
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to add venue",
        variant: "destructive",
      })
    },
  })

  const { update: updateVenue, isLoading: isUpdating } = useSupabaseMutation<Partial<Venue>>({
    table: "venues",
    onSuccess: () => {
      toast({ title: "Success", description: "Venue updated successfully" })
      setEditingVenue(null)
      setIsDialogOpen(false)
      refetchVenues()
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update venue",
        variant: "destructive",
      })
    },
  })

  const { remove: deleteVenue, isLoading: isDeleting } = useSupabaseMutation({
    table: "venues",
    onSuccess: () => {
      toast({ title: "Success", description: "Venue deleted successfully" })
      refetchVenues()
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to delete venue",
        variant: "destructive",
      })
    },
  })

  // Handle form submission for new venue
  const handleAddVenue = async () => {
    // Validate required fields
    if (!newVenue.name || !newVenue.address || !newVenue.city || !newVenue.country) {
      toast({
        title: "Validation Error",
        description: "Name, address, city, and country are required",
        variant: "destructive",
      })
      return
    }

    // Add promoter_id (current user) to the venue data
    await insertVenue({
      ...newVenue,
      promoter_id: user?.id || null,
      capacity: newVenue.capacity ? Number(newVenue.capacity) : null,
    } as NewVenue)
  }

  // Handle form submission for editing venue
  const handleUpdateVenue = async () => {
    if (!editingVenue) return

    // Validate required fields
    if (!editingVenue.name || !editingVenue.address || !editingVenue.city || !editingVenue.country) {
      toast({
        title: "Validation Error",
        description: "Name, address, city, and country are required",
        variant: "destructive",
      })
      return
    }

    // Update venue
    await updateVenue(
      {
        name: editingVenue.name,
        description: editingVenue.description,
        address: editingVenue.address,
        city: editingVenue.city,
        state: editingVenue.state,
        country: editingVenue.country,
        capacity: editingVenue.capacity ? Number(editingVenue.capacity) : null,
        website: editingVenue.website,
        contact_email: editingVenue.contact_email,
        contact_phone: editingVenue.contact_phone,
        updated_at: new Date().toISOString(),
      },
      { column: "id", value: editingVenue.id },
    )
  }

  // Handle venue deletion
  const handleDeleteVenue = async (id: string) => {
    if (confirm("Are you sure you want to delete this venue? This action cannot be undone.")) {
      await deleteVenue({ column: "id", value: id })
    }
  }

  // Open edit dialog with venue data
  const openEditDialog = (venue: Venue) => {
    setEditingVenue(venue)
    setIsDialogOpen(true)
  }

  // Open add dialog
  const openAddDialog = () => {
    setEditingVenue(null)
    setIsDialogOpen(true)
  }

  // Loading state
  if (isCheckingAdmin || (isAdmin === true && isLoadingVenues)) {
    return (
      <div className="container mx-auto py-10 flex justify-center items-center min-h-[60vh]">
        <div className="flex flex-col items-center gap-2">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    )
  }

  // Error state
  if (adminError || venuesError) {
    return (
      <div className="container mx-auto py-10">
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>{adminError?.message || venuesError?.message || "An error occurred"}</AlertDescription>
        </Alert>
        <Button onClick={() => window.location.reload()} className="mt-4">
          Try Again
        </Button>
      </div>
    )
  }

  // Access denied state
  if (isAdmin === false) {
    return (
      <div className="container mx-auto py-10">
        <Card>
          <CardHeader>
            <CardTitle>Access Denied</CardTitle>
            <CardDescription>You do not have permission to access this page.</CardDescription>
          </CardHeader>
          <CardContent>
            <p>This page is restricted to administrators only.</p>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <ErrorBoundary>
      <div className="container mx-auto py-10">
        <div className="mb-8">
          <h1 className="text-3xl font-bold tracking-tight">Venue Management</h1>
          <p className="text-muted-foreground mt-2">Manage venues for events and performances</p>
        </div>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle>Venues</CardTitle>
              <CardDescription>View and manage venue information</CardDescription>
            </div>
            <Button onClick={openAddDialog}>
              <Plus className="mr-2 h-4 w-4" />
              Add Venue
            </Button>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b">
                    <th className="text-left py-3 px-4">Name</th>
                    <th className="text-left py-3 px-4">Location</th>
                    <th className="text-left py-3 px-4">Capacity</th>
                    <th className="text-left py-3 px-4">Owner</th>
                    <th className="text-right py-3 px-4">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {venues?.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="py-6 text-center text-muted-foreground">
                        No venues found
                      </td>
                    </tr>
                  ) : (
                    venues?.map((venue) => (
                      <tr key={venue.id} className="border-b">
                        <td className="py-3 px-4 font-medium">{venue.name}</td>
                        <td className="py-3 px-4">
                          <div className="flex items-center">
                            <MapPin className="h-4 w-4 mr-1 text-muted-foreground" />
                            {venue.city}, {venue.country}
                          </div>
                        </td>
                        <td className="py-3 px-4">
                          {venue.capacity ? (
                            <div className="flex items-center">
                              <Users className="h-4 w-4 mr-1 text-muted-foreground" />
                              {venue.capacity.toLocaleString()}
                            </div>
                          ) : (
                            "N/A"
                          )}
                        </td>
                        <td className="py-3 px-4">{venue.profiles?.full_name || "N/A"}</td>
                        <td className="py-3 px-4 text-right">
                          <div className="flex justify-end gap-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => openEditDialog(venue)}
                              disabled={isUpdating}
                            >
                              Edit
                            </Button>
                            <Button
                              variant="destructive"
                              size="sm"
                              onClick={() => handleDeleteVenue(venue.id)}
                              disabled={isDeleting}
                            >
                              {isDeleting ? (
                                <Loader2 className="h-4 w-4 animate-spin" />
                              ) : (
                                <Trash2 className="h-4 w-4" />
                              )}
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        {/* Venue Form Dialog */}
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>{editingVenue ? "Edit Venue" : "Add New Venue"}</DialogTitle>
              <DialogDescription>
                {editingVenue ? "Update venue information." : "Add a new venue to the platform."}
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="name">Venue Name*</Label>
                  <Input
                    id="name"
                    value={editingVenue ? editingVenue.name : newVenue.name}
                    onChange={(e) =>
                      editingVenue
                        ? setEditingVenue({ ...editingVenue, name: e.target.value })
                        : setNewVenue({ ...newVenue, name: e.target.value })
                    }
                    placeholder="e.g., The Music Hall"
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="capacity">Capacity</Label>
                  <Input
                    id="capacity"
                    type="number"
                    value={editingVenue ? editingVenue.capacity || "" : newVenue.capacity || ""}
                    onChange={(e) => {
                      const value = e.target.value ? Number.parseInt(e.target.value) : null
                      editingVenue
                        ? setEditingVenue({ ...editingVenue, capacity: value })
                        : setNewVenue({ ...newVenue, capacity: value })
                    }}
                    placeholder="e.g., 500"
                  />
                </div>
              </div>

              <div className="grid gap-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={editingVenue ? editingVenue.description || "" : newVenue.description || ""}
                  onChange={(e) =>
                    editingVenue
                      ? setEditingVenue({ ...editingVenue, description: e.target.value })
                      : setNewVenue({ ...newVenue, description: e.target.value })
                  }
                  placeholder="Describe the venue..."
                  rows={3}
                />
              </div>

              <div className="grid gap-2">
                <Label htmlFor="address">Address*</Label>
                <Input
                  id="address"
                  value={editingVenue ? editingVenue.address : newVenue.address || ""}
                  onChange={(e) =>
                    editingVenue
                      ? setEditingVenue({ ...editingVenue, address: e.target.value })
                      : setNewVenue({ ...newVenue, address: e.target.value })
                  }
                  placeholder="Street address"
                />
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="city">City*</Label>
                  <Input
                    id="city"
                    value={editingVenue ? editingVenue.city : newVenue.city || ""}
                    onChange={(e) =>
                      editingVenue
                        ? setEditingVenue({ ...editingVenue, city: e.target.value })
                        : setNewVenue({ ...newVenue, city: e.target.value })
                    }
                    placeholder="City"
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="state">State/Province</Label>
                  <Input
                    id="state"
                    value={editingVenue ? editingVenue.state || "" : newVenue.state || ""}
                    onChange={(e) =>
                      editingVenue
                        ? setEditingVenue({ ...editingVenue, state: e.target.value })
                        : setNewVenue({ ...newVenue, state: e.target.value })
                    }
                    placeholder="State/Province"
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="country">Country*</Label>
                  <Input
                    id="country"
                    value={editingVenue ? editingVenue.country : newVenue.country || ""}
                    onChange={(e) =>
                      editingVenue
                        ? setEditingVenue({ ...editingVenue, country: e.target.value })
                        : setNewVenue({ ...newVenue, country: e.target.value })
                    }
                    placeholder="Country"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="website">Website</Label>
                  <Input
                    id="website"
                    value={editingVenue ? editingVenue.website || "" : newVenue.website || ""}
                    onChange={(e) =>
                      editingVenue
                        ? setEditingVenue({ ...editingVenue, website: e.target.value })
                        : setNewVenue({ ...newVenue, website: e.target.value })
                    }
                    placeholder="https://example.com"
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="contact_email">Contact Email</Label>
                  <Input
                    id="contact_email"
                    type="email"
                    value={editingVenue ? editingVenue.contact_email || "" : newVenue.contact_email || ""}
                    onChange={(e) =>
                      editingVenue
                        ? setEditingVenue({ ...editingVenue, contact_email: e.target.value })
                        : setNewVenue({ ...newVenue, contact_email: e.target.value })
                    }
                    placeholder="contact@venue.com"
                  />
                </div>
              </div>

              <div className="grid gap-2">
                <Label htmlFor="contact_phone">Contact Phone</Label>
                <Input
                  id="contact_phone"
                  value={editingVenue ? editingVenue.contact_phone || "" : newVenue.contact_phone || ""}
                  onChange={(e) =>
                    editingVenue
                      ? setEditingVenue({ ...editingVenue, contact_phone: e.target.value })
                      : setNewVenue({ ...newVenue, contact_phone: e.target.value })
                  }
                  placeholder="+1 (555) 123-4567"
                />
              </div>
            </div>
            <DialogFooter>
              <Button onClick={editingVenue ? handleUpdateVenue : handleAddVenue} disabled={isInserting || isUpdating}>
                {isInserting || isUpdating ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    {editingVenue ? "Updating..." : "Adding..."}
                  </>
                ) : (
                  <>
                    <Save className="mr-2 h-4 w-4" />
                    {editingVenue ? "Save Changes" : "Add Venue"}
                  </>
                )}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </ErrorBoundary>
  )
}
