import ClientVenueManager from "./ClientVenueManager"

export default function AdminVenuesPage() {
  return <ClientVenueManager />
}
