"use client"

import { useState, useEffect } from "react"
import { useAuth } from "@/contexts/auth-context"
import { useSupabase } from "@/contexts/supabase-context"
import { useSupabaseQuery } from "@/hooks/use-supabase-query"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Loader2, Users, Music, MapPin, CreditCard, Settings, AlertCircle } from "lucide-react"
import Link from "next/link"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { ErrorBoundary } from "@/components/error-boundary"

export default function AdminDashboardPage() {
  const { user, isLoading: authLoading } = useAuth()
  const { supabase, isReady } = useSupabase()
  const [isAdmin, setIsAdmin] = useState(false)
  const [isCheckingAdmin, setIsCheckingAdmin] = useState(true)
  const [adminError, setAdminError] = useState<string | null>(null)

  // Check if user is admin
  useEffect(() => {
    const checkAdminStatus = async () => {
      if (!user || !supabase || !isReady) {
        setIsCheckingAdmin(false)
        return
      }

      try {
        const { data, error } = await supabase.from("profiles").select("role").eq("user_id", user.id).single()

        if (error) {
          console.error("Error checking admin status:", error)
          setAdminError("Failed to verify admin status. Please try again.")
          return
        }

        setIsAdmin(data?.role === "admin")
      } catch (error: any) {
        console.error("Error checking admin status:", error)
        setAdminError("An unexpected error occurred. Please try again.")
      } finally {
        setIsCheckingAdmin(false)
      }
    }

    checkAdminStatus()
  }, [user, supabase, isReady])

  // Fetch user count
  const {
    data: userCount,
    isLoading: isLoadingUsers,
    error: userError,
  } = useSupabaseQuery({
    table: "profiles",
    columns: "count",
    enabled: isAdmin && isReady,
  })

  // Fetch artist count
  const {
    data: artistCount,
    isLoading: isLoadingArtists,
    error: artistError,
  } = useSupabaseQuery({
    table: "artist_profiles",
    columns: "count",
    enabled: isAdmin && isReady,
  })

  // Fetch venue count
  const {
    data: venueCount,
    isLoading: isLoadingVenues,
    error: venueError,
  } = useSupabaseQuery({
    table: "venues",
    columns: "count",
    enabled: isAdmin && isReady,
  })

  // Fetch subscription count
  const {
    data: subscriptionCount,
    isLoading: isLoadingSubscriptions,
    error: subscriptionError,
  } = useSupabaseQuery({
    table: "profiles",
    columns: "count",
    filters: [{ column: "subscription_status", operator: "is", value: "not.null" }],
    enabled: isAdmin && isReady,
  })

  const isLoading =
    authLoading ||
    isCheckingAdmin ||
    (isAdmin && (isLoadingUsers || isLoadingArtists || isLoadingVenues || isLoadingSubscriptions))

  const error =
    adminError || userError?.message || artistError?.message || venueError?.message || subscriptionError?.message

  if (isLoading) {
    return (
      <div className="container mx-auto py-10 flex justify-center items-center min-h-[60vh]">
        <div className="flex flex-col items-center gap-2">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="container mx-auto py-10">
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
        <Button onClick={() => window.location.reload()} className="mt-4">
          Try Again
        </Button>
      </div>
    )
  }

  if (!isAdmin) {
    return (
      <div className="container mx-auto py-10">
        <Card>
          <CardHeader>
            <CardTitle>Access Denied</CardTitle>
            <CardDescription>You do not have permission to access this page.</CardDescription>
          </CardHeader>
          <CardContent>
            <p>This page is restricted to administrators only.</p>
          </CardContent>
        </Card>
      </div>
    )
  }

  const stats = {
    users: userCount?.[0]?.count || 0,
    artists: artistCount?.[0]?.count || 0,
    venues: venueCount?.[0]?.count || 0,
    subscriptions: subscriptionCount?.[0]?.count || 0,
  }

  return (
    <ErrorBoundary>
      <div className="container mx-auto py-10">
        <div className="mb-8">
          <h1 className="text-3xl font-bold tracking-tight">Admin Dashboard</h1>
          <p className="text-muted-foreground mt-2">Manage and monitor your platform</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Total Users</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center">
                <Users className="h-5 w-5 text-primary mr-2" />
                <span className="text-3xl font-bold">{stats.users}</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Artists</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center">
                <Music className="h-5 w-5 text-primary mr-2" />
                <span className="text-3xl font-bold">{stats.artists}</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Venues</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center">
                <MapPin className="h-5 w-5 text-primary mr-2" />
                <span className="text-3xl font-bold">{stats.venues}</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Subscriptions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center">
                <CreditCard className="h-5 w-5 text-primary mr-2" />
                <span className="text-3xl font-bold">{stats.subscriptions}</span>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Subscription Management</CardTitle>
              <CardDescription>Manage subscription plans and features</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                Configure subscription plans, features, and view subscriber information.
              </p>
            </CardContent>
            <CardFooter>
              <Button asChild className="w-full">
                <Link href="/admin/subscription">
                  <Settings className="mr-2 h-4 w-4" />
                  Manage Subscriptions
                </Link>
              </Button>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Venue Management</CardTitle>
              <CardDescription>Manage venues for events</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">Add, edit, and remove venues from the platform.</p>
            </CardContent>
            <CardFooter>
              <Button asChild className="w-full">
                <Link href="/admin/venues">
                  <MapPin className="mr-2 h-4 w-4" />
                  Manage Venues
                </Link>
              </Button>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>User Management</CardTitle>
              <CardDescription>Manage user accounts</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">View, edit, and manage user accounts and permissions.</p>
            </CardContent>
            <CardFooter>
              <Button asChild className="w-full">
                <Link href="/admin/users">
                  <Users className="mr-2 h-4 w-4" />
                  Manage Users
                </Link>
              </Button>
            </CardFooter>
          </Card>
        </div>
      </div>
    </ErrorBoundary>
  )
}
