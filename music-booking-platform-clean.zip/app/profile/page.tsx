"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Skeleton } from "@/components/ui/skeleton"
import { useToast } from "@/hooks/use-toast"
import { useAuth } from "@/contexts/auth-context"
import { getSupabaseBrowserClient } from "@/lib/supabase"
import { PersonalInfoForm } from "@/components/profile/personal-info-form"
import { PreferencesForm } from "@/components/profile/preferences-form"
import { BookingHistory } from "@/components/profile/booking-history"
import { ProfileStatistics } from "@/components/profile/profile-statistics"
import { ProfileReviews } from "@/components/profile/profile-reviews"
import { AdminSection } from "@/components/profile/admin-section"
import { ProfileHeader } from "@/components/profile/profile-header"

export default function ProfilePage() {
  const { user, profile, isLoading: authLoading } = useAuth()
  const [profileData, setProfileData] = useState<any>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [isAdmin, setIsAdmin] = useState(false)
  const router = useRouter()
  const { toast } = useToast()
  const supabase = getSupabaseBrowserClient()

  useEffect(() => {
    const fetchProfileData = async () => {
      if (!user || !profile) return

      try {
        setIsLoading(true)

        // Fetch the user's profile data
        const query = supabase
          .from("profiles")
          .select(`
            *,
            artist_profiles(*),
            promoter_profiles(*)
          `)
          .eq("id", profile.id)
          .single()

        const { data, error } = await query

        if (error) throw error

        // Check if user has admin role
        const isAdminUser = data.role === "admin" || data.is_admin === true
        setIsAdmin(isAdminUser)

        // Fetch additional data based on user role
        let additionalData = {}

        if (data.role === "artist") {
          // Fetch artist-specific data
          const { data: artistStats } = await supabase
            .from("artist_statistics")
            .select("*")
            .eq("profile_id", profile.id)
            .single()
            .catch(() => ({ data: null }))

          // Fetch reviews
          const { data: reviews } = await supabase
            .from("reviews")
            .select("*")
            .eq("artist_id", data.artist_profiles[0]?.id)
            .order("created_at", { ascending: false })
            .catch(() => ({ data: [] }))

          additionalData = {
            statistics: artistStats || { profile_views: 0, booking_requests: 0, confirmed_bookings: 0 },
            reviews: reviews || [],
          }
        } else if (data.role === "promoter") {
          // Fetch promoter-specific data
          const { data: promoterStats } = await supabase
            .from("promoter_statistics")
            .select("*")
            .eq("profile_id", profile.id)
            .single()
            .catch(() => ({ data: null }))

          additionalData = {
            statistics: promoterStats || { profile_views: 0, gigs_posted: 0, applications_received: 0 },
          }
        }

        // Fetch booking history
        const { data: bookings } = await supabase
          .from("booking_requests")
          .select(`
            *,
            artist:artist_id (
              id,
              artist_name,
              profile_id,
              profiles:profile_id (
                id,
                full_name,
                avatar_url
              )
            ),
            requester:requester_id (
              id,
              full_name,
              avatar_url
            )
          `)
          .or(`artist_id.eq.${data.artist_profiles[0]?.id || "null"},requester_id.eq.${profile.id}`)
          .order("created_at", { ascending: false })
          .catch(() => ({ data: [] }))

        setProfileData({
          ...data,
          ...additionalData,
          bookings: bookings || [],
        })
      } catch (error: any) {
        console.error("Error fetching profile data:", error)
        toast({
          title: "Error",
          description: "Failed to load profile data. Please try again.",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }

    if (user && profile && !authLoading) {
      fetchProfileData()
    } else if (!authLoading && !user) {
      router.push("/auth/login")
    }
  }, [user, profile, authLoading, supabase, toast, router])

  if (authLoading || isLoading) {
    return <ProfileSkeleton />
  }

  if (!user || !profile) {
    return null // Router will redirect to login
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <ProfileHeader
        name={profileData?.full_name || ""}
        role={profileData?.role || ""}
        avatarUrl={profileData?.avatar_url || ""}
        email={profileData?.email || ""}
      />

      <Tabs defaultValue="personal-info" className="mt-8">
        <TabsList className="grid w-full grid-cols-2 md:grid-cols-5 lg:w-auto">
          <TabsTrigger value="personal-info">Personal Info</TabsTrigger>
          <TabsTrigger value="preferences">Preferences</TabsTrigger>
          <TabsTrigger value="bookings">Bookings</TabsTrigger>
          <TabsTrigger value="statistics">Statistics</TabsTrigger>
          <TabsTrigger value="reviews">Reviews</TabsTrigger>
          {isAdmin && <TabsTrigger value="admin">Admin</TabsTrigger>}
        </TabsList>

        <div className="mt-6">
          <TabsContent value="personal-info">
            <PersonalInfoForm
              profileData={profileData}
              onUpdate={(updatedData) => setProfileData({ ...profileData, ...updatedData })}
            />
          </TabsContent>

          <TabsContent value="preferences">
            <PreferencesForm
              profileData={profileData}
              onUpdate={(updatedData) => setProfileData({ ...profileData, ...updatedData })}
            />
          </TabsContent>

          <TabsContent value="bookings">
            <BookingHistory bookings={profileData?.bookings || []} userRole={profileData?.role} />
          </TabsContent>

          <TabsContent value="statistics">
            <ProfileStatistics statistics={profileData?.statistics || {}} userRole={profileData?.role} />
          </TabsContent>

          <TabsContent value="reviews">
            <ProfileReviews reviews={profileData?.reviews || []} userRole={profileData?.role} />
          </TabsContent>

          {isAdmin && (
            <TabsContent value="admin">
              <AdminSection profileData={profileData} />
            </TabsContent>
          )}
        </div>
      </Tabs>
    </div>
  )
}

function ProfileSkeleton() {
  return (
    <div className="container mx-auto py-8 px-4">
      <div className="flex flex-col md:flex-row items-center md:items-start gap-6">
        <Skeleton className="h-24 w-24 rounded-full" />
        <div className="space-y-2">
          <Skeleton className="h-8 w-48" />
          <Skeleton className="h-4 w-32" />
          <Skeleton className="h-4 w-64" />
        </div>
      </div>

      <div className="mt-8">
        <Skeleton className="h-10 w-full max-w-md mb-6" />
        <Skeleton className="h-[400px] w-full" />
      </div>
    </div>
  )
}
