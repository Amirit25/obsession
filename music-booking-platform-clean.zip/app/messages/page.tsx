import { getConversations } from "../actions/messaging-actions"
import { ConversationList } from "@/components/messaging/conversation-list"
import { NewConversationDialog } from "@/components/messaging/new-conversation-dialog"

export default async function MessagesPage() {
  const { data: conversations, error } = await getConversations()

  return (
    <div className="h-[calc(100vh-4rem)] flex flex-col">
      <div className="flex items-center justify-between p-4 border-b">
        <h1 className="text-2xl font-bold">Messages</h1>
        <NewConversationDialog />
      </div>

      <div className="flex-1 flex">
        <div className="w-full md:w-80 lg:w-96 h-full">
          <ConversationList conversations={conversations || []} />
        </div>

        <div className="hidden md:flex flex-1 items-center justify-center bg-muted/30">
          <div className="text-center">
            <h2 className="text-xl font-medium mb-2">Select a conversation</h2>
            <p className="text-muted-foreground">Choose a conversation from the list or start a new one</p>
          </div>
        </div>
      </div>
    </div>
  )
}
