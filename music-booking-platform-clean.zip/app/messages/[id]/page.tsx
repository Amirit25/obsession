import { notFound } from "next/navigation"
import Link from "next/link"
import { getMessages, getConversations } from "@/app/actions/messaging-actions"
import { MessageList } from "@/components/messaging/message-list"
import { MessageInput } from "@/components/messaging/message-input"
import { ConversationList } from "@/components/messaging/conversation-list"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { ChevronLeft } from "lucide-react"

interface ConversationPageProps {
  params: {
    id: string
  }
}

export default async function ConversationPage({ params }: ConversationPageProps) {
  const { id } = params

  // Get messages for this conversation
  const { data: messages, error: messagesError } = await getMessages(id)

  // Get all conversations for the sidebar
  const { data: conversations, error: conversationsError } = await getConversations()

  // If conversation doesn't exist or user doesn't have access
  if (messagesError || !messages) {
    notFound()
  }

  // Find the current conversation
  const currentConversation = conversations?.find((c) => c.id === id)

  // Find the other participant (not the current user)
  const otherParticipant = currentConversation?.participants[0]

  return (
    <div className="h-[calc(100vh-4rem)] flex flex-col">
      <div className="flex-1 flex">
        {/* Conversation list sidebar (hidden on mobile) */}
        <div className="hidden md:block w-80 lg:w-96 h-full border-r">
          <ConversationList conversations={conversations || []} />
        </div>

        {/* Main conversation area */}
        <div className="flex-1 flex flex-col">
          {/* Conversation header */}
          <div className="flex items-center p-4 border-b">
            <Link href="/messages" className="md:hidden mr-2">
              <Button variant="ghost" size="icon">
                <ChevronLeft className="h-5 w-5" />
              </Button>
            </Link>

            {otherParticipant ? (
              <div className="flex items-center">
                <Avatar className="h-10 w-10 mr-3">
                  <AvatarImage src={otherParticipant.profile.avatar_url || undefined} />
                  <AvatarFallback>{otherParticipant.profile.full_name.charAt(0)}</AvatarFallback>
                </Avatar>

                <div>
                  <h2 className="font-medium">{otherParticipant.profile.full_name}</h2>
                  <p className="text-xs text-muted-foreground">
                    {otherParticipant.profile.role === "artist" ? "Artist" : "Promoter"}
                  </p>
                </div>
              </div>
            ) : (
              <h2 className="font-medium">Conversation</h2>
            )}
          </div>

          {/* Messages */}
          <MessageList messages={messages} />

          {/* Message input */}
          <MessageInput conversationId={id} />
        </div>
      </div>
    </div>
  )
}
