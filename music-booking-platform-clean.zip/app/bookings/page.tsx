"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Calendar, Check, X, Clock } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { useToast } from "@/hooks/use-toast"
import { useAuth } from "@/contexts/auth-context"
import { useSupabase } from "@/contexts/supabase-context"
import { updateBookingStatus } from "@/app/actions/booking-actions"
import { ErrorBoundary } from "@/components/error-boundary"

export default function BookingsPage() {
  const { user, profile } = useAuth()
  const { supabase, isReady } = useSupabase()
  const [bookings, setBookings] = useState<any[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const { toast } = useToast()

  useEffect(() => {
    const fetchBookings = async () => {
      if (!profile || !supabase || !isReady) return

      try {
        setIsLoading(true)

        // Get bookings where the user is either the artist or the requester
        const { data, error } = await supabase
          .from("booking_requests")
          .select(`
            *,
            artist:artist_id (
              id,
              artist_name,
              profile_id,
              profiles:profile_id (
                id,
                full_name,
                avatar_url
              )
            ),
            requester:requester_id (
              id,
              full_name,
              avatar_url
            )
          `)
          .or(`artist_id.eq.${profile.id},requester_id.eq.${profile.id}`)
          .order("created_at", { ascending: false })

        if (error) throw error

        setBookings(data || [])
      } catch (error: any) {
        toast({
          title: "Error",
          description: "Failed to load bookings",
          variant: "destructive",
        })
        console.error(error)
      } finally {
        setIsLoading(false)
      }
    }

    if (user && profile && supabase && isReady) {
      fetchBookings()
    } else if (!user) {
      setIsLoading(false)
    }
  }, [profile, supabase, toast, user, isReady])

  const handleUpdateStatus = async (id: string, status: "accepted" | "rejected" | "cancelled") => {
    try {
      const result = await updateBookingStatus(id, status)

      if (result.error) {
        toast({
          title: "Error",
          description: result.error,
          variant: "destructive",
        })
      } else {
        toast({
          title: "Status Updated",
          description: `Booking has been ${status}`,
        })

        // Update the local state
        setBookings(bookings.map((booking) => (booking.id === id ? { ...booking, status } : booking)))
      }
    } catch (error: any) {
      toast({
        title: "Error",
        description: "Failed to update booking status",
        variant: "destructive",
      })
    }
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4">Loading bookings...</p>
        </div>
      </div>
    )
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardContent className="py-8">
            <p className="text-center mb-4">Please log in to view your bookings</p>
            <Button asChild className="w-full">
              <Link href="/auth/login">Log In</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  // Filter bookings by status
  const pendingBookings = bookings.filter((booking) => booking.status === "pending")
  const acceptedBookings = bookings.filter((booking) => booking.status === "accepted")
  const rejectedBookings = bookings.filter((booking) => booking.status === "rejected" || booking.status === "cancelled")

  // Determine if the user is the artist or the requester for each booking
  const isArtist = (booking: any) => booking.artist?.profile_id === profile?.id

  return (
    <ErrorBoundary>
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
        <div className="container mx-auto px-4 py-8">
          <div className="flex items-center mb-8">
            <h1 className="text-2xl font-bold">Bookings</h1>
          </div>

          <Tabs defaultValue="pending">
            <TabsList className="mb-8">
              <TabsTrigger value="pending">
                Pending
                {pendingBookings.length > 0 && (
                  <Badge variant="secondary" className="ml-2">
                    {pendingBookings.length}
                  </Badge>
                )}
              </TabsTrigger>
              <TabsTrigger value="accepted">
                Accepted
                {acceptedBookings.length > 0 && (
                  <Badge variant="secondary" className="ml-2">
                    {acceptedBookings.length}
                  </Badge>
                )}
              </TabsTrigger>
              <TabsTrigger value="rejected">
                Rejected/Cancelled
                {rejectedBookings.length > 0 && (
                  <Badge variant="secondary" className="ml-2">
                    {rejectedBookings.length}
                  </Badge>
                )}
              </TabsTrigger>
            </TabsList>

            <TabsContent value="pending">
              {pendingBookings.length === 0 ? (
                <Card>
                  <CardContent className="py-8 text-center">
                    <p className="text-muted-foreground">No pending booking requests</p>
                  </CardContent>
                </Card>
              ) : (
                <div className="space-y-4">
                  {pendingBookings.map((booking) => (
                    <Card key={booking.id}>
                      <CardHeader>
                        <div className="flex justify-between items-start">
                          <div>
                            <CardTitle>{booking.event_name}</CardTitle>
                            <CardDescription>
                              {new Date(booking.event_date).toLocaleDateString("en-US", {
                                weekday: "long",
                                year: "numeric",
                                month: "long",
                                day: "numeric",
                              })}
                            </CardDescription>
                          </div>
                          <Badge variant="outline" className="flex items-center">
                            <Clock className="mr-1 h-3 w-3" />
                            Pending
                          </Badge>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-4">
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                              <p className="text-sm font-medium text-muted-foreground">Location</p>
                              <p>{booking.event_location}</p>
                              {booking.event_venue && <p className="text-sm">{booking.event_venue}</p>}
                            </div>
                            <div>
                              <p className="text-sm font-medium text-muted-foreground">
                                {isArtist(booking) ? "Requested by" : "Artist"}
                              </p>
                              <p>
                                {isArtist(booking)
                                  ? booking.requester?.full_name || "Unknown"
                                  : booking.artist?.artist_name || booking.artist?.profiles?.full_name || "Unknown"}
                              </p>
                            </div>
                          </div>
                          {booking.event_description && (
                            <div>
                              <p className="text-sm font-medium text-muted-foreground">Description</p>
                              <p className="text-sm">{booking.event_description}</p>
                            </div>
                          )}
                          {booking.budget && (
                            <div>
                              <p className="text-sm font-medium text-muted-foreground">Budget</p>
                              <p>{booking.budget}</p>
                            </div>
                          )}
                          <div>
                            <p className="text-sm font-medium text-muted-foreground">Contact</p>
                            <p>{booking.contact_email}</p>
                            {booking.contact_phone && <p className="text-sm">{booking.contact_phone}</p>}
                          </div>
                        </div>
                      </CardContent>
                      {isArtist(booking) && (
                        <CardFooter className="flex justify-end space-x-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleUpdateStatus(booking.id, "rejected")}
                          >
                            <X className="mr-2 h-4 w-4" />
                            Decline
                          </Button>
                          <Button
                            variant="default"
                            size="sm"
                            onClick={() => handleUpdateStatus(booking.id, "accepted")}
                          >
                            <Check className="mr-2 h-4 w-4" />
                            Accept
                          </Button>
                        </CardFooter>
                      )}
                      {!isArtist(booking) && (
                        <CardFooter className="flex justify-end">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleUpdateStatus(booking.id, "cancelled")}
                          >
                            <X className="mr-2 h-4 w-4" />
                            Cancel Request
                          </Button>
                        </CardFooter>
                      )}
                    </Card>
                  ))}
                </div>
              )}
            </TabsContent>

            <TabsContent value="accepted">
              {acceptedBookings.length === 0 ? (
                <Card>
                  <CardContent className="py-8 text-center">
                    <p className="text-muted-foreground">No accepted booking requests</p>
                  </CardContent>
                </Card>
              ) : (
                <div className="space-y-4">
                  {acceptedBookings.map((booking) => (
                    <Card key={booking.id}>
                      <CardHeader>
                        <div className="flex justify-between items-start">
                          <div>
                            <CardTitle>{booking.event_name}</CardTitle>
                            <CardDescription>
                              {new Date(booking.event_date).toLocaleDateString("en-US", {
                                weekday: "long",
                                year: "numeric",
                                month: "long",
                                day: "numeric",
                              })}
                            </CardDescription>
                          </div>
                          <Badge
                            variant="success"
                            className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100 flex items-center"
                          >
                            <Check className="mr-1 h-3 w-3" />
                            Accepted
                          </Badge>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-4">
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                              <p className="text-sm font-medium text-muted-foreground">Location</p>
                              <p>{booking.event_location}</p>
                              {booking.event_venue && <p className="text-sm">{booking.event_venue}</p>}
                            </div>
                            <div>
                              <p className="text-sm font-medium text-muted-foreground">
                                {isArtist(booking) ? "Requested by" : "Artist"}
                              </p>
                              <p>
                                {isArtist(booking)
                                  ? booking.requester?.full_name || "Unknown"
                                  : booking.artist?.artist_name || booking.artist?.profiles?.full_name || "Unknown"}
                              </p>
                            </div>
                          </div>
                          {booking.event_description && (
                            <div>
                              <p className="text-sm font-medium text-muted-foreground">Description</p>
                              <p className="text-sm">{booking.event_description}</p>
                            </div>
                          )}
                          {booking.budget && (
                            <div>
                              <p className="text-sm font-medium text-muted-foreground">Budget</p>
                              <p>{booking.budget}</p>
                            </div>
                          )}
                          <div>
                            <p className="text-sm font-medium text-muted-foreground">Contact</p>
                            <p>{booking.contact_email}</p>
                            {booking.contact_phone && <p className="text-sm">{booking.contact_phone}</p>}
                          </div>
                        </div>
                      </CardContent>
                      <CardFooter className="flex justify-end">
                        <Button variant="outline" size="sm" asChild>
                          <Link href={`/messages?booking=${booking.id}`}>
                            <Calendar className="mr-2 h-4 w-4" />
                            Discuss Details
                          </Link>
                        </Button>
                      </CardFooter>
                    </Card>
                  ))}
                </div>
              )}
            </TabsContent>

            <TabsContent value="rejected">
              {rejectedBookings.length === 0 ? (
                <Card>
                  <CardContent className="py-8 text-center">
                    <p className="text-muted-foreground">No rejected or cancelled booking requests</p>
                  </CardContent>
                </Card>
              ) : (
                <div className="space-y-4">
                  {rejectedBookings.map((booking) => (
                    <Card key={booking.id}>
                      <CardHeader>
                        <div className="flex justify-between items-start">
                          <div>
                            <CardTitle>{booking.event_name}</CardTitle>
                            <CardDescription>
                              {new Date(booking.event_date).toLocaleDateString("en-US", {
                                weekday: "long",
                                year: "numeric",
                                month: "long",
                                day: "numeric",
                              })}
                            </CardDescription>
                          </div>
                          <Badge variant="destructive" className="flex items-center">
                            <X className="mr-1 h-3 w-3" />
                            {booking.status === "rejected" ? "Rejected" : "Cancelled"}
                          </Badge>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-4">
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                              <p className="text-sm font-medium text-muted-foreground">Location</p>
                              <p>{booking.event_location}</p>
                              {booking.event_venue && <p className="text-sm">{booking.event_venue}</p>}
                            </div>
                            <div>
                              <p className="text-sm font-medium text-muted-foreground">
                                {isArtist(booking) ? "Requested by" : "Artist"}
                              </p>
                              <p>
                                {isArtist(booking)
                                  ? booking.requester?.full_name || "Unknown"
                                  : booking.artist?.artist_name || booking.artist?.profiles?.full_name || "Unknown"}
                              </p>
                            </div>
                          </div>
                          {booking.event_description && (
                            <div>
                              <p className="text-sm font-medium text-muted-foreground">Description</p>
                              <p className="text-sm">{booking.event_description}</p>
                            </div>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </ErrorBoundary>
  )
}
