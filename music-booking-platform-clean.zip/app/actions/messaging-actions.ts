"use server"

import { revalidatePath } from "next/cache"
import { getSupabaseServerClient } from "@/lib/supabase"
import type { NewConversation, NewMessage } from "@/types/messaging"

// Get all conversations for the current user
export async function getConversations() {
  try {
    const supabase = getSupabaseServerClient()

    // Get the current user
    const {
      data: { user },
    } = await supabase.auth.getUser()
    if (!user) {
      return { error: "Not authenticated" }
    }

    // Get the profile ID
    const { data: profile } = await supabase.from("profiles").select("id").eq("user_id", user.id).single()

    if (!profile) {
      return { error: "Profile not found" }
    }

    // Get all conversations the user is part of
    const { data: participations, error: participationsError } = await supabase
      .from("conversation_participants")
      .select(`
        conversation_id,
        conversations:conversation_id (
          id,
          created_at,
          updated_at
        )
      `)
      .eq("profile_id", profile.id)

    if (participationsError) {
      return { error: participationsError.message }
    }

    if (!participations || participations.length === 0) {
      return { data: [] }
    }

    // Get conversation IDs
    const conversationIds = participations.map((p) => p.conversation_id)

    // Get all participants for these conversations
    const { data: participants, error: participantsError } = await supabase
      .from("conversation_participants")
      .select(`
        id,
        conversation_id,
        profile_id,
        created_at,
        profiles:profile_id (
          id,
          full_name,
          avatar_url,
          role
        )
      `)
      .in("conversation_id", conversationIds)

    if (participantsError) {
      return { error: participantsError.message }
    }

    // Get the last message for each conversation
    const { data: lastMessages, error: lastMessagesError } = await supabase
      .from("messages")
      .select(`
        id,
        conversation_id,
        sender_id,
        content,
        read,
        created_at,
        updated_at,
        profiles:sender_id (
          id,
          full_name,
          avatar_url
        )
      `)
      .in("conversation_id", conversationIds)
      .order("created_at", { ascending: false })

    if (lastMessagesError) {
      return { error: lastMessagesError.message }
    }

    // Count unread messages for each conversation
    const { data: unreadCounts, error: unreadCountsError } = await supabase
      .from("messages")
      .select("conversation_id, count", { count: "exact" })
      .in("conversation_id", conversationIds)
      .eq("read", false)
      .neq("sender_id", profile.id)
      .group("conversation_id")

    if (unreadCountsError) {
      return { error: unreadCountsError.message }
    }

    // Organize data into conversations
    const conversations = participations.map((p) => {
      const conversation = p.conversations

      // Get participants for this conversation
      const conversationParticipants =
        participants?.filter((participant) => participant.conversation_id === conversation.id) || []

      // Get the last message for this conversation
      const lastMessage = lastMessages?.find((message) => message.conversation_id === conversation.id)

      // Get unread count for this conversation
      const unreadCount = unreadCounts?.find((count) => count.conversation_id === conversation.id)?.count || 0

      return {
        ...conversation,
        participants: conversationParticipants,
        lastMessage,
        unreadCount,
      }
    })

    // Sort conversations by last message date (newest first)
    conversations.sort((a, b) => {
      const dateA = a.lastMessage?.created_at || a.updated_at
      const dateB = b.lastMessage?.created_at || b.updated_at
      return new Date(dateB).getTime() - new Date(dateA).getTime()
    })

    return { data: conversations }
  } catch (error: any) {
    console.error("Error fetching conversations:", error)
    return { error: error.message || "Failed to fetch conversations" }
  }
}

// Get messages for a specific conversation
export async function getMessages(conversationId: string) {
  try {
    const supabase = getSupabaseServerClient()

    // Get the current user
    const {
      data: { user },
    } = await supabase.auth.getUser()
    if (!user) {
      return { error: "Not authenticated" }
    }

    // Get the profile ID
    const { data: profile } = await supabase.from("profiles").select("id").eq("user_id", user.id).single()

    if (!profile) {
      return { error: "Profile not found" }
    }

    // Check if user is part of this conversation
    const { data: participation, error: participationError } = await supabase
      .from("conversation_participants")
      .select("id")
      .eq("conversation_id", conversationId)
      .eq("profile_id", profile.id)
      .single()

    if (participationError || !participation) {
      return { error: "You don't have access to this conversation" }
    }

    // Get messages
    const { data: messages, error: messagesError } = await supabase
      .from("messages")
      .select(`
        id,
        conversation_id,
        sender_id,
        content,
        read,
        created_at,
        updated_at,
        profiles:sender_id (
          id,
          full_name,
          avatar_url
        )
      `)
      .eq("conversation_id", conversationId)
      .order("created_at", { ascending: true })

    if (messagesError) {
      return { error: messagesError.message }
    }

    // Mark unread messages as read
    const { error: updateError } = await supabase
      .from("messages")
      .update({ read: true })
      .eq("conversation_id", conversationId)
      .neq("sender_id", profile.id)
      .eq("read", false)

    if (updateError) {
      console.error("Error marking messages as read:", updateError)
    }

    return { data: messages }
  } catch (error: any) {
    console.error("Error fetching messages:", error)
    return { error: error.message || "Failed to fetch messages" }
  }
}

// Send a message
export async function sendMessage(data: NewMessage) {
  try {
    const supabase = getSupabaseServerClient()

    // Get the current user
    const {
      data: { user },
    } = await supabase.auth.getUser()
    if (!user) {
      return { error: "Not authenticated" }
    }

    // Get the profile ID
    const { data: profile } = await supabase.from("profiles").select("id").eq("user_id", user.id).single()

    if (!profile) {
      return { error: "Profile not found" }
    }

    // Check if user is part of this conversation
    const { data: participation, error: participationError } = await supabase
      .from("conversation_participants")
      .select("id")
      .eq("conversation_id", data.conversation_id)
      .eq("profile_id", profile.id)
      .single()

    if (participationError || !participation) {
      return { error: "You don't have access to this conversation" }
    }

    // Send message
    const { data: message, error: messageError } = await supabase
      .from("messages")
      .insert({
        conversation_id: data.conversation_id,
        sender_id: profile.id,
        content: data.content,
        read: false,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      })
      .select()
      .single()

    if (messageError) {
      return { error: messageError.message }
    }

    revalidatePath(`/messages/${data.conversation_id}`)
    return { data: message }
  } catch (error: any) {
    console.error("Error sending message:", error)
    return { error: error.message || "Failed to send message" }
  }
}

// Create a new conversation
export async function createConversation(data: NewConversation) {
  try {
    const supabase = getSupabaseServerClient()

    // Get the current user
    const {
      data: { user },
    } = await supabase.auth.getUser()
    if (!user) {
      return { error: "Not authenticated" }
    }

    // Get the profile ID
    const { data: profile } = await supabase.from("profiles").select("id").eq("user_id", user.id).single()

    if (!profile) {
      return { error: "Profile not found" }
    }

    // Check if recipient exists
    const { data: recipient, error: recipientError } = await supabase
      .from("profiles")
      .select("id")
      .eq("id", data.recipient_id)
      .single()

    if (recipientError || !recipient) {
      return { error: "Recipient not found" }
    }

    // Check if conversation already exists between these users
    const { data: existingParticipations, error: existingError } = await supabase
      .from("conversation_participants")
      .select("conversation_id")
      .eq("profile_id", profile.id)

    if (!existingError && existingParticipations && existingParticipations.length > 0) {
      const conversationIds = existingParticipations.map((p) => p.conversation_id)

      const { data: recipientParticipations, error: recipientError } = await supabase
        .from("conversation_participants")
        .select("conversation_id")
        .eq("profile_id", data.recipient_id)
        .in("conversation_id", conversationIds)

      if (!recipientError && recipientParticipations && recipientParticipations.length > 0) {
        // Conversation already exists, send message to existing conversation
        const existingConversationId = recipientParticipations[0].conversation_id

        // Send initial message
        await sendMessage({
          conversation_id: existingConversationId,
          content: data.initial_message,
        })

        return { data: { id: existingConversationId }, existing: true }
      }
    }

    // Create new conversation
    const { data: conversation, error: conversationError } = await supabase
      .from("conversations")
      .insert({
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      })
      .select()
      .single()

    if (conversationError) {
      return { error: conversationError.message }
    }

    // Add participants
    const { error: participantsError } = await supabase.from("conversation_participants").insert([
      {
        conversation_id: conversation.id,
        profile_id: profile.id,
        created_at: new Date().toISOString(),
      },
      {
        conversation_id: conversation.id,
        profile_id: data.recipient_id,
        created_at: new Date().toISOString(),
      },
    ])

    if (participantsError) {
      return { error: participantsError.message }
    }

    // Send initial message
    await sendMessage({
      conversation_id: conversation.id,
      content: data.initial_message,
    })

    revalidatePath("/messages")
    return { data: conversation }
  } catch (error: any) {
    console.error("Error creating conversation:", error)
    return { error: error.message || "Failed to create conversation" }
  }
}
