"use server"

import { revalidatePath } from "next/cache"
import { getSupabaseServerClient } from "@/lib/supabase"
import type { CalendarEvent } from "@/types/calendar"

/**
 * Convert a gig listing to a calendar event
 */
export async function convertGigToCalendarEvent(gigId: string): Promise<CalendarEvent | null> {
  try {
    const supabase = getSupabaseServerClient()

    // Fetch the gig listing with promoter details
    const { data: gig, error } = await supabase
      .from("gig_listings")
      .select(`
        *,
        promoter:promoter_id (
          id,
          profiles:profile_id (
            id,
            full_name,
            email
          )
        )
      `)
      .eq("id", gigId)
      .single()

    if (error || !gig) {
      console.error("Error fetching gig:", error)
      return null
    }

    // Calculate end time (default to 3 hours if duration not specified)
    const startTime = new Date(gig.event_date)
    const endTime = new Date(startTime)
    endTime.setHours(endTime.getHours() + (gig.duration || 3))

    // Create calendar event
    const calendarEvent: CalendarEvent = {
      id: gig.id,
      title: gig.title,
      description: gig.description,
      location: `${gig.venue || "Venue TBD"}, ${gig.location}`,
      startTime: startTime.toISOString(),
      endTime: endTime.toISOString(),
      organizer: {
        name: gig.promoter.profiles.full_name,
        email: gig.promoter.profiles.email,
      },
    }

    return calendarEvent
  } catch (error) {
    console.error("Error converting gig to calendar event:", error)
    return null
  }
}

/**
 * Convert a booking request to a calendar event
 */
export async function convertBookingToCalendarEvent(bookingId: string): Promise<CalendarEvent | null> {
  try {
    const supabase = getSupabaseServerClient()

    // Fetch the booking with requester and artist details
    const { data: booking, error } = await supabase
      .from("booking_requests")
      .select(`
        *,
        requester:requester_id (
          id,
          full_name,
          email
        ),
        artist:artist_id (
          id,
          artist_profiles:profile_id (
            id,
            artist_name,
            profiles:profile_id (
              id,
              full_name,
              email
            )
          )
        )
      `)
      .eq("id", bookingId)
      .single()

    if (error || !booking) {
      console.error("Error fetching booking:", error)
      return null
    }

    // Calculate end time (default to 2 hours)
    const startTime = new Date(booking.event_date)
    const endTime = new Date(startTime)
    endTime.setHours(endTime.getHours() + 2)

    // Create calendar event
    const calendarEvent: CalendarEvent = {
      id: booking.id,
      title: booking.event_name,
      description: booking.event_description || `Booking for ${booking.artist.artist_profiles.artist_name}`,
      location: `${booking.event_venue || "Venue TBD"}, ${booking.event_location}`,
      startTime: startTime.toISOString(),
      endTime: endTime.toISOString(),
      organizer: {
        name: booking.requester.full_name,
        email: booking.requester.email,
      },
      attendees: [
        {
          name: booking.artist.artist_profiles.profiles.full_name,
          email: booking.artist.artist_profiles.profiles.email,
        },
      ],
    }

    return calendarEvent
  } catch (error) {
    console.error("Error converting booking to calendar event:", error)
    return null
  }
}

/**
 * Save user calendar preferences
 */
export async function saveCalendarPreferences(data: {
  defaultCalendar: string
  autoSync: boolean
}): Promise<{ success: boolean; error?: string }> {
  try {
    const supabase = getSupabaseServerClient()

    // Get the current user
    const {
      data: { user },
      error: userError,
    } = await supabase.auth.getUser()

    if (userError || !user) {
      return { success: false, error: "Not authenticated" }
    }

    // Get the profile ID
    const { data: profile, error: profileError } = await supabase
      .from("profiles")
      .select("id")
      .eq("user_id", user.id)
      .single()

    if (profileError || !profile) {
      return { success: false, error: "Profile not found" }
    }

    // Update the profile with calendar preferences
    const { error: updateError } = await supabase
      .from("profiles")
      .update({
        calendar_preferences: {
          defaultCalendar: data.defaultCalendar,
          autoSync: data.autoSync,
        },
        updated_at: new Date().toISOString(),
      })
      .eq("id", profile.id)

    if (updateError) {
      return { success: false, error: updateError.message }
    }

    // Revalidate the profile page
    revalidatePath("/profile")

    return { success: true }
  } catch (error: any) {
    return { success: false, error: error.message || "Failed to save calendar preferences" }
  }
}
