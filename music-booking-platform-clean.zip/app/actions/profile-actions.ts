"use server"

import { revalidatePath } from "next/cache"
import { getSupabaseServerClient } from "@/lib/supabase"

export async function updateProfile(formData: FormData) {
  try {
    const supabase = getSupabaseServerClient()

    const userId = formData.get("userId") as string
    const fullName = formData.get("fullName") as string
    const username = formData.get("username") as string
    const bio = formData.get("bio") as string
    const location = formData.get("location") as string
    const website = formData.get("website") as string

    // Check if username is taken (if changed)
    if (username) {
      const { data: existingUser, error: checkError } = await supabase
        .from("profiles")
        .select("id, username")
        .eq("username", username)
        .neq("user_id", userId)
        .single()

      if (existingUser) {
        return { success: false, error: "Username is already taken" }
      }
    }

    // Update profile
    const { data, error } = await supabase
      .from("profiles")
      .update({
        full_name: fullName,
        username,
        bio,
        location,
        website,
        updated_at: new Date().toISOString(),
      })
      .eq("user_id", userId)
      .select()
      .single()

    if (error) {
      throw error
    }

    return { success: true, data }
  } catch (error: any) {
    console.error("Error updating profile:", error)
    return { success: false, error: error.message || "Failed to update profile" }
  }
}

export async function updateAvatar(userId: string, avatarUrl: string) {
  try {
    const supabase = getSupabaseServerClient()

    const { data, error } = await supabase
      .from("profiles")
      .update({
        avatar_url: avatarUrl,
        updated_at: new Date().toISOString(),
      })
      .eq("user_id", userId)
      .select()
      .single()

    if (error) {
      throw error
    }

    // Also update the user's auth metadata
    await supabase.auth.updateUser({
      data: { avatar_url: avatarUrl },
    })

    return { success: true, data }
  } catch (error: any) {
    console.error("Error updating avatar:", error)
    return { success: false, error: error.message || "Failed to update avatar" }
  }
}

export async function getProfile(userId: string) {
  try {
    const supabase = getSupabaseServerClient()

    const { data, error } = await supabase.from("profiles").select("*").eq("user_id", userId).single()

    if (error) {
      throw error
    }

    return { success: true, data }
  } catch (error: any) {
    console.error("Error fetching profile:", error)
    return { success: false, error: error.message || "Failed to fetch profile" }
  }
}

export async function updatePreferences(data: { preferences: any }) {
  try {
    const supabase = getSupabaseServerClient()

    // Get the current user
    const {
      data: { user },
    } = await supabase.auth.getUser()
    if (!user) {
      return { error: "Not authenticated" }
    }

    // Get the profile ID
    const { data: profile } = await supabase.from("profiles").select("id").eq("user_id", user.id).single()

    if (!profile) {
      return { error: "Profile not found" }
    }

    // Update the profile with preferences
    const { error: profileError } = await supabase
      .from("profiles")
      .update({
        preferences: data.preferences,
        updated_at: new Date().toISOString(),
      })
      .eq("id", profile.id)

    if (profileError) {
      return { error: profileError.message }
    }

    // Revalidate the profile page
    revalidatePath("/profile")

    return { success: true }
  } catch (error: any) {
    return { error: error.message || "Failed to update preferences" }
  }
}

export async function replyToReview(data: { reviewId: string; replyText: string }) {
  try {
    const supabase = getSupabaseServerClient()

    // Get the current user
    const {
      data: { user },
    } = await supabase.auth.getUser()
    if (!user) {
      return { error: "Not authenticated" }
    }

    // Get the profile ID
    const { data: profile } = await supabase.from("profiles").select("id").eq("user_id", user.id).single()

    if (!profile) {
      return { error: "Profile not found" }
    }

    // Update the review with the reply
    const { error: reviewError } = await supabase
      .from("reviews")
      .update({
        reply: data.replyText,
        reply_date: new Date().toISOString(),
      })
      .eq("id", data.reviewId)
      .eq("artist_id", profile.id) // Ensure the review belongs to this artist

    if (reviewError) {
      return { error: reviewError.message }
    }

    // Revalidate the profile page
    revalidatePath("/profile")

    return { success: true }
  } catch (error: any) {
    return { error: error.message || "Failed to reply to review" }
  }
}

export async function reportReview(data: { reviewId: string }) {
  try {
    const supabase = getSupabaseServerClient()

    // Get the current user
    const {
      data: { user },
    } = await supabase.auth.getUser()
    if (!user) {
      return { error: "Not authenticated" }
    }

    // Create a report
    const { error: reportError } = await supabase.from("reports").insert({
      review_id: data.reviewId,
      reporter_id: user.id,
      report_type: "inappropriate_content",
      status: "pending",
      created_at: new Date().toISOString(),
    })

    if (reportError) {
      return { error: reportError.message }
    }

    return { success: true }
  } catch (error: any) {
    return { error: error.message || "Failed to report review" }
  }
}

// Add the missing uploadMedia export
export async function uploadMedia(formData: FormData) {
  try {
    const supabase = getSupabaseServerClient()

    // Get the current user
    const {
      data: { user },
    } = await supabase.auth.getUser()
    if (!user) {
      return { error: "Not authenticated" }
    }

    // Get the profile ID
    const { data: profile } = await supabase.from("profiles").select("id").eq("user_id", user.id).single()

    if (!profile) {
      return { error: "Profile not found" }
    }

    // Extract form data
    const mediaType = formData.get("mediaType") as string
    const title = formData.get("title") as string
    const file = formData.get("file") as File

    if (!file || !title || !mediaType) {
      return { error: "Missing required fields" }
    }

    // Upload the file to storage
    const fileExt = file.name.split(".").pop()
    const fileName = `${profile.id}/${mediaType}/${Date.now()}.${fileExt}`

    const { error: uploadError, data: uploadData } = await supabase.storage.from("media").upload(fileName, file, {
      cacheControl: "3600",
      upsert: false,
    })

    if (uploadError) {
      return { error: uploadError.message }
    }

    // Get the public URL
    const {
      data: { publicUrl },
    } = supabase.storage.from("media").getPublicUrl(fileName)

    // Save the media reference to the database
    const { error: dbError } = await supabase.from("artist_media").insert({
      profile_id: profile.id,
      title,
      media_type: mediaType,
      file_path: fileName,
      public_url: publicUrl,
      created_at: new Date().toISOString(),
    })

    if (dbError) {
      return { error: dbError.message }
    }

    // Revalidate the profile page
    revalidatePath("/artist/profile")
    return { success: true, url: publicUrl }
  } catch (error: any) {
    return { error: error.message || "Failed to upload media" }
  }
}

export async function deleteMedia(id: string) {
  try {
    const supabase = getSupabaseServerClient()

    // Get the current user
    const {
      data: { user },
    } = await supabase.auth.getUser()
    if (!user) {
      return { error: "Not authenticated" }
    }

    // Get the profile ID
    const { data: profile } = await supabase.from("profiles").select("id").eq("user_id", user.id).single()

    if (!profile) {
      return { error: "Profile not found" }
    }

    // Get the media item
    const { data: media } = await supabase
      .from("artist_media")
      .select("*")
      .eq("id", id)
      .eq("profile_id", profile.id)
      .single()

    if (!media) {
      return { error: "Media not found or you don't have permission" }
    }

    // Delete from storage
    const { error: storageError } = await supabase.storage.from("media").remove([media.file_path])

    if (storageError) {
      console.error("Error deleting from storage:", storageError)
      // Continue anyway to delete the database record
    }

    // Delete from database
    const { error: dbError } = await supabase.from("artist_media").delete().eq("id", id)

    if (dbError) {
      return { error: dbError.message }
    }

    // Revalidate the profile page
    revalidatePath("/artist/profile")
    return { success: true }
  } catch (error: any) {
    return { error: error.message || "Failed to delete media" }
  }
}

export async function importVideo(data: {
  title: string
  videoUrl: string
  embedUrl: string
  thumbnailUrl: string
  platform: string
}) {
  try {
    const supabase = getSupabaseServerClient()

    // Get the current user
    const {
      data: { user },
    } = await supabase.auth.getUser()
    if (!user) {
      return { error: "Not authenticated" }
    }

    // Get the profile ID
    const { data: profile } = await supabase.from("profiles").select("id").eq("user_id", user.id).single()

    if (!profile) {
      return { error: "Profile not found" }
    }

    // Save the video reference to the database
    const { error: dbError } = await supabase.from("artist_media").insert({
      profile_id: profile.id,
      title: data.title,
      media_type: "video",
      file_path: data.videoUrl, // Storing the original URL
      public_url: data.embedUrl, // Storing the embed URL
      thumbnail_url: data.thumbnailUrl, // Storing the thumbnail URL
      platform: data.platform, // Storing the platform (YouTube or Vimeo)
      created_at: new Date().toISOString(),
    })

    if (dbError) {
      return { error: dbError.message }
    }

    // Revalidate the profile page
    revalidatePath("/artist/profile")
    return { success: true, url: data.embedUrl }
  } catch (error: any) {
    return { error: error.message || "Failed to import video" }
  }
}
