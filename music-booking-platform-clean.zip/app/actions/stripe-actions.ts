"use server"

import Stripe from "stripe"
import { getSupabaseServerClient } from "@/lib/server/supabase-server"
import { getHeaderValue } from "@/lib/server/headers"

// Initialize Stripe
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || "", {
  apiVersion: "2023-10-16",
})

// Create a checkout session
export async function createCheckoutSession({
  priceId,
  planName,
  billingCycle,
  returnUrl,
}: {
  priceId: string
  planName: string
  billingCycle: string
  returnUrl: string
}) {
  try {
    const supabase = getSupabaseServerClient()

    // Get the current user
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      return { error: "Not authenticated" }
    }

    // Get the user's profile
    const { data: profile } = await supabase
      .from("profiles")
      .select("id, full_name, email")
      .eq("user_id", user.id)
      .single()

    if (!profile) {
      return { error: "Profile not found" }
    }

    // Create a checkout session
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ["card"],
      billing_address_collection: "auto",
      customer_email: profile.email,
      line_items: [
        {
          price: priceId,
          quantity: 1,
        },
      ],
      mode: "subscription",
      allow_promotion_codes: true,
      subscription_data: {
        metadata: {
          profile_id: profile.id,
          plan: planName.toLowerCase(),
          billing_cycle: billingCycle,
        },
      },
      metadata: {
        profile_id: profile.id,
        plan: planName.toLowerCase(),
        billing_cycle: billingCycle,
      },
      success_url: `${returnUrl}?success=true&session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${returnUrl}?canceled=true`,
    })

    return { url: session.url }
  } catch (error: any) {
    console.error("Error creating checkout session:", error)
    return { error: error.message || "Failed to create checkout session" }
  }
}

// Handle Stripe webhook events
export async function handleStripeWebhook(request: Request) {
  try {
    const body = await request.text()
    const signature = getHeaderValue(request.headers, "stripe-signature")

    if (!signature) {
      return new Response("Webhook Error: No signature provided", { status: 400 })
    }

    // Verify webhook signature
    let event: Stripe.Event
    try {
      event = stripe.webhooks.constructEvent(body, signature, process.env.STRIPE_WEBHOOK_SECRET || "")
    } catch (err: any) {
      console.error(`Webhook signature verification failed: ${err.message}`)
      return new Response(`Webhook Error: ${err.message}`, { status: 400 })
    }

    const supabase = getSupabaseServerClient()

    // Handle the event
    switch (event.type) {
      case "checkout.session.completed": {
        const session = event.data.object as Stripe.Checkout.Session
        const subscriptionId = session.subscription as string
        const profileId = session.metadata?.profile_id

        if (profileId && subscriptionId) {
          // Get subscription details
          const subscription = await stripe.subscriptions.retrieve(subscriptionId)
          const plan = subscription.metadata.plan || "pro"
          const periodEnd = new Date(subscription.current_period_end * 1000)

          // Update profile with subscription info
          await supabase
            .from("profiles")
            .update({
              subscription_status: "active",
              subscription_plan: plan,
              subscription_id: subscriptionId,
              subscription_period_end: periodEnd.toISOString(),
              subscription_created_at: new Date().toISOString(),
            })
            .eq("id", profileId)

          // Record subscription history
          const invoice = await stripe.invoices.retrieve(session.invoice as string)
          await supabase.from("subscription_history").insert({
            profile_id: profileId,
            event_type: "subscription_created",
            plan: plan,
            amount: invoice.amount_paid / 100, // Convert from cents
            currency: invoice.currency,
            status: "paid",
            invoice_url: invoice.hosted_invoice_url,
          })
        }
        break
      }

      case "invoice.payment_succeeded": {
        const invoice = event.data.object as Stripe.Invoice
        const subscriptionId = invoice.subscription as string

        if (subscriptionId) {
          const subscription = await stripe.subscriptions.retrieve(subscriptionId)
          const profileId = subscription.metadata.profile_id
          const plan = subscription.metadata.plan || "pro"
          const periodEnd = new Date(subscription.current_period_end * 1000)

          if (profileId) {
            // Update subscription period end
            await supabase
              .from("profiles")
              .update({
                subscription_status: "active",
                subscription_period_end: periodEnd.toISOString(),
              })
              .eq("id", profileId)

            // Record payment in history
            await supabase.from("subscription_history").insert({
              profile_id: profileId,
              event_type: "payment_succeeded",
              plan: plan,
              amount: invoice.amount_paid / 100,
              currency: invoice.currency,
              status: "paid",
              invoice_url: invoice.hosted_invoice_url,
            })
          }
        }
        break
      }

      case "customer.subscription.updated": {
        const subscription = event.data.object as Stripe.Subscription
        const profileId = subscription.metadata.profile_id
        const plan = subscription.metadata.plan || "pro"
        const periodEnd = new Date(subscription.current_period_end * 1000)

        if (profileId) {
          // Update subscription details
          await supabase
            .from("profiles")
            .update({
              subscription_status: subscription.status,
              subscription_plan: plan,
              subscription_period_end: periodEnd.toISOString(),
            })
            .eq("id", profileId)

          // Record update in history
          await supabase.from("subscription_history").insert({
            profile_id: profileId,
            event_type: "subscription_updated",
            plan: plan,
            status: subscription.status,
          })
        }
        break
      }

      case "customer.subscription.deleted": {
        const subscription = event.data.object as Stripe.Subscription
        const profileId = subscription.metadata.profile_id

        if (profileId) {
          // Update profile to free plan
          await supabase
            .from("profiles")
            .update({
              subscription_status: "canceled",
              subscription_period_end: new Date(subscription.current_period_end * 1000).toISOString(),
            })
            .eq("id", profileId)

          // Record cancellation in history
          await supabase.from("subscription_history").insert({
            profile_id: profileId,
            event_type: "subscription_canceled",
            status: "canceled",
          })
        }
        break
      }
    }

    return new Response(JSON.stringify({ received: true }), {
      status: 200,
      headers: { "Content-Type": "application/json" },
    })
  } catch (error: any) {
    console.error("Error handling webhook:", error)
    return new Response(`Webhook Error: ${error.message}`, { status: 400 })
  }
}

// Cancel a subscription
export async function cancelSubscription() {
  try {
    const supabase = getSupabaseServerClient()

    // Get the current user
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      return { error: "Not authenticated" }
    }

    // Get the user's profile with subscription info
    const { data: profile } = await supabase
      .from("profiles")
      .select("id, subscription_id")
      .eq("user_id", user.id)
      .single()

    if (!profile || !profile.subscription_id) {
      return { error: "No active subscription found" }
    }

    // Cancel the subscription in Stripe
    await stripe.subscriptions.update(profile.subscription_id, {
      cancel_at_period_end: true,
    })

    // Update the profile status
    await supabase
      .from("profiles")
      .update({
        subscription_status: "canceling",
      })
      .eq("id", profile.id)

    return { success: true, message: "Subscription will be canceled at the end of the billing period" }
  } catch (error: any) {
    console.error("Error canceling subscription:", error)
    return { error: error.message || "Failed to cancel subscription" }
  }
}

// Reactivate a canceled subscription
export async function reactivateSubscription() {
  try {
    const supabase = getSupabaseServerClient()

    // Get the current user
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      return { error: "Not authenticated" }
    }

    // Get the user's profile with subscription info
    const { data: profile } = await supabase
      .from("profiles")
      .select("id, subscription_id")
      .eq("user_id", user.id)
      .single()

    if (!profile || !profile.subscription_id) {
      return { error: "No subscription found to reactivate" }
    }

    // Reactivate the subscription in Stripe
    await stripe.subscriptions.update(profile.subscription_id, {
      cancel_at_period_end: false,
    })

    // Update the profile status
    await supabase
      .from("profiles")
      .update({
        subscription_status: "active",
      })
      .eq("id", profile.id)

    return { success: true, message: "Subscription has been reactivated" }
  } catch (error: any) {
    console.error("Error reactivating subscription:", error)
    return { error: error.message || "Failed to reactivate subscription" }
  }
}

// Get subscription invoices
export async function getSubscriptionInvoices() {
  try {
    const supabase = getSupabaseServerClient()

    // Get the current user
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      return { error: "Not authenticated" }
    }

    // Get the user's profile with subscription info
    const { data: profile } = await supabase
      .from("profiles")
      .select("id, subscription_id")
      .eq("user_id", user.id)
      .single()

    if (!profile || !profile.subscription_id) {
      return { data: [] }
    }

    // Get invoices from Stripe
    const invoices = await stripe.invoices.list({
      subscription: profile.subscription_id,
      limit: 10,
    })

    return {
      data: invoices.data.map((invoice) => ({
        id: invoice.id,
        amount: invoice.amount_paid / 100,
        currency: invoice.currency,
        status: invoice.status,
        created: new Date(invoice.created * 1000).toISOString(),
        period_start: new Date(invoice.period_start * 1000).toISOString(),
        period_end: new Date(invoice.period_end * 1000).toISOString(),
        invoice_url: invoice.hosted_invoice_url,
        pdf_url: invoice.invoice_pdf,
      })),
    }
  } catch (error: any) {
    console.error("Error fetching invoices:", error)
    return { error: error.message || "Failed to fetch invoices" }
  }
}

// Get upcoming invoice
export async function getUpcomingInvoice() {
  try {
    const supabase = getSupabaseServerClient()

    // Get the current user
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      return { error: "Not authenticated" }
    }

    // Get the user's profile with subscription info
    const { data: profile } = await supabase
      .from("profiles")
      .select("id, subscription_id")
      .eq("user_id", user.id)
      .single()

    if (!profile || !profile.subscription_id) {
      return { data: null }
    }

    // Get upcoming invoice from Stripe
    const invoice = await stripe.invoices.retrieveUpcoming({
      subscription: profile.subscription_id,
    })

    return {
      data: {
        amount: invoice.amount_due / 100,
        currency: invoice.currency,
        next_payment_attempt: invoice.next_payment_attempt
          ? new Date(invoice.next_payment_attempt * 1000).toISOString()
          : null,
        period_start: new Date(invoice.period_start * 1000).toISOString(),
        period_end: new Date(invoice.period_end * 1000).toISOString(),
      },
    }
  } catch (error: any) {
    console.error("Error fetching upcoming invoice:", error)
    return { error: error.message || "Failed to fetch upcoming invoice" }
  }
}

// Check if user has access to a premium feature
export async function checkFeatureAccess(featureKey: string) {
  try {
    const supabase = getSupabaseServerClient()

    // Get the current user
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      return { hasAccess: false, reason: "Not authenticated" }
    }

    // Get the user's profile with subscription info
    const { data: profile } = await supabase
      .from("profiles")
      .select("id, subscription_status, subscription_plan")
      .eq("user_id", user.id)
      .single()

    if (!profile) {
      return { hasAccess: false, reason: "Profile not found" }
    }

    // Default to free plan if no subscription
    const plan = profile.subscription_status === "active" ? profile.subscription_plan : "free"

    // Get feature value for the user's plan
    const { data: feature } = await supabase
      .from("subscription_features")
      .select("feature_value")
      .eq("plan", plan)
      .eq("feature_key", featureKey)
      .single()

    if (!feature) {
      return { hasAccess: false, reason: "Feature not available on your plan" }
    }

    // Check if feature is enabled
    if (feature.feature_value === "true") {
      return { hasAccess: true }
    }

    // For numeric limits, return the limit value
    if (!isNaN(Number(feature.feature_value))) {
      return { hasAccess: true, limit: Number(feature.feature_value) }
    }

    // For array values (like export formats)
    if (Array.isArray(feature.feature_value)) {
      return { hasAccess: true, options: feature.feature_value }
    }

    // For unlimited values
    if (feature.feature_value === "unlimited") {
      return { hasAccess: true, limit: Number.POSITIVE_INFINITY }
    }

    return { hasAccess: true, value: feature.feature_value }
  } catch (error: any) {
    console.error("Error checking feature access:", error)
    return { hasAccess: false, reason: error.message || "Failed to check feature access" }
  }
}
