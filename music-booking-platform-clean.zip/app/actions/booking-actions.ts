"use server"

import { revalidatePath } from "next/cache"
import { getSupabaseServerClient } from "@/lib/supabase"

export async function createBookingRequest(formData: FormData) {
  try {
    const supabase = getSupabaseServerClient()

    // Get the current user
    const {
      data: { user },
    } = await supabase.auth.getUser()
    if (!user) {
      return { error: "Not authenticated" }
    }

    // Get the profile ID
    const { data: profile } = await supabase.from("profiles").select("id").eq("user_id", user.id).single()

    if (!profile) {
      return { error: "Profile not found" }
    }

    // Extract form data
    const artistId = formData.get("artistId") as string
    const eventName = formData.get("eventName") as string
    const eventDate = formData.get("eventDate") as string
    const eventLocation = formData.get("eventLocation") as string
    const eventVenue = formData.get("eventVenue") as string
    const eventDescription = formData.get("eventDescription") as string
    const budget = formData.get("budget") as string
    const contactEmail = formData.get("contactEmail") as string
    const contactPhone = formData.get("contactPhone") as string

    if (!artistId || !eventName || !eventDate || !eventLocation) {
      return { error: "Missing required fields" }
    }

    // Create the booking request
    const { error, data } = await supabase
      .from("booking_requests")
      .insert({
        requester_id: profile.id,
        artist_id: artistId,
        event_name: eventName,
        event_date: eventDate,
        event_location: eventLocation,
        event_venue: eventVenue,
        event_description: eventDescription,
        budget,
        contact_email: contactEmail,
        contact_phone: contactPhone,
        status: "pending",
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      })
      .select()

    if (error) {
      return { error: error.message }
    }

    // Revalidate the bookings page
    revalidatePath("/bookings")
    return { success: true, bookingId: data?.[0]?.id }
  } catch (error: any) {
    return { error: error.message || "Failed to create booking request" }
  }
}

export async function updateBookingStatus(id: string, status: "accepted" | "rejected" | "cancelled") {
  try {
    const supabase = getSupabaseServerClient()

    // Get the current user
    const {
      data: { user },
    } = await supabase.auth.getUser()
    if (!user) {
      return { error: "Not authenticated" }
    }

    // Get the profile ID
    const { data: profile } = await supabase.from("profiles").select("id").eq("user_id", user.id).single()

    if (!profile) {
      return { error: "Profile not found" }
    }

    // Get the booking request
    const { data: booking } = await supabase.from("booking_requests").select("*").eq("id", id).single()

    if (!booking) {
      return { error: "Booking request not found" }
    }

    // Check if user is authorized (either the artist or the requester)
    if (booking.artist_id !== profile.id && booking.requester_id !== profile.id) {
      return { error: "Not authorized" }
    }

    // Update the booking status
    const { error } = await supabase
      .from("booking_requests")
      .update({
        status,
        updated_at: new Date().toISOString(),
      })
      .eq("id", id)

    if (error) {
      return { error: error.message }
    }

    // Revalidate the bookings page
    revalidatePath("/bookings")
    return { success: true }
  } catch (error: any) {
    return { error: error.message || "Failed to update booking status" }
  }
}
