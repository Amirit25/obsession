"use server"

import { getSupabaseServerClient } from "@/lib/supabase"
import { revalidatePath } from "next/cache"

type GigListingFormData = {
  title: string
  description: string
  eventDate: string
  applicationDeadline: string
  location: string
  venue?: string
  genres: string[]
  feeMin: number
  feeMax: number
  feeCurrency: string
  audienceSize?: number
  duration?: number
  requirements?: string
  perks?: string
}

export async function createGigListing(formData: GigListingFormData, promoterId: string) {
  const supabase = getSupabaseServerClient()

  try {
    const { error } = await supabase.from("gig_listings").insert({
      promoter_id: promoterId,
      title: formData.title,
      description: formData.description,
      event_date: formData.eventDate,
      application_deadline: formData.applicationDeadline,
      location: formData.location,
      venue: formData.venue,
      genres: formData.genres,
      fee_range: {
        min: formData.feeMin,
        max: formData.feeMax,
        currency: formData.feeCurrency,
      },
      audience_size: formData.audienceSize,
      duration: formData.duration,
      requirements: formData.requirements,
      perks: formData.perks,
      status: "open",
    })

    if (error) {
      return { success: false, error: error.message }
    }

    revalidatePath("/promoter")
    return { success: true }
  } catch (error) {
    return { success: false, error: "Failed to create gig listing" }
  }
}

export async function getGigListings(limit = 10, offset = 0, filters?: any) {
  const supabase = getSupabaseServerClient()

  let query = supabase
    .from("gig_listings")
    .select(`
      *,
      promoter_profiles:promoter_id (
        id,
        company_name,
        profiles:profile_id (
          full_name,
          location
        )
      )
    `)
    .eq("status", "open")
    .order("created_at", { ascending: false })
    .range(offset, offset + limit - 1)

  // Apply filters if provided
  if (filters) {
    if (filters.genres && filters.genres.length > 0) {
      query = query.contains("genres", filters.genres)
    }

    if (filters.location) {
      query = query.ilike("location", `%${filters.location}%`)
    }

    if (filters.minFee) {
      query = query.gte("fee_range->min", filters.minFee)
    }
  }

  const { data, error } = await query

  if (error) {
    console.error("Error fetching gig listings:", error)
    return []
  }

  return data
}

export async function applyToGig(
  gigId: string,
  artistId: string,
  message: string,
  proposedFee: { amount: number; currency: string },
) {
  const supabase = getSupabaseServerClient()

  try {
    // Check if already applied
    const { data: existingApplication } = await supabase
      .from("applications")
      .select("id")
      .eq("gig_id", gigId)
      .eq("artist_id", artistId)
      .single()

    if (existingApplication) {
      return { success: false, error: "You have already applied to this gig" }
    }

    // Create application
    const { error } = await supabase.from("applications").insert({
      gig_id: gigId,
      artist_id: artistId,
      message,
      proposed_fee: proposedFee,
      status: "pending",
    })

    if (error) {
      return { success: false, error: error.message }
    }

    // Create conversation
    const { data: gig } = await supabase.from("gig_listings").select("promoter_id").eq("id", gigId).single()

    if (gig) {
      // Get the application ID
      const { data: application } = await supabase
        .from("applications")
        .select("id")
        .eq("gig_id", gigId)
        .eq("artist_id", artistId)
        .single()

      if (application) {
        await supabase.from("conversations").insert({
          application_id: application.id,
          artist_id: artistId,
          promoter_id: gig.promoter_id,
        })
      }
    }

    revalidatePath("/artist")
    return { success: true }
  } catch (error) {
    return { success: false, error: "Failed to apply to gig" }
  }
}
