import { headers } from "next/headers"

export default function HeadersDebugPage() {
  const headersList = headers()

  // Convert headers to an array for display
  const headersArray = Array.from(headersList.entries())

  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-4">Headers Debug Page</h1>
      <div className="bg-card p-4 rounded-md">
        <h2 className="font-semibold mb-2">All Request Headers:</h2>
        <ul className="space-y-2">
          {headersArray.map(([name, value]) => (
            <li key={name} className="font-mono text-sm">
              <span className="font-semibold">{name}:</span> {value}
            </li>
          ))}
        </ul>
      </div>
    </div>
  )
}
