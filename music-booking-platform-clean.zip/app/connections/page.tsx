"use client"

import type React from "react"

import { useState } from "react"
import {
  Music2,
  Youtube,
  Instagram,
  Twitter,
  Disc3,
  Radio,
  Link,
  CheckCircle2,
  XCircle,
  PlusCircle,
  Share2,
  Video,
} from "lucide-react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { toast } from "@/hooks/use-toast"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface PlatformSettings {
  autoSync: boolean
  syncFrequency: "hourly" | "daily" | "weekly"
  notificationsEnabled: boolean
  dataSharing: boolean
  displayName?: string
}

interface PlatformConnection {
  id: string
  name: string
  icon: React.ElementType
  connected: boolean
  status: "active" | "pending" | "error" | "disconnected"
  lastSync?: string
  accountName?: string
  settings?: PlatformSettings
}

export default function ConnectionsPage() {
  const [selectedPlatform, setSelectedPlatform] = useState<PlatformConnection | null>(null)
  const [platformSettings, setPlatformSettings] = useState<PlatformSettings>({
    autoSync: true,
    syncFrequency: "daily",
    notificationsEnabled: true,
    dataSharing: false,
    displayName: "",
  })
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [isSoundcloudDialogOpen, setIsSoundcloudDialogOpen] = useState(false)
  const [soundcloudForm, setSoundcloudForm] = useState({
    username: "",
    password: "",
    rememberMe: true,
  })

  const [isSoundcloudAuthInProgress, setIsSoundcloudAuthInProgress] = useState(false)
  const [soundcloudAuthUrl, setSoundcloudAuthUrl] = useState("")

  const [isBandcampDialogOpen, setIsBandcampDialogOpen] = useState(false)
  const [bandcampAuthUrl, setBandcampAuthUrl] = useState("")
  const [bandcampAuthInProgress, setBandcampAuthInProgress] = useState(false)

  const [connections, setConnections] = useState<PlatformConnection[]>([
    {
      id: "spotify",
      name: "Spotify",
      icon: Music2,
      connected: true,
      status: "active",
      lastSync: "10 minutes ago",
      accountName: "Jane Doe",
      settings: {
        autoSync: true,
        syncFrequency: "daily",
        notificationsEnabled: true,
        dataSharing: false,
      },
    },
    {
      id: "apple-music",
      name: "Apple Music",
      icon: Music2,
      connected: true,
      status: "active",
      lastSync: "15 minutes ago",
      accountName: "jane.doe@example.com",
      settings: {
        autoSync: true,
        syncFrequency: "daily",
        notificationsEnabled: true,
        dataSharing: false,
      },
    },
    {
      id: "youtube",
      name: "YouTube",
      icon: Youtube,
      connected: true,
      status: "active",
      lastSync: "30 minutes ago",
      accountName: "Jane Doe Music",
      settings: {
        autoSync: true,
        syncFrequency: "daily",
        notificationsEnabled: true,
        dataSharing: false,
      },
    },
    {
      id: "instagram",
      name: "Instagram",
      icon: Instagram,
      connected: true,
      status: "active",
      lastSync: "1 hour ago",
      accountName: "@janedoemusic",
      settings: {
        autoSync: true,
        syncFrequency: "daily",
        notificationsEnabled: true,
        dataSharing: false,
      },
    },
    {
      id: "twitter",
      name: "Twitter/X",
      icon: Twitter,
      connected: false,
      status: "disconnected",
      settings: {
        autoSync: true,
        syncFrequency: "daily",
        notificationsEnabled: true,
        dataSharing: false,
      },
    },
    {
      id: "tiktok",
      name: "TikTok",
      icon: Radio,
      connected: true,
      status: "error",
      lastSync: "Failed 2 hours ago",
      accountName: "@janedoemusic",
      settings: {
        autoSync: true,
        syncFrequency: "daily",
        notificationsEnabled: true,
        dataSharing: false,
      },
    },
    {
      id: "soundcloud",
      name: "SoundCloud",
      icon: Disc3,
      connected: false,
      status: "disconnected",
      settings: {
        autoSync: true,
        syncFrequency: "daily",
        notificationsEnabled: true,
        dataSharing: false,
      },
    },
    {
      id: "bandcamp",
      name: "Bandcamp",
      icon: Music2,
      connected: false,
      status: "disconnected",
      settings: {
        autoSync: true,
        syncFrequency: "daily",
        notificationsEnabled: true,
        dataSharing: false,
      },
    },
    // Add YouTube Music
    {
      id: "youtube-music",
      name: "YouTube Music",
      icon: Music2,
      connected: true,
      status: "active",
      lastSync: "45 minutes ago",
      accountName: "Jane Doe Music",
      settings: {
        autoSync: true,
        syncFrequency: "daily",
        notificationsEnabled: true,
        dataSharing: false,
      },
    },
    // Add Deezer
    {
      id: "deezer",
      name: "Deezer",
      icon: Music2,
      connected: false,
      status: "disconnected",
      settings: {
        autoSync: true,
        syncFrequency: "daily",
        notificationsEnabled: true,
        dataSharing: false,
      },
    },
    // Add Amazon Music
    {
      id: "amazon-music",
      name: "Amazon Music",
      icon: Music2,
      connected: false,
      status: "disconnected",
      settings: {
        autoSync: true,
        syncFrequency: "daily",
        notificationsEnabled: true,
        dataSharing: false,
      },
    },
    // Add Tidal
    {
      id: "tidal",
      name: "Tidal",
      icon: Music2,
      connected: false,
      status: "disconnected",
      settings: {
        autoSync: true,
        syncFrequency: "daily",
        notificationsEnabled: true,
        dataSharing: false,
      },
    },
    // Add Facebook
    {
      id: "facebook",
      name: "Facebook",
      icon: Share2,
      connected: true,
      status: "active",
      lastSync: "2 hours ago",
      accountName: "Jane Doe",
      settings: {
        autoSync: true,
        syncFrequency: "daily",
        notificationsEnabled: true,
        dataSharing: false,
      },
    },
    // Add Vimeo
    {
      id: "vimeo",
      name: "Vimeo",
      icon: Video,
      connected: false,
      status: "disconnected",
      settings: {
        autoSync: true,
        syncFrequency: "daily",
        notificationsEnabled: true,
        dataSharing: false,
      },
    },
    // Add Twitch
    {
      id: "twitch",
      name: "Twitch",
      icon: Video,
      connected: false,
      status: "disconnected",
      settings: {
        autoSync: true,
        syncFrequency: "daily",
        notificationsEnabled: true,
        dataSharing: false,
      },
    },
  ])

  const toggleConnection = (id: string) => {
    setConnections(
      connections.map((conn) =>
        conn.id === id
          ? {
              ...conn,
              connected: !conn.connected,
              status: conn.connected ? "disconnected" : "active",
            }
          : conn,
      ),
    )
  }

  const openSettings = (platform: PlatformConnection) => {
    setSelectedPlatform(platform)
    setPlatformSettings({
      autoSync: platform.settings?.autoSync ?? true,
      syncFrequency: platform.settings?.syncFrequency ?? "daily",
      notificationsEnabled: platform.settings?.notificationsEnabled ?? true,
      dataSharing: platform.settings?.dataSharing ?? false,
      displayName: platform.settings?.displayName ?? platform.accountName,
    })
    setIsDialogOpen(true)
  }

  const saveSettings = () => {
    if (!selectedPlatform) return

    setConnections(
      connections.map((conn) =>
        conn.id === selectedPlatform.id
          ? {
              ...conn,
              settings: platformSettings,
              accountName: platformSettings.displayName || conn.accountName,
            }
          : conn,
      ),
    )

    toast({
      title: "Settings saved",
      description: `Your ${selectedPlatform.name} connection settings have been updated.`,
    })

    setIsDialogOpen(false)
  }

  const initiateSoundcloudAuth = async () => {
    // In a real app, this would be an API call to your backend to start the OAuth flow
    setIsSoundcloudAuthInProgress(true)

    try {
      // Simulate API call to get authorization URL
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // This would be returned from your backend in a real implementation
      const authUrl =
        "https://soundcloud.com/connect?client_id=YOUR_CLIENT_ID&response_type=code&redirect_uri=YOUR_REDIRECT_URI&scope=non-expiring"
      setSoundcloudAuthUrl(authUrl)

      // Open the dialog with the auth URL
      setIsSoundcloudDialogOpen(true)
    } catch (error) {
      toast({
        title: "Authentication Error",
        description: "Failed to initiate Soundcloud authentication.",
        variant: "destructive",
      })
    } finally {
      setIsSoundcloudAuthInProgress(false)
    }
  }

  const completeSoundcloudAuth = () => {
    // In a real app, this would verify the OAuth callback and store the token
    setConnections(
      connections.map((conn) =>
        conn.id === "soundcloud"
          ? {
              ...conn,
              connected: true,
              status: "active",
              accountName: "YourSoundcloudUsername",
              lastSync: "Just now",
            }
          : conn,
      ),
    )

    toast({
      title: "Soundcloud Connected",
      description: "Your Soundcloud account has been successfully connected.",
    })

    setIsSoundcloudDialogOpen(false)
  }

  const openSoundcloudConnect = () => {
    initiateSoundcloudAuth()
  }

  const connectSoundcloud = () => {
    // In a real app, this would make an API call to authenticate with Soundcloud
    setConnections(
      connections.map((conn) =>
        conn.id === "soundcloud"
          ? {
              ...conn,
              connected: true,
              status: "active",
              accountName: soundcloudForm.username,
              lastSync: "Just now",
            }
          : conn,
      ),
    )

    toast({
      title: "Soundcloud Connected",
      description: "Your Soundcloud account has been successfully connected.",
    })

    setIsSoundcloudDialogOpen(false)
  }

  const initiateBandcampAuth = async () => {
    // In a real app, this would be an API call to your backend to start the OAuth flow
    setBandcampAuthInProgress(true)

    try {
      // Simulate API call to get authorization URL
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // This would be returned from your backend in a real implementation
      const authUrl =
        "https://bandcamp.com/oauth2/authorize?client_id=YOUR_CLIENT_ID&response_type=code&redirect_uri=YOUR_REDIRECT_URI&scope=identity+stream"
      setBandcampAuthUrl(authUrl)

      // Open the dialog with the auth URL
      setIsBandcampDialogOpen(true)
    } catch (error) {
      toast({
        title: "Authentication Error",
        description: "Failed to initiate Bandcamp authentication.",
        variant: "destructive",
      })
    } finally {
      setBandcampAuthInProgress(false)
    }
  }

  const completeBandcampAuth = () => {
    // In a real app, this would verify the OAuth callback and store the token
    setConnections(
      connections.map((conn) =>
        conn.id === "bandcamp"
          ? {
              ...conn,
              connected: true,
              status: "active",
              accountName: "YourBandcampUsername",
              lastSync: "Just now",
            }
          : conn,
      ),
    )

    toast({
      title: "Bandcamp Connected",
      description: "Your Bandcamp account has been successfully connected.",
    })

    setIsBandcampDialogOpen(false)
  }

  const openBandcampConnect = () => {
    initiateBandcampAuth()
  }

  const openSoundcloudConnect_OLD = () => {
    setSoundcloudForm({
      username: "",
      password: "",
      rememberMe: true,
    })
    setIsSoundcloudDialogOpen(true)
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Platform Connections</h1>
        <p className="text-muted-foreground">
          Connect your streaming and social media accounts to track your performance
        </p>
      </div>

      <Tabs defaultValue="all">
        <TabsList>
          <TabsTrigger value="all">All Platforms</TabsTrigger>
          <TabsTrigger value="streaming">Streaming</TabsTrigger>
          <TabsTrigger value="social">Social Media</TabsTrigger>
        </TabsList>
        <TabsContent value="all" className="mt-6">
          <div className="grid gap-4 md:grid-cols-2">
            {connections.map((platform) => (
              <Card key={platform.id}>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <div className="flex items-center space-x-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
                      <platform.icon className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <CardTitle className="text-base">{platform.name}</CardTitle>
                      {platform.accountName && <CardDescription>{platform.accountName}</CardDescription>}
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    {platform.status === "active" && (
                      <Badge variant="outline" className="bg-emerald-500/10 text-emerald-500/20">
                        <CheckCircle2 className="mr-1 h-3 w-3" />
                        Connected
                      </Badge>
                    )}
                    {platform.status === "error" && (
                      <Badge variant="outline" className="bg-red-500/10 text-red-500 border-red-500/20">
                        <XCircle className="mr-1 h-3 w-3" />
                        Error
                      </Badge>
                    )}
                    <Switch checked={platform.connected} onCheckedChange={() => toggleConnection(platform.id)} />
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="text-sm">
                    {platform.connected ? (
                      <div className="flex flex-col space-y-1">
                        <div className="flex items-center justify-between">
                          <span className="text-muted-foreground">Last synced:</span>
                          <span>{platform.lastSync || "Never"}</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-muted-foreground">Data collected:</span>
                          <span>Streams, followers, engagement</span>
                        </div>
                      </div>
                    ) : (
                      <p className="text-muted-foreground">
                        Connect your {platform.name} account to track your performance metrics.
                      </p>
                    )}
                  </div>
                </CardContent>
                <CardFooter>
                  {platform.connected ? (
                    <div className="flex w-full gap-2">
                      <Button variant="outline" className="flex-1">
                        Refresh
                      </Button>
                      <Button variant="outline" className="flex-1" onClick={() => openSettings(platform)}>
                        Settings
                      </Button>
                    </div>
                  ) : (
                    <Button
                      className="w-full"
                      onClick={
                        platform.id === "soundcloud"
                          ? openSoundcloudConnect
                          : platform.id === "bandcamp"
                            ? openBandcampConnect
                            : undefined
                      }
                    >
                      <Link className="mr-2 h-4 w-4" />
                      Connect {platform.name}
                    </Button>
                  )}
                </CardFooter>
              </Card>
            ))}
          </div>
        </TabsContent>
        <TabsContent value="streaming" className="mt-6">
          <div className="grid gap-4 md:grid-cols-2">
            {connections
              .filter((platform) =>
                ["spotify", "apple-music", "youtube", "soundcloud", "bandcamp"].includes(platform.id),
              )
              .map((platform) => (
                <Card key={platform.id}>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <div className="flex items-center space-x-3">
                      <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
                        <platform.icon className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <CardTitle className="text-base">{platform.name}</CardTitle>
                        {platform.accountName && <CardDescription>{platform.accountName}</CardDescription>}
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      {platform.status === "active" && (
                        <Badge variant="outline" className="bg-emerald-500/10 text-emerald-500/20">
                          <CheckCircle2 className="mr-1 h-3 w-3" />
                          Connected
                        </Badge>
                      )}
                      {platform.status === "error" && (
                        <Badge variant="outline" className="bg-red-500/10 text-red-500 border-red-500/20">
                          <XCircle className="mr-1 h-3 w-3" />
                          Error
                        </Badge>
                      )}
                      <Switch checked={platform.connected} onCheckedChange={() => toggleConnection(platform.id)} />
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="text-sm">
                      {platform.connected ? (
                        <div className="flex flex-col space-y-1">
                          <div className="flex items-center justify-between">
                            <span className="text-muted-foreground">Last synced:</span>
                            <span>{platform.lastSync || "Never"}</span>
                          </div>
                          <div className="flex items-center justify-between">
                            <span className="text-muted-foreground">Data collected:</span>
                            <span>Streams, followers, engagement</span>
                          </div>
                        </div>
                      ) : (
                        <p className="text-muted-foreground">
                          Connect your {platform.name} account to track your performance metrics.
                        </p>
                      )}
                    </div>
                  </CardContent>
                  <CardFooter>
                    {platform.connected ? (
                      <div className="flex w-full gap-2">
                        <Button variant="outline" className="flex-1">
                          Refresh
                        </Button>
                        <Button variant="outline" className="flex-1" onClick={() => openSettings(platform)}>
                          Settings
                        </Button>
                      </div>
                    ) : (
                      <Button className="w-full">
                        <Link className="mr-2 h-4 w-4" />
                        Connect {platform.name}
                      </Button>
                    )}
                  </CardFooter>
                </Card>
              ))}
          </div>
        </TabsContent>
        <TabsContent value="social" className="mt-6">
          <div className="grid gap-4 md:grid-cols-2">
            {connections
              .filter((platform) => ["instagram", "twitter", "tiktok"].includes(platform.id))
              .map((platform) => (
                <Card key={platform.id}>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <div className="flex items-center space-x-3">
                      <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
                        <platform.icon className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <CardTitle className="text-base">{platform.name}</CardTitle>
                        {platform.accountName && <CardDescription>{platform.accountName}</CardDescription>}
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      {platform.status === "active" && (
                        <Badge variant="outline" className="bg-emerald-500/10 text-emerald-500/20">
                          <CheckCircle2 className="mr-1 h-3 w-3" />
                          Connected
                        </Badge>
                      )}
                      {platform.status === "error" && (
                        <Badge variant="outline" className="bg-red-500/10 text-red-500 border-red-500/20">
                          <XCircle className="mr-1 h-3 w-3" />
                          Error
                        </Badge>
                      )}
                      <Switch checked={platform.connected} onCheckedChange={() => toggleConnection(platform.id)} />
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="text-sm">
                      {platform.connected ? (
                        <div className="flex flex-col space-y-1">
                          <div className="flex items-center justify-between">
                            <span className="text-muted-foreground">Last synced:</span>
                            <span>{platform.lastSync || "Never"}</span>
                          </div>
                          <div className="flex items-center justify-between">
                            <span className="text-muted-foreground">Data collected:</span>
                            <span>Followers, likes, engagement</span>
                          </div>
                        </div>
                      ) : (
                        <p className="text-muted-foreground">
                          Connect your {platform.name} account to track your social media metrics.
                        </p>
                      )}
                    </div>
                  </CardContent>
                  <CardFooter>
                    {platform.connected ? (
                      <div className="flex w-full gap-2">
                        <Button variant="outline" className="flex-1">
                          Refresh
                        </Button>
                        <Button variant="outline" className="flex-1" onClick={() => openSettings(platform)}>
                          Settings
                        </Button>
                      </div>
                    ) : (
                      <Button className="w-full">
                        <Link className="mr-2 h-4 w-4" />
                        Connect {platform.name}
                      </Button>
                    )}
                  </CardFooter>
                </Card>
              ))}
          </div>
        </TabsContent>
      </Tabs>

      <Card>
        <CardHeader>
          <CardTitle>Add New Connection</CardTitle>
          <CardDescription>Connect additional platforms to enhance your analytics</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-3">
            <Button variant="outline" className="h-auto flex-col py-4">
              <PlusCircle className="h-10 w-10 mb-2" />
              <span className="font-medium">Deezer</span>
            </Button>
            <Button variant="outline" className="h-auto flex-col py-4">
              <PlusCircle className="h-10 w-10 mb-2" />
              <span className="font-medium">Amazon Music</span>
            </Button>
            <Button variant="outline" className="h-auto flex-col py-4">
              <PlusCircle className="h-10 w-10 mb-2" />
              <span className="font-medium">Facebook</span>
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Connection Settings</CardTitle>
          <CardDescription>Manage how your connections sync and share data</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="auto-sync">Auto Sync</Label>
                <p className="text-sm text-muted-foreground">Automatically sync data from connected platforms</p>
              </div>
              <Switch id="auto-sync" defaultChecked />
            </div>
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="notifications">Sync Notifications</Label>
                <p className="text-sm text-muted-foreground">Receive notifications when data is synced</p>
              </div>
              <Switch id="notifications" defaultChecked />
            </div>
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="data-sharing">Data Sharing</Label>
                <p className="text-sm text-muted-foreground">Allow platforms to share data with each other</p>
              </div>
              <Switch id="data-sharing" />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Settings Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>{selectedPlatform?.name} Settings</DialogTitle>
            <DialogDescription>
              Configure how your {selectedPlatform?.name} account connects with ArtistPulse
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="displayName" className="text-right">
                Display Name
              </Label>
              <Input
                id="displayName"
                value={platformSettings.displayName || ""}
                onChange={(e) => setPlatformSettings({ ...platformSettings, displayName: e.target.value })}
                className="col-span-3"
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="syncFrequency" className="text-right">
                Sync Frequency
              </Label>
              <Select
                value={platformSettings.syncFrequency}
                onValueChange={(value) =>
                  setPlatformSettings({
                    ...platformSettings,
                    syncFrequency: value as "hourly" | "daily" | "weekly",
                  })
                }
              >
                <SelectTrigger className="col-span-3">
                  <SelectValue placeholder="Select frequency" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="hourly">Hourly</SelectItem>
                  <SelectItem value="daily">Daily</SelectItem>
                  <SelectItem value="weekly">Weekly</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <div className="text-right">
                <Label>Auto Sync</Label>
              </div>
              <div className="col-span-3 flex items-center space-x-2">
                <Switch
                  checked={platformSettings.autoSync}
                  onCheckedChange={(checked) => setPlatformSettings({ ...platformSettings, autoSync: checked })}
                />
                <Label>Enable automatic synchronization</Label>
              </div>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <div className="text-right">
                <Label>Notifications</Label>
              </div>
              <div className="col-span-3 flex items-center space-x-2">
                <Switch
                  checked={platformSettings.notificationsEnabled}
                  onCheckedChange={(checked) =>
                    setPlatformSettings({ ...platformSettings, notificationsEnabled: checked })
                  }
                />
                <Label>Receive notifications about changes</Label>
              </div>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <div className="text-right">
                <Label>Data Sharing</Label>
              </div>
              <div className="col-span-3 flex items-center space-x-2">
                <Switch
                  checked={platformSettings.dataSharing}
                  onCheckedChange={(checked) => setPlatformSettings({ ...platformSettings, dataSharing: checked })}
                />
                <Label>Allow data sharing with other platforms</Label>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={saveSettings}>Save Changes</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Soundcloud Connection Dialog */}
      <Dialog open={isSoundcloudDialogOpen} onOpenChange={setIsSoundcloudDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Connect to Soundcloud</DialogTitle>
            <DialogDescription>Connect your Soundcloud account to track your performance metrics</DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <div className="rounded-md bg-amber-50 p-4 mb-4">
              <div className="flex">
                <div className="flex-shrink-0">
                  <svg className="h-5 w-5 text-amber-400" viewBox="0 0 20 20" fill="currentColor">
                    <path
                      fillRule="evenodd"
                      d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z"
                      clipRule="evenodd"
                    />
                  </svg>
                </div>
                <div className="ml-3">
                  <h3 className="text-sm font-medium text-amber-800">Security Notice</h3>
                  <div className="mt-2 text-sm text-amber-700">
                    <p>
                      You will be redirected to Soundcloud to authorize access to your account. ArtistPulse will only
                      access your public profile information and streaming data.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div className="text-center">
              {isSoundcloudAuthInProgress ? (
                <div className="flex justify-center items-center py-4">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
                  <span className="ml-2">Preparing authentication...</span>
                </div>
              ) : (
                <div className="space-y-4">
                  <p className="text-sm text-muted-foreground mb-4">
                    Click the button below to authorize ArtistPulse to access your Soundcloud account.
                  </p>
                  <div className="flex justify-center">
                    <Button onClick={completeSoundcloudAuth}>Authorize with Soundcloud</Button>
                  </div>
                  <p className="text-xs text-muted-foreground mt-4">
                    In a real implementation, this would open Soundcloud's authorization page in a new window. After
                    authorization, you would be redirected back to this application.
                  </p>
                </div>
              )}
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsSoundcloudDialogOpen(false)}>
              Cancel
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Bandcamp Connection Dialog */}
      <Dialog open={isBandcampDialogOpen} onOpenChange={setIsBandcampDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Connect to Bandcamp</DialogTitle>
            <DialogDescription>Connect your Bandcamp account to track your performance metrics</DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <div className="rounded-md bg-amber-50 p-4 mb-4">
              <div className="flex">
                <div className="flex-shrink-0">
                  <svg className="h-5 w-5 text-amber-400" viewBox="0 0 20 20" fill="currentColor">
                    <path
                      fillRule="evenodd"
                      d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z"
                      clipRule="evenodd"
                    />
                  </svg>
                </div>
                <div className="ml-3">
                  <h3 className="text-sm font-medium text-amber-800">Authorization Notice</h3>
                  <div className="mt-2 text-sm text-amber-700">
                    <p>
                      You will be redirected to Bandcamp to authorize access to your account. ArtistPulse will only
                      access your public profile information and streaming data.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div className="text-center">
              {bandcampAuthInProgress ? (
                <div className="flex justify-center items-center py-4">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
                  <span className="ml-2">Preparing authentication...</span>
                </div>
              ) : (
                <div className="space-y-4">
                  <p className="text-sm text-muted-foreground mb-4">
                    Click the button below to authorize ArtistPulse to access your Bandcamp account.
                  </p>
                  <div className="flex justify-center">
                    <Button onClick={completeBandcampAuth}>Authorize with Bandcamp</Button>
                  </div>
                  <p className="text-xs text-muted-foreground mt-4">
                    In a real implementation, this would open Bandcamp's authorization page in a new window. After
                    authorization, you would be redirected back to this application.
                  </p>
                </div>
              )}
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsBandcampDialogOpen(false)}>
              Cancel
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
