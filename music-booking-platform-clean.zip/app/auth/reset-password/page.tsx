"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { getSupabaseBrowserClient } from "@/lib/supabase"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Music } from "lucide-react"

export default function ResetPasswordPage() {
  const [password, setPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState(false)
  const [validationError, setValidationError] = useState<string | null>(null)
  const router = useRouter()
  const supabase = getSupabaseBrowserClient()

  useEffect(() => {
    // Check if we have a hash in the URL (from the password reset email)
    const checkSession = async () => {
      const { data, error } = await supabase.auth.getSession()

      // If no session and no hash, redirect to forgot password
      if (!data.session && !window.location.hash) {
        router.push("/auth/forgot-password")
      }
    }

    checkSession()
  }, [router, supabase])

  const validatePassword = () => {
    if (password.length < 8) {
      setValidationError("Password must be at least 8 characters long")
      return false
    }

    if (password !== confirmPassword) {
      setValidationError("Passwords do not match")
      return false
    }

    setValidationError(null)
    return true
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!validatePassword()) {
      return
    }

    setIsLoading(true)
    setError(null)

    try {
      const { error } = await supabase.auth.updateUser({
        password,
      })

      if (error) {
        setError(error.message)
      } else {
        setSuccess(true)
        // Redirect to login after 3 seconds
        setTimeout(() => {
          router.push("/auth/login")
        }, 3000)
      }
    } catch (err) {
      setError("An unexpected error occurred. Please try again.")
      console.error("Password update error:", err)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-gradient-to-b from-gray-900 to-black p-4 text-white">
      <div className="w-full max-w-md">
        <div className="mb-8 flex items-center justify-center">
          <div className="mr-2 rounded-full bg-yellow-500 p-2">
            <Music className="h-6 w-6 text-black" />
          </div>
          <h1 className="text-2xl font-bold">obsession</h1>
        </div>

        <Card className="border-gray-800 bg-gray-900 text-white">
          <CardHeader>
            <CardTitle className="text-xl">Create new password</CardTitle>
            <CardDescription className="text-gray-400">Enter a new password for your account</CardDescription>
          </CardHeader>
          <CardContent>
            {success ? (
              <Alert className="border-green-500 bg-green-500/20 text-green-200">
                <AlertDescription>
                  Your password has been successfully reset. Redirecting you to login...
                </AlertDescription>
              </Alert>
            ) : (
              <form onSubmit={handleSubmit}>
                <div className="mb-4">
                  <Label htmlFor="password" className="text-gray-300">
                    New Password
                  </Label>
                  <Input
                    id="password"
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    required
                    className="mt-1 border-gray-700 bg-gray-800 text-white placeholder:text-gray-500"
                  />
                </div>

                <div className="mb-4">
                  <Label htmlFor="confirmPassword" className="text-gray-300">
                    Confirm New Password
                  </Label>
                  <Input
                    id="confirmPassword"
                    type="password"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="••••••••"
                    required
                    className="mt-1 border-gray-700 bg-gray-800 text-white placeholder:text-gray-500"
                  />
                </div>

                {validationError && (
                  <Alert className="mb-4 border-orange-500 bg-orange-500/20 text-orange-200">
                    <AlertDescription>{validationError}</AlertDescription>
                  </Alert>
                )}

                {error && (
                  <Alert className="mb-4 border-red-500 bg-red-500/20 text-red-200">
                    <AlertDescription>{error}</AlertDescription>
                  </Alert>
                )}

                <Button
                  type="submit"
                  disabled={isLoading}
                  className="w-full bg-yellow-500 text-black hover:bg-yellow-600"
                >
                  {isLoading ? "Updating..." : "Reset Password"}
                </Button>
              </form>
            )}
          </CardContent>
          <CardFooter className="flex justify-center border-t border-gray-800 pt-4">
            <div className="text-sm text-gray-400">
              Remember your password?{" "}
              <Link href="/auth/login" className="text-yellow-500 hover:text-yellow-400">
                Sign in
              </Link>
            </div>
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}
