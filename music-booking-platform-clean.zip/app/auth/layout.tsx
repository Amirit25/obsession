import type { ReactNode } from "react"
import Link from "next/link"

export default function AuthLayout({ children }: { children: ReactNode }) {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-gradient-to-b from-gray-900 to-black p-4 md:p-8">
      <div className="w-full max-w-md">
        <div className="mb-8 text-center">
          <Link href="/" className="inline-block">
            <h1 className="text-3xl font-bold text-white">obsession</h1>
          </Link>
          <p className="mt-2 text-gray-400">Your Music Career Dashboard</p>
        </div>
        <div className="overflow-hidden rounded-lg bg-gray-800 shadow-xl">{children}</div>
      </div>
    </div>
  )
}
