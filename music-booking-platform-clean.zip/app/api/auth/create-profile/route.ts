import { NextResponse } from "next/server"
import { getSupabaseServerClient } from "@/lib/supabase"

export async function POST(request: Request) {
  try {
    const { userId, email, fullName, role } = await request.json()

    if (!userId || !email || !fullName || !role) {
      return NextResponse.json({ error: "Missing required fields: userId, email, fullName, role" }, { status: 400 })
    }

    const supabase = getSupabaseServerClient()

    // Check if profile already exists
    const { data: existingProfile, error: checkError } = await supabase
      .from("profiles")
      .select("id")
      .eq("user_id", userId)
      .single()

    if (checkError && checkError.code !== "PGRST116") {
      console.error("Error checking for existing profile:", checkError)
      return NextResponse.json({ error: "Error checking for existing profile" }, { status: 500 })
    }

    if (existingProfile) {
      // Profile already exists, return success
      return NextResponse.json({
        success: true,
        message: "Profile already exists",
        profileId: existingProfile.id,
      })
    }

    // Create profile
    const { data: profileData, error: profileError } = await supabase
      .from("profiles")
      .insert({
        user_id: userId,
        email,
        full_name: fullName,
        role,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      })
      .select("id")
      .single()

    if (profileError) {
      console.error("Error creating profile:", profileError)
      return NextResponse.json({ error: profileError.message || "Failed to create profile" }, { status: 500 })
    }

    // Create role-specific profile
    if (role === "artist") {
      const { error: artistError } = await supabase.from("artist_profiles").insert({
        profile_id: profileData.id,
        artist_name: fullName,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      })

      if (artistError) {
        console.error("Error creating artist profile:", artistError)
        return NextResponse.json({ error: "Failed to create artist profile" }, { status: 500 })
      }
    } else if (role === "promoter") {
      const { error: promoterError } = await supabase.from("promoter_profiles").insert({
        profile_id: profileData.id,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      })

      if (promoterError) {
        console.error("Error creating promoter profile:", promoterError)
        return NextResponse.json({ error: "Failed to create promoter profile" }, { status: 500 })
      }
    }

    return NextResponse.json({
      success: true,
      profileId: profileData.id,
    })
  } catch (error) {
    console.error("Unexpected error in create-profile:", error)
    return NextResponse.json({ error: "An unexpected error occurred" }, { status: 500 })
  }
}
