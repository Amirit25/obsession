import { headers } from "next/headers"
import { NextResponse } from "next/server"

export async function GET() {
  const headersList = headers()
  const userAgent = headersList.get("user-agent") || "Unknown user agent"
  const host = headersList.get("host") || "Unknown host"
  const acceptLanguage = headersList.get("accept-language") || "Unknown language"

  return NextResponse.json({
    userAgent,
    host,
    acceptLanguage,
    message: "Headers accessed in Route Handler",
  })
}
