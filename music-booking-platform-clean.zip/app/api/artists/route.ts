import { type NextRequest, NextResponse } from "next/server"
import { withErrorHandling } from "@/lib/api-utils"

export async function GET(req: NextRequest) {
  return withErrorHandling(req, async (supabase) => {
    const { searchParams } = new URL(req.url)
    const query = searchParams.get("query") || ""
    const genre = searchParams.get("genre") || ""
    const location = searchParams.get("location") || ""
    const limit = Number.parseInt(searchParams.get("limit") || "10")
    const page = Number.parseInt(searchParams.get("page") || "1")
    const offset = (page - 1) * limit

    let supabaseQuery = supabase.from("artist_profiles").select("*, profiles(username, avatar_url)")

    if (query) {
      supabaseQuery = supabaseQuery.or(
        `name.ilike.%${query}%, bio.ilike.%${query}%, profiles.username.ilike.%${query}%`,
      )
    }

    if (genre) {
      supabaseQuery = supabaseQuery.contains("genres", [genre])
    }

    if (location) {
      supabaseQuery = supabaseQuery.ilike("location", `%${location}%`)
    }

    const { data, error, count } = await supabaseQuery
      .order("created_at", { ascending: false })
      .range(offset, offset + limit - 1)
      .limit(limit)

    if (error) {
      throw error
    }

    // Get total count for pagination
    const { count: totalCount, error: countError } = await supabase
      .from("artist_profiles")
      .select("*", { count: "exact", head: true })

    if (countError) {
      throw countError
    }

    return NextResponse.json({
      artists: data,
      pagination: {
        total: totalCount,
        page,
        limit,
        pages: Math.ceil(totalCount! / limit),
      },
    })
  })
}
