import { NextResponse } from "next/server"

// Mock data for gig listings
const mockListings = [
  {
    id: "listing_1",
    title: "Weekend Festival Slot",
    fee: { min: 300, max: 500, currency: "EUR" },
    location: "Berlin, Germany",
    date: "2025-05-15",
    genre: "Electronic",
    audience: "500+",
    description:
      "Looking for an electronic act to fill a 45-minute slot at our weekend festival. Perfect for emerging artists looking to grow their audience.",
    applications: 12,
    promoterId: "user_456",
  },
  {
    id: "listing_2",
    title: "Jazz Club Performance",
    fee: { min: 200, max: 350, currency: "EUR" },
    location: "Paris, France",
    date: "2025-06-22",
    genre: "Jazz",
    audience: "100-200",
    description:
      "Seeking a jazz trio or quartet for our intimate club setting. Looking for a 2-hour set with a mix of standards and originals.",
    applications: 8,
    promoterId: "user_456",
  },
  {
    id: "listing_3",
    title: "Corporate Event",
    fee: { min: 500, max: 800, currency: "EUR" },
    location: "London, UK",
    date: "2025-07-10",
    genre: "Pop/Acoustic",
    audience: "150",
    description:
      "Need a solo artist or small band for a corporate product launch. Background music required for a 3-hour event with light, upbeat tunes.",
    applications: 7,
    promoterId: "user_456",
  },
]

export async function GET(request: Request) {
  // In a real app, you would fetch from a database and handle authentication
  return NextResponse.json({ listings: mockListings })
}

export async function POST(request: Request) {
  try {
    const body = await request.json()

    // In a real app, you would validate the request and save to a database
    const newListing = {
      id: `listing_${Date.now()}`,
      ...body,
      applications: 0,
      createdAt: new Date().toISOString(),
    }

    return NextResponse.json({ listing: newListing }, { status: 201 })
  } catch (error) {
    return NextResponse.json({ error: "Failed to create listing" }, { status: 500 })
  }
}
