import Link from "next/link"
import { ArrowLeft } from "lucide-react"
import { Button } from "@/components/ui/button"
import { getSupabaseServerClient } from "@/lib/supabase"
import { CreateGigForm } from "@/components/create-gig-form"
import { redirect } from "next/navigation"

async function getPromoterProfile(userId: string) {
  const supabase = getSupabaseServerClient()

  // Get profile
  const { data: profile } = await supabase.from("profiles").select("id, role").eq("user_id", userId).single()

  if (!profile || profile.role !== "promoter") return null

  // Get promoter profile
  const { data: promoterProfile } = await supabase
    .from("promoter_profiles")
    .select("id")
    .eq("profile_id", profile.id)
    .single()

  return promoterProfile
}

export default async function CreateGigPage() {
  const supabase = getSupabaseServerClient()
  const {
    data: { session },
  } = await supabase.auth.getSession()

  if (!session) {
    redirect("/auth/login")
  }

  const promoterProfile = await getPromoterProfile(session.user.id)

  if (!promoterProfile) {
    redirect("/promoter")
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <header className="border-b bg-white dark:bg-gray-950">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <Link href="/" className="flex items-center">
            <div className="bg-black dark:bg-white p-2 rounded-md">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path
                  d="M9 18V5L21 3V16"
                  stroke={`${true ? "#FFFFFF" : "#000000"}`}
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
                <path
                  d="M6 21C7.65685 21 9 19.6569 9 18C9 16.3431 7.65685 15 6 15C4.34315 15 3 16.3431 3 18C3 19.6569 4.34315 21 6 21Z"
                  stroke={`${true ? "#FFFFFF" : "#000000"}`}
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
                <path
                  d="M18 19C19.6569 19 21 17.6569 21 16C21 14.3431 19.6569 13 18 13C16.3431 13 15 14.3431 15 16C15 17.6569 16.3431 19 18 19Z"
                  stroke={`${true ? "#FFFFFF" : "#000000"}`}
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            </div>
            <span className="ml-2 text-xl font-bold">gigwave</span>
          </Link>
          <div className="flex items-center gap-4">
            <Button variant="outline" size="sm">
              Upgrade to Pro
            </Button>
            <form
              action={async () => {
                "use server"
                const supabase = getSupabaseServerClient()
                await supabase.auth.signOut()
              }}
            >
              <Button variant="ghost" size="sm" type="submit">
                Sign Out
              </Button>
            </form>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center mb-8">
          <Button variant="ghost" size="sm" className="mr-2" asChild>
            <Link href="/promoter">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Dashboard
            </Link>
          </Button>
          <h1 className="text-2xl font-bold">Create New Gig</h1>
        </div>

        <div className="max-w-3xl mx-auto">
          <CreateGigForm promoterId={promoterProfile.id} />
        </div>
      </div>
    </div>
  )
}
