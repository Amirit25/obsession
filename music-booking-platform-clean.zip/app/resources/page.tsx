"use client"

import { useState } from "react"
import { Play, Clock, BookOpen, Filter, Search, Tag, ChevronDown } from "lucide-react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

interface Resource {
  id: string
  title: string
  type: "video" | "article" | "podcast"
  category: "marketing" | "production" | "business" | "performance"
  thumbnail: string
  duration?: string
  author: string
  date: string
  description: string
  featured?: boolean
}

export default function ResourcesPage() {
  const [searchQuery, setSearchQuery] = useState("")

  const resources: Resource[] = [
    {
      id: "1",
      title: "How to Grow Your Audience on Spotify",
      type: "video",
      category: "marketing",
      thumbnail: "/placeholder.svg?height=180&width=320",
      duration: "18:24",
      author: "Music Marketing Pro",
      date: "May 15, 2025",
      description:
        "Learn proven strategies to increase your Spotify followers and get your music on popular playlists.",
      featured: true,
    },
    {
      id: "2",
      title: "Mastering Your Home Studio Setup",
      type: "video",
      category: "production",
      thumbnail: "/placeholder.svg?height=180&width=320",
      duration: "32:10",
      author: "Studio Essentials",
      date: "April 22, 2025",
      description: "A comprehensive guide to setting up a professional home studio on any budget.",
      featured: true,
    },
    {
      id: "3",
      title: "Understanding Music Royalties",
      type: "article",
      category: "business",
      thumbnail: "/placeholder.svg?height=180&width=320",
      author: "Music Business Weekly",
      date: "March 10, 2025",
      description: "A detailed breakdown of how music royalties work and how to maximize your earnings.",
    },
    {
      id: "4",
      title: "Social Media Strategy for Musicians",
      type: "video",
      category: "marketing",
      thumbnail: "/placeholder.svg?height=180&width=320",
      duration: "24:15",
      author: "Digital Artist Academy",
      date: "February 28, 2025",
      description: "Learn how to effectively use social media to promote your music and connect with fans.",
    },
    {
      id: "5",
      title: "Vocal Performance Techniques",
      type: "video",
      category: "performance",
      thumbnail: "/placeholder.svg?height=180&width=320",
      duration: "45:30",
      author: "Vocal Mastery",
      date: "January 15, 2025",
      description: "Advanced vocal techniques to improve your live and recorded performances.",
    },
    {
      id: "6",
      title: "Negotiating Your First Record Deal",
      type: "article",
      category: "business",
      thumbnail: "/placeholder.svg?height=180&width=320",
      author: "Industry Insider",
      date: "December 5, 2024",
      description: "What to look for and what to avoid when signing your first record deal.",
    },
  ]

  const filteredResources = resources.filter(
    (resource) =>
      resource.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      resource.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      resource.author.toLowerCase().includes(searchQuery.toLowerCase()) ||
      resource.category.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const featuredResources = resources.filter((resource) => resource.featured)

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Artist Academy</h1>
        <p className="text-muted-foreground">Educational resources to help you grow your music career</p>
      </div>

      <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
        <div className="relative w-full sm:w-96">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Search resources..."
            className="pl-8"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            aria-label="Search resources"
            id="resource-search"
            autoComplete="off"
            onKeyDown={(e) => {
              if (e.key === "Escape") {
                setSearchQuery("")
              }
            }}
          />
        </div>
        <div className="flex gap-2">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm">
                <Filter className="mr-2 h-4 w-4" />
                Filter
                <ChevronDown className="ml-2 h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem>All Resources</DropdownMenuItem>
              <DropdownMenuItem>Videos</DropdownMenuItem>
              <DropdownMenuItem>Articles</DropdownMenuItem>
              <DropdownMenuItem>Podcasts</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm">
                <Tag className="mr-2 h-4 w-4" />
                Category
                <ChevronDown className="ml-2 h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem>All Categories</DropdownMenuItem>
              <DropdownMenuItem>Marketing</DropdownMenuItem>
              <DropdownMenuItem>Production</DropdownMenuItem>
              <DropdownMenuItem>Business</DropdownMenuItem>
              <DropdownMenuItem>Performance</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      <Tabs defaultValue="all">
        <TabsList>
          <TabsTrigger value="all">All Resources</TabsTrigger>
          <TabsTrigger value="videos">Videos</TabsTrigger>
          <TabsTrigger value="articles">Articles</TabsTrigger>
          <TabsTrigger value="podcasts">Podcasts</TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="mt-6">
          {featuredResources.filter(
            (resource) =>
              resource.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
              resource.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
              resource.author.toLowerCase().includes(searchQuery.toLowerCase()) ||
              resource.category.toLowerCase().includes(searchQuery.toLowerCase()),
          ).length > 0 && (
            <div className="mb-8">
              <h2 className="text-xl font-semibold mb-4">Featured Resources</h2>
              <div className="grid gap-6 md:grid-cols-2">
                {featuredResources
                  .filter(
                    (resource) =>
                      resource.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                      resource.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
                      resource.author.toLowerCase().includes(searchQuery.toLowerCase()) ||
                      resource.category.toLowerCase().includes(searchQuery.toLowerCase()),
                  )
                  .map((resource) => (
                    <Card key={resource.id} className="overflow-hidden">
                      <div className="relative aspect-video">
                        <img
                          src={resource.thumbnail || "/placeholder.svg"}
                          alt={resource.title}
                          className="object-cover w-full h-full"
                        />
                        {resource.type === "video" && (
                          <div className="absolute inset-0 flex items-center justify-center">
                            <div className="h-12 w-12 rounded-full bg-black/70 flex items-center justify-center">
                              <Play className="h-6 w-6 text-white" />
                            </div>
                          </div>
                        )}
                        <Badge className="absolute top-2 right-2">
                          {resource.category.charAt(0).toUpperCase() + resource.category.slice(1)}
                        </Badge>
                      </div>
                      <CardHeader>
                        <CardTitle className="text-lg">{resource.title}</CardTitle>
                        <CardDescription>
                          {resource.author} • {resource.date}
                          {resource.duration && (
                            <span className="flex items-center ml-2 inline-flex">
                              <Clock className="h-3 w-3 mr-1" />
                              {resource.duration}
                            </span>
                          )}
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm text-muted-foreground">{resource.description}</p>
                      </CardContent>
                      <CardFooter>
                        <Button className="w-full">{resource.type === "video" ? "Watch Now" : "Read Now"}</Button>
                      </CardFooter>
                    </Card>
                  ))}
              </div>
            </div>
          )}

          {filteredResources.length === 0 && (
            <div className="flex items-center justify-center p-12">
              <div className="text-center">
                <h3 className="text-lg font-medium mb-2">No results found</h3>
                <p className="text-muted-foreground">
                  Try adjusting your search or filter to find what you're looking for.
                </p>
              </div>
            </div>
          )}
          {filteredResources.length > 0 && (
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {filteredResources.map((resource) => (
                <Card key={resource.id} className="overflow-hidden">
                  <div className="relative aspect-video">
                    <img
                      src={resource.thumbnail || "/placeholder.svg"}
                      alt={resource.title}
                      className="object-cover w-full h-full"
                    />
                    {resource.type === "video" && (
                      <div className="absolute inset-0 flex items-center justify-center">
                        <div className="h-12 w-12 rounded-full bg-black/70 flex items-center justify-center">
                          <Play className="h-6 w-6 text-white" />
                        </div>
                      </div>
                    )}
                    <Badge className="absolute top-2 right-2">
                      {resource.category.charAt(0).toUpperCase() + resource.category.slice(1)}
                    </Badge>
                  </div>
                  <CardHeader>
                    <CardTitle className="text-base">{resource.title}</CardTitle>
                    <CardDescription className="text-xs">
                      {resource.author} • {resource.date}
                      {resource.duration && (
                        <span className="flex items-center ml-2 inline-flex">
                          <Clock className="h-3 w-3 mr-1" />
                          {resource.duration}
                        </span>
                      )}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-xs text-muted-foreground line-clamp-2">{resource.description}</p>
                  </CardContent>
                  <CardFooter>
                    <Button variant="outline" size="sm" className="w-full">
                      {resource.type === "video" ? (
                        <>
                          <Play className="mr-2 h-4 w-4" />
                          Watch
                        </>
                      ) : (
                        <>
                          <BookOpen className="mr-2 h-4 w-4" />
                          Read
                        </>
                      )}
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="videos" className="mt-6">
          {filteredResources.length === 0 ? (
            <div className="flex items-center justify-center p-12">
              <div className="text-center">
                <h3 className="text-lg font-medium mb-2">No results found</h3>
                <p className="text-muted-foreground">
                  Try adjusting your search or filter to find what you're looking for.
                </p>
              </div>
            </div>
          ) : (
            filteredResources
              .filter((resource) => resource.type === "video")
              .map((resource) => (
                <Card key={resource.id} className="overflow-hidden">
                  <div className="relative aspect-video">
                    <img
                      src={resource.thumbnail || "/placeholder.svg"}
                      alt={resource.title}
                      className="object-cover w-full h-full"
                    />
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="h-12 w-12 rounded-full bg-black/70 flex items-center justify-center">
                        <Play className="h-6 w-6 text-white" />
                      </div>
                    </div>
                    <Badge className="absolute top-2 right-2">
                      {resource.category.charAt(0).toUpperCase() + resource.category.slice(1)}
                    </Badge>
                  </div>
                  <CardHeader>
                    <CardTitle className="text-base">{resource.title}</CardTitle>
                    <CardDescription className="text-xs">
                      {resource.author} • {resource.date}
                      {resource.duration && (
                        <span className="flex items-center ml-2 inline-flex">
                          <Clock className="h-3 w-3 mr-1" />
                          {resource.duration}
                        </span>
                      )}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-xs text-muted-foreground line-clamp-2">{resource.description}</p>
                  </CardContent>
                  <CardFooter>
                    <Button variant="outline" size="sm" className="w-full">
                      <Play className="mr-2 h-4 w-4" />
                      Watch
                    </Button>
                  </CardFooter>
                </Card>
              ))
          )}
        </TabsContent>

        <TabsContent value="articles" className="mt-6">
          {filteredResources.length === 0 ? (
            <div className="flex items-center justify-center p-12">
              <div className="text-center">
                <h3 className="text-lg font-medium mb-2">No results found</h3>
                <p className="text-muted-foreground">
                  Try adjusting your search or filter to find what you're looking for.
                </p>
              </div>
            </div>
          ) : (
            filteredResources
              .filter((resource) => resource.type === "article")
              .map((resource) => (
                <Card key={resource.id} className="overflow-hidden">
                  <div className="relative aspect-video">
                    <img
                      src={resource.thumbnail || "/placeholder.svg"}
                      alt={resource.title}
                      className="object-cover w-full h-full"
                    />
                    <Badge className="absolute top-2 right-2">
                      {resource.category.charAt(0).toUpperCase() + resource.category.slice(1)}
                    </Badge>
                  </div>
                  <CardHeader>
                    <CardTitle className="text-base">{resource.title}</CardTitle>
                    <CardDescription className="text-xs">
                      {resource.author} • {resource.date}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-xs text-muted-foreground line-clamp-2">{resource.description}</p>
                  </CardContent>
                  <CardFooter>
                    <Button variant="outline" size="sm" className="w-full">
                      <BookOpen className="mr-2 h-4 w-4" />
                      Read
                    </Button>
                  </CardFooter>
                </Card>
              ))
          )}
        </TabsContent>

        <TabsContent value="podcasts" className="mt-6">
          <div className="flex items-center justify-center p-12">
            <div className="text-center">
              <h3 className="text-lg font-medium mb-2">Coming Soon</h3>
              <p className="text-muted-foreground">We're working on adding podcast content to our resources.</p>
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
