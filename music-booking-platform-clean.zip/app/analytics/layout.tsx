import type React from "react"
import { ProtectedRoute } from "@/components/auth/protected-route"
import { AnalyticsNav } from "./components/analytics-nav"
import { Suspense } from "react"

export default function AnalyticsLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <ProtectedRoute>
      <div className="container mx-auto px-4 py-6">
        <AnalyticsNav />
        <Suspense>{children}</Suspense>
      </div>
    </ProtectedRoute>
  )
}
