"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export function TourPlanner() {
  const [region, setRegion] = useState("north-america")
  const [isGenerating, setIsGenerating] = useState(false)
  const [planGenerated, setPlanGenerated] = useState(false)

  const generateTourPlan = () => {
    setIsGenerating(true)
    // Simulate API call with timeout
    setTimeout(() => {
      setIsGenerating(false)
      setPlanGenerated(true)
    }, 1500)
  }

  const resetPlan = () => {
    setPlanGenerated(false)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Tour Planning Assistant</CardTitle>
        <CardDescription>Plan your tour based on your audience data</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="suggested" className="space-y-4">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="suggested">Suggested Tour</TabsTrigger>
            <TabsTrigger value="custom">Custom Planning</TabsTrigger>
          </TabsList>

          <TabsContent value="suggested" className="space-y-4">
            <div className="flex flex-col sm:flex-row gap-4 mb-4">
              <Select value={region} onValueChange={setRegion}>
                <SelectTrigger>
                  <SelectValue placeholder="Select Region" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="north-america">North America</SelectItem>
                  <SelectItem value="europe">Europe</SelectItem>
                  <SelectItem value="asia">Asia</SelectItem>
                  <SelectItem value="latin-america">Latin America</SelectItem>
                  <SelectItem value="oceania">Australia & New Zealand</SelectItem>
                </SelectContent>
              </Select>

              <Button className="shrink-0" onClick={generateTourPlan} disabled={isGenerating}>
                {isGenerating ? "Generating..." : "Generate Tour Plan"}
              </Button>
              {planGenerated && (
                <Button variant="outline" className="shrink-0 ml-2" onClick={resetPlan}>
                  Reset
                </Button>
              )}
            </div>

            <div className="space-y-4">
              <div className="text-sm font-medium">Suggested Cities Based on Your Audience</div>

              {region === "north-america" && planGenerated && (
                <div className="space-y-3">
                  {[
                    { city: "New York, NY", listeners: "12,000", venue: "Brooklyn Steel (1,800 capacity)" },
                    { city: "Los Angeles, CA", listeners: "8,500", venue: "The Fonda Theatre (1,200 capacity)" },
                    { city: "Chicago, IL", listeners: "4,200", venue: "Thalia Hall (800 capacity)" },
                    { city: "Toronto, ON", listeners: "6,500", venue: "The Danforth Music Hall (1,500 capacity)" },
                    { city: "Austin, TX", listeners: "3,800", venue: "Emo's (1,700 capacity)" },
                  ].map((item) => (
                    <div key={item.city} className="flex items-center justify-between border-b pb-2">
                      <div>
                        <div className="font-medium">{item.city}</div>
                        <div className="text-sm text-muted-foreground">Suggested venue: {item.venue}</div>
                      </div>
                      <div className="text-sm">{item.listeners} listeners</div>
                    </div>
                  ))}
                </div>
              )}

              {region === "europe" && planGenerated && (
                <div className="space-y-3">
                  {[
                    { city: "London, UK", listeners: "10,000", venue: "O2 Academy Brixton (4,900 capacity)" },
                    { city: "Berlin, DE", listeners: "7,800", venue: "Astra Kulturhaus (1,500 capacity)" },
                    { city: "Paris, FR", listeners: "4,800", venue: "La Cigale (1,000 capacity)" },
                    { city: "Amsterdam, NL", listeners: "3,200", venue: "Paradiso (1,500 capacity)" },
                    { city: "Barcelona, ES", listeners: "2,900", venue: "Razzmatazz (1,700 capacity)" },
                  ].map((item) => (
                    <div key={item.city} className="flex items-center justify-between border-b pb-2">
                      <div>
                        <div className="font-medium">{item.city}</div>
                        <div className="text-sm text-muted-foreground">Suggested venue: {item.venue}</div>
                      </div>
                      <div className="text-sm">{item.listeners} listeners</div>
                    </div>
                  ))}
                </div>
              )}

              {(!planGenerated || (region !== "north-america" && region !== "europe")) && (
                <div className="p-8 text-center">
                  <p className="text-muted-foreground">
                    {planGenerated
                      ? "Select North America or Europe and generate again to see suggested cities"
                      : 'Select a region and click "Generate Tour Plan" to see suggested cities based on your audience data'}
                  </p>
                </div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="custom" className="space-y-4">
            <div className="grid gap-4">
              <div className="grid gap-2">
                <Label htmlFor="tour-name">Tour Name</Label>
                <Input id="tour-name" placeholder="Enter tour name" />
              </div>

              <div className="grid gap-2">
                <Label htmlFor="start-date">Start Date</Label>
                <Input id="start-date" type="date" />
              </div>

              <div className="grid gap-2">
                <Label htmlFor="end-date">End Date</Label>
                <Input id="end-date" type="date" />
              </div>

              <div className="grid gap-2">
                <Label htmlFor="regions">Regions</Label>
                <Select>
                  <SelectTrigger id="regions">
                    <SelectValue placeholder="Select regions" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="north-america">North America</SelectItem>
                    <SelectItem value="europe">Europe</SelectItem>
                    <SelectItem value="asia">Asia</SelectItem>
                    <SelectItem value="latin-america">Latin America</SelectItem>
                    <SelectItem value="oceania">Australia & New Zealand</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="grid gap-2">
                <Label htmlFor="venue-size">Venue Size</Label>
                <Select>
                  <SelectTrigger id="venue-size">
                    <SelectValue placeholder="Select venue size" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="small">Small (up to 500 capacity)</SelectItem>
                    <SelectItem value="medium">Medium (500-1,500 capacity)</SelectItem>
                    <SelectItem value="large">Large (1,500-5,000 capacity)</SelectItem>
                    <SelectItem value="xl">Extra Large (5,000+ capacity)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
      <CardFooter className="flex justify-between">
        <Button variant="outline">Export Plan</Button>
        <Button>Save Plan</Button>
      </CardFooter>
    </Card>
  )
}
