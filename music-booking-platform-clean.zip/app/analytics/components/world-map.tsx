"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export function WorldMap() {
  const [metric, setMetric] = useState("listeners")

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <div>
          <CardTitle>Global Audience Map</CardTitle>
          <CardDescription>Geographic distribution of your audience</CardDescription>
        </div>
        <Select value={metric} onValueChange={setMetric}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Select metric" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="listeners">Listeners</SelectItem>
            <SelectItem value="streams">Streams</SelectItem>
            <SelectItem value="growth">Growth</SelectItem>
            <SelectItem value="engagement">Engagement</SelectItem>
          </SelectContent>
        </Select>
      </CardHeader>
      <CardContent>
        <div className="h-[400px] flex items-center justify-center bg-muted/20 rounded-md">
          <div className="text-center">
            <p className="text-muted-foreground">Interactive world map visualization coming soon</p>
            <p className="text-sm text-muted-foreground mt-2">
              This feature will display your audience distribution on an interactive world map
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
