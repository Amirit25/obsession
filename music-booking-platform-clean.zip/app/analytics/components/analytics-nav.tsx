"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { BarChart3, Users, Globe, TrendingUp, Settings } from "lucide-react"

const items = [
  {
    title: "Overview",
    href: "/analytics/dashboard",
    icon: BarChart3,
  },
  {
    title: "Audience",
    href: "/analytics/audience",
    icon: Users,
  },
  {
    title: "Geography",
    href: "/analytics/geography",
    icon: Globe,
  },
  {
    title: "Performance",
    href: "/analytics/performance",
    icon: TrendingUp,
  },
  {
    title: "Settings",
    href: "/analytics/settings",
    icon: Settings,
  },
]

export function AnalyticsNav() {
  const pathname = usePathname()

  return (
    <nav className="mb-6 flex items-center space-x-4 overflow-auto pb-2">
      {items.map((item) => (
        <Link
          key={item.href}
          href={item.href}
          className={cn(
            "flex min-w-max items-center gap-2 rounded-md px-3 py-2 text-sm font-medium transition-colors",
            pathname === item.href ? "bg-primary text-primary-foreground" : "hover:bg-muted",
          )}
        >
          <item.icon className="h-4 w-4" />
          {item.title}
        </Link>
      ))}
    </nav>
  )
}
