"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Music, Share2, Video, MapPin, ArrowLeft, CheckCircle2, XCircle } from "lucide-react"
import Link from "next/link"
import { Badge } from "@/components/ui/badge"

// Platform categories with their respective platforms
const platformCategories = [
  {
    id: "music",
    name: "Music Streaming",
    icon: Music,
    platforms: [
      { id: "spotify", name: "Spotify", popular: true, connected: true },
      { id: "apple-music", name: "Apple Music", popular: true, connected: true },
      { id: "youtube-music", name: "YouTube Music", popular: true, connected: true },
      { id: "soundcloud", name: "SoundCloud", popular: true, connected: false },
      { id: "bandcamp", name: "Bandcamp", popular: false, connected: true },
      { id: "deezer", name: "Deezer", popular: false, connected: false },
      { id: "tidal", name: "Tidal", popular: false, connected: false },
      { id: "amazon-music", name: "Amazon Music", popular: false, connected: false },
      { id: "pandora", name: "Pandora", popular: false, connected: false },
      { id: "iheartradio", name: "iHeartRadio", popular: false, connected: false },
      { id: "napster", name: "Napster", popular: false, connected: false },
      { id: "audiomack", name: "Audiomack", popular: false, connected: false },
    ],
  },
  {
    id: "social",
    name: "Social Networks",
    icon: Share2,
    platforms: [
      { id: "instagram", name: "Instagram", popular: true, connected: true },
      { id: "tiktok", name: "TikTok", popular: true, connected: true },
      { id: "facebook", name: "Facebook", popular: true, connected: true },
      { id: "twitter", name: "Twitter/X", popular: true, connected: false },
      { id: "snapchat", name: "Snapchat", popular: false, connected: false },
      { id: "linkedin", name: "LinkedIn", popular: false, connected: false },
      { id: "pinterest", name: "Pinterest", popular: false, connected: false },
      { id: "triller", name: "Triller", popular: false, connected: false },
    ],
  },
  {
    id: "video",
    name: "Video Platforms",
    icon: Video,
    platforms: [
      { id: "youtube", name: "YouTube", popular: true, connected: true },
      { id: "vimeo", name: "Vimeo", popular: false, connected: false },
      { id: "dailymotion", name: "Dailymotion", popular: false, connected: false },
      { id: "twitch", name: "Twitch", popular: false, connected: false },
    ],
  },
  {
    id: "regional",
    name: "Regional Platforms",
    icon: MapPin,
    platforms: [
      { id: "boomplay", name: "Boomplay (Africa)", popular: false, connected: false },
      { id: "anghami", name: "Anghami (Middle East)", popular: false, connected: false },
      { id: "jiosaavn", name: "JioSaavn (India)", popular: false, connected: false },
      { id: "gaana", name: "Gaana (India)", popular: false, connected: false },
      { id: "yandex-music", name: "Yandex Music (Russia)", popular: false, connected: false },
      { id: "melon", name: "Melon (South Korea)", popular: false, connected: false },
      { id: "line-music", name: "Line Music (Japan)", popular: false, connected: false },
      { id: "kkbox", name: "KKBox (Asia)", popular: false, connected: false },
    ],
  },
]

export default function ConnectPlatformsPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("all")

  // Filter platforms based on search term and selected category
  const filteredPlatforms = platformCategories
    .filter((category) => selectedCategory === "all" || category.id === selectedCategory)
    .flatMap((category) =>
      category.platforms
        .filter((platform) => platform.name.toLowerCase().includes(searchTerm.toLowerCase()))
        .map((platform) => ({ ...platform, category: category.name, categoryIcon: category.icon })),
    )

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="sm" asChild>
            <Link href="/analytics/dashboard">
              <ArrowLeft className="h-4 w-4" />
              <span className="ml-2">Back to Dashboard</span>
            </Link>
          </Button>
        </div>
      </div>

      <div>
        <h1 className="text-3xl font-bold tracking-tight">Connect Platforms</h1>
        <p className="text-muted-foreground">Connect your accounts from various platforms to track your performance</p>
      </div>

      <div className="flex flex-col gap-4 sm:flex-row">
        <Input
          placeholder="Search platforms..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="sm:max-w-xs"
        />

        <Tabs defaultValue="all" value={selectedCategory} onValueChange={setSelectedCategory} className="w-full">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="all">All</TabsTrigger>
            <TabsTrigger value="music">Music</TabsTrigger>
            <TabsTrigger value="social">Social</TabsTrigger>
            <TabsTrigger value="video">Video</TabsTrigger>
            <TabsTrigger value="regional">Regional</TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
        {filteredPlatforms.map((platform) => {
          const Icon = platform.categoryIcon
          return (
            <Card key={platform.id} className="overflow-hidden">
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Icon className="h-4 w-4 text-muted-foreground" />
                    <CardTitle className="text-base">{platform.name}</CardTitle>
                  </div>
                  {platform.popular && (
                    <Badge variant="secondary" className="text-xs">
                      Popular
                    </Badge>
                  )}
                </div>
                <CardDescription className="text-xs">{platform.category}</CardDescription>
              </CardHeader>
              <CardContent className="pb-2">
                <div className="flex items-center">
                  {platform.connected ? (
                    <div className="flex items-center text-sm text-green-500">
                      <CheckCircle2 className="mr-1 h-4 w-4" />
                      Connected
                    </div>
                  ) : (
                    <div className="flex items-center text-sm text-muted-foreground">
                      <XCircle className="mr-1 h-4 w-4" />
                      Not connected
                    </div>
                  )}
                </div>
              </CardContent>
              <CardFooter>
                <Button variant={platform.connected ? "outline" : "default"} className="w-full">
                  {platform.connected ? "Manage Connection" : "Connect"}
                </Button>
              </CardFooter>
            </Card>
          )
        })}
      </div>
    </div>
  )
}
