"use client"

export default function PerformancePage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Performance Analytics</h1>
        <p className="text-muted-foreground">Track your music performance across platforms</p>
      </div>

      <div className="rounded-lg border p-8 text-center">
        <h2 className="text-xl font-semibold">Coming Soon</h2>
        <p className="mt-2 text-muted-foreground">
          Detailed performance analytics will be available soon. Check back later for updates.
        </p>
      </div>
    </div>
  )
}
