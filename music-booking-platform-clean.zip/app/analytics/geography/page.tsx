"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts"
import { WorldMap } from "../components/world-map"
import { TourPlanner } from "../components/tour-planner"

// Sample data for top countries
const topCountriesData = [
  { country: "United States", listeners: 45000 },
  { country: "United Kingdom", listeners: 32000 },
  { country: "Germany", listeners: 28000 },
  { country: "Canada", listeners: 24000 },
  { country: "Australia", listeners: 18000 },
  { country: "France", listeners: 15000 },
  { country: "Brazil", listeners: 12000 },
  { country: "Japan", listeners: 10000 },
  { country: "Mexico", listeners: 8000 },
  { country: "Spain", listeners: 7000 },
]

// Sample data for top cities
const topCitiesData = [
  { city: "New York", country: "US", listeners: 12000 },
  { city: "London", country: "UK", listeners: 10000 },
  { city: "Los Angeles", country: "US", listeners: 8500 },
  { city: "Berlin", country: "DE", listeners: 7800 },
  { city: "Toronto", country: "CA", listeners: 6500 },
  { city: "Sydney", country: "AU", listeners: 5200 },
  { city: "Paris", country: "FR", listeners: 4800 },
  { city: "Chicago", country: "US", listeners: 4200 },
  { city: "São Paulo", country: "BR", listeners: 3900 },
  { city: "Tokyo", country: "JP", listeners: 3600 },
]

// Sample data for regional distribution
const regionalDistributionData = [
  { name: "North America", value: 42 },
  { name: "Europe", value: 35 },
  { name: "Asia Pacific", value: 12 },
  { name: "Latin America", value: 8 },
  { name: "Africa", value: 3 },
]

// Sample data for language distribution
const languageDistributionData = [
  { language: "English", percentage: 65 },
  { language: "Spanish", percentage: 12 },
  { language: "German", percentage: 8 },
  { language: "French", percentage: 6 },
  { language: "Portuguese", percentage: 4 },
  { language: "Japanese", percentage: 3 },
  { language: "Other", percentage: 2 },
]

// Sample data for growth by region
const growthByRegionData = [
  { region: "North America", previousYear: 38, currentYear: 42 },
  { region: "Europe", previousYear: 32, currentYear: 35 },
  { region: "Asia Pacific", previousYear: 10, currentYear: 12 },
  { region: "Latin America", previousYear: 6, currentYear: 8 },
  { region: "Africa", previousYear: 2, currentYear: 3 },
]

// Colors for pie chart
const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042", "#8884D8"]

export default function GeographyPage() {
  const [timeRange, setTimeRange] = useState("30days")
  const [platform, setPlatform] = useState("all")

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Geography Analytics</h1>
          <p className="text-muted-foreground">Detailed geographic analysis of your audience</p>
        </div>
        <div className="flex flex-col sm:flex-row gap-2">
          <Select value={platform} onValueChange={setPlatform}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Select Platform" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Platforms</SelectItem>
              <SelectItem value="spotify">Spotify</SelectItem>
              <SelectItem value="apple">Apple Music</SelectItem>
              <SelectItem value="youtube">YouTube</SelectItem>
              <SelectItem value="tiktok">TikTok</SelectItem>
            </SelectContent>
          </Select>
          <Select value={timeRange} onValueChange={setTimeRange}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Select Time Range" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7days">Last 7 Days</SelectItem>
              <SelectItem value="30days">Last 30 Days</SelectItem>
              <SelectItem value="90days">Last 90 Days</SelectItem>
              <SelectItem value="year">Last Year</SelectItem>
              <SelectItem value="alltime">All Time</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <WorldMap />

      <div className="grid gap-6 md:grid-cols-2">
        <TourPlanner />

        <Card>
          <CardHeader>
            <CardTitle>Geographic Insights</CardTitle>
            <CardDescription>Key insights from your audience data</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="space-y-2">
                <div className="font-medium">Top Growth Markets</div>
                <p className="text-sm text-muted-foreground">
                  Your audience in Latin America has grown by 45% in the last 90 days, with Brazil and Mexico showing
                  the strongest growth.
                </p>
              </div>

              <div className="space-y-2">
                <div className="font-medium">Engagement Hotspots</div>
                <p className="text-sm text-muted-foreground">
                  Listeners in Japan and Germany show the highest engagement rates, with average session times 30%
                  higher than your global average.
                </p>
              </div>

              <div className="space-y-2">
                <div className="font-medium">Untapped Potential</div>
                <p className="text-sm text-muted-foreground">
                  Your music is gaining traction in Southeast Asia, particularly in Indonesia and the Philippines,
                  suggesting potential for targeted promotion.
                </p>
              </div>

              <div className="space-y-2">
                <div className="font-medium">Tour Recommendations</div>
                <p className="text-sm text-muted-foreground">
                  Based on your audience distribution, a tour covering major cities in North America and Europe would
                  reach 65% of your active listeners.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="countries">Countries</TabsTrigger>
          <TabsTrigger value="cities">Cities</TabsTrigger>
          <TabsTrigger value="growth">Growth</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            <Card>
              <CardHeader>
                <CardTitle>Regional Distribution</CardTitle>
                <CardDescription>Audience distribution by region</CardDescription>
              </CardHeader>
              <CardContent className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={regionalDistributionData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {regionalDistributionData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value) => `${value}%`} />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Language Distribution</CardTitle>
                <CardDescription>Primary languages of your audience</CardDescription>
              </CardHeader>
              <CardContent className="h-[300px]">
                <ChartContainer
                  className="h-full"
                  config={{
                    percentage: {
                      label: "Percentage",
                      color: "hsl(var(--chart-1))",
                    },
                  }}
                >
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={languageDistributionData}
                      layout="vertical"
                      margin={{ top: 20, right: 30, left: 70, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
                      <XAxis type="number" domain={[0, 100]} tickFormatter={(value) => `${value}%`} />
                      <YAxis type="category" dataKey="language" width={60} tickMargin={10} />
                      <ChartTooltip
                        content={<ChartTooltipContent />}
                        formatter={(value) => [`${value}%`, "Percentage"]}
                      />
                      <Bar dataKey="percentage" fill="var(--color-percentage)" radius={[0, 4, 4, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </ChartContainer>
              </CardContent>
            </Card>

            <Card className="md:col-span-2 lg:col-span-1">
              <CardHeader>
                <CardTitle>Growth by Region</CardTitle>
                <CardDescription>Year-over-year growth by region</CardDescription>
              </CardHeader>
              <CardContent className="h-[300px]">
                <ChartContainer
                  className="h-full"
                  config={{
                    previousYear: {
                      label: "Previous Year",
                      color: "hsl(var(--chart-2))",
                    },
                    currentYear: {
                      label: "Current Year",
                      color: "hsl(var(--chart-1))",
                    },
                  }}
                >
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={growthByRegionData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                      <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
                      <XAxis dataKey="region" />
                      <YAxis tickFormatter={(value) => `${value}%`} />
                      <ChartTooltip content={<ChartTooltipContent />} />
                      <Legend />
                      <Bar dataKey="previousYear" fill="var(--color-previousYear)" radius={[4, 4, 0, 0]} />
                      <Bar dataKey="currentYear" fill="var(--color-currentYear)" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </ChartContainer>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="countries" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Top Countries</CardTitle>
              <CardDescription>Countries with the most listeners</CardDescription>
            </CardHeader>
            <CardContent className="h-[400px]">
              <ChartContainer
                className="h-full"
                config={{
                  listeners: {
                    label: "Listeners",
                    color: "hsl(var(--chart-1))",
                  },
                }}
              >
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={topCountriesData} margin={{ top: 20, right: 30, left: 20, bottom: 60 }}>
                    <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
                    <XAxis dataKey="country" angle={-45} textAnchor="end" height={70} tickMargin={10} />
                    <YAxis />
                    <ChartTooltip content={<ChartTooltipContent />} />
                    <Bar dataKey="listeners" fill="var(--color-listeners)" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </ChartContainer>
            </CardContent>
          </Card>

          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Country Growth</CardTitle>
                <CardDescription>Fastest growing countries</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[
                    { country: "Brazil", growth: "+45%", listeners: "12,000" },
                    { country: "Mexico", growth: "+38%", listeners: "8,000" },
                    { country: "India", growth: "+32%", listeners: "6,500" },
                    { country: "Indonesia", growth: "+28%", listeners: "4,200" },
                    { country: "Nigeria", growth: "+25%", listeners: "3,800" },
                  ].map((item) => (
                    <div key={item.country} className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="font-medium">{item.country}</div>
                      </div>
                      <div className="flex items-center gap-4">
                        <div className="text-green-500 font-medium">{item.growth}</div>
                        <div className="text-muted-foreground text-sm">{item.listeners}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Engagement by Country</CardTitle>
                <CardDescription>Average engagement rate by country</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[
                    { country: "Japan", rate: "8.2%", change: "+1.2%" },
                    { country: "Germany", rate: "7.8%", change: "+0.8%" },
                    { country: "United Kingdom", rate: "7.5%", change: "+0.5%" },
                    { country: "United States", rate: "6.9%", change: "+0.3%" },
                    { country: "Canada", rate: "6.7%", change: "+0.2%" },
                  ].map((item) => (
                    <div key={item.country} className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="font-medium">{item.country}</div>
                      </div>
                      <div className="flex items-center gap-4">
                        <div className="font-medium">{item.rate}</div>
                        <div className="text-green-500 text-sm">{item.change}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="cities" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Top Cities</CardTitle>
              <CardDescription>Cities with the most listeners</CardDescription>
            </CardHeader>
            <CardContent className="h-[400px]">
              <ChartContainer
                className="h-full"
                config={{
                  listeners: {
                    label: "Listeners",
                    color: "hsl(var(--chart-1))",
                  },
                }}
              >
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={topCitiesData} margin={{ top: 20, right: 30, left: 20, bottom: 60 }}>
                    <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
                    <XAxis dataKey="city" angle={-45} textAnchor="end" height={70} tickMargin={10} />
                    <YAxis />
                    <ChartTooltip
                      content={<ChartTooltipContent />}
                      formatter={(value, name, props) => {
                        return [
                          `${value.toLocaleString()} listeners`,
                          props.payload.city + ", " + props.payload.country,
                        ]
                      }}
                    />
                    <Bar dataKey="listeners" fill="var(--color-listeners)" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </ChartContainer>
            </CardContent>
          </Card>

          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>City Growth</CardTitle>
                <CardDescription>Fastest growing cities</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[
                    { city: "Mexico City, MX", growth: "+52%", listeners: "7,800" },
                    { city: "Mumbai, IN", growth: "+48%", listeners: "5,200" },
                    { city: "São Paulo, BR", growth: "+43%", listeners: "3,900" },
                    { city: "Jakarta, ID", growth: "+39%", listeners: "3,100" },
                    { city: "Lagos, NG", growth: "+35%", listeners: "2,800" },
                  ].map((item) => (
                    <div key={item.city} className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="font-medium">{item.city}</div>
                      </div>
                      <div className="flex items-center gap-4">
                        <div className="text-green-500 font-medium">{item.growth}</div>
                        <div className="text-muted-foreground text-sm">{item.listeners}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Engagement by City</CardTitle>
                <CardDescription>Average engagement rate by city</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[
                    { city: "Berlin, DE", rate: "9.1%", change: "+1.5%" },
                    { city: "Tokyo, JP", rate: "8.7%", change: "+1.3%" },
                    { city: "London, UK", rate: "8.2%", change: "+0.9%" },
                    { city: "New York, US", rate: "7.8%", change: "+0.7%" },
                    { city: "Paris, FR", rate: "7.5%", change: "+0.6%" },
                  ].map((item) => (
                    <div key={item.city} className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="font-medium">{item.city}</div>
                      </div>
                      <div className="flex items-center gap-4">
                        <div className="font-medium">{item.rate}</div>
                        <div className="text-green-500 text-sm">{item.change}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="growth" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Emerging Markets</CardTitle>
                <CardDescription>Regions with fastest audience growth</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[
                    { region: "Latin America", growth: "+45%", potential: "High" },
                    { region: "South Asia", growth: "+38%", potential: "Very High" },
                    { region: "Africa", growth: "+32%", potential: "Very High" },
                    { region: "Southeast Asia", growth: "+28%", potential: "High" },
                    { region: "Eastern Europe", growth: "+22%", potential: "Medium" },
                  ].map((item) => (
                    <div key={item.region} className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="font-medium">{item.region}</div>
                      </div>
                      <div className="flex items-center gap-4">
                        <div className="text-green-500 font-medium">{item.growth}</div>
                        <div className="text-muted-foreground text-sm">{item.potential}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Seasonal Trends</CardTitle>
                <CardDescription>Geographic seasonal listening patterns</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[
                    { season: "Summer (Northern)", regions: "North America, Europe", change: "+22%" },
                    { season: "Winter (Southern)", regions: "Australia, South America", change: "+18%" },
                    { season: "Holiday Season", regions: "Global", change: "+35%" },
                    { season: "Festival Season", regions: "India, Southeast Asia", change: "+28%" },
                    { season: "Spring Break", regions: "North America", change: "+15%" },
                  ].map((item) => (
                    <div key={item.season} className="flex items-center justify-between">
                      <div>
                        <div className="font-medium">{item.season}</div>
                        <div className="text-muted-foreground text-sm">{item.regions}</div>
                      </div>
                      <div className="text-green-500 font-medium">{item.change}</div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Geographic Expansion Opportunities</CardTitle>
              <CardDescription>Regions with high growth potential based on current trends</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {[
                  {
                    region: "Southeast Asia",
                    countries: "Indonesia, Philippines, Vietnam, Thailand",
                    opportunity: "High streaming growth with young population and increasing internet penetration",
                    recommendation: "Localize content and collaborate with regional artists",
                  },
                  {
                    region: "Africa",
                    countries: "Nigeria, Kenya, South Africa, Ghana",
                    opportunity: "Rapidly growing music market with unique regional genres gaining global popularity",
                    recommendation: "Partner with local distributors and explore Afrobeats collaborations",
                  },
                  {
                    region: "Latin America",
                    countries: "Mexico, Colombia, Argentina, Chile",
                    opportunity: "Strong engagement rates and growing premium subscription base",
                    recommendation: "Spanish language versions and regional genre exploration",
                  },
                ].map((item) => (
                  <div key={item.region} className="space-y-2 pb-4 border-b last:border-0">
                    <div className="font-semibold text-lg">{item.region}</div>
                    <div className="text-sm font-medium">Key Countries: {item.countries}</div>
                    <div className="text-sm text-muted-foreground">{item.opportunity}</div>
                    <div className="text-sm font-medium mt-2">Recommendation: {item.recommendation}</div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
