"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  Music,
  Share2,
  Video,
  Plus,
  ArrowUpRight,
  TrendingUp,
  TrendingDown,
  Users,
  Clock,
  MapPin,
  Radio,
} from "lucide-react"
import Link from "next/link"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"
import { Line, LineChart, ResponsiveContainer, XAxis, YAxis, CartesianGrid, Legend } from "recharts"

// Sample data - in a real app, this would come from your API
const performanceData = [
  { month: "Jan", spotify: 1200, apple: 900, youtube: 1700, tiktok: 2400, youtubeMusic: 800, bandcamp: 300 },
  { month: "Feb", spotify: 1900, apple: 1200, youtube: 1500, tiktok: 3100, youtubeMusic: 950, bandcamp: 350 },
  { month: "Mar", spotify: 2100, apple: 1400, youtube: 1900, tiktok: 3800, youtubeMusic: 1100, bandcamp: 400 },
  { month: "Apr", spotify: 2400, apple: 1600, youtube: 2200, tiktok: 4200, youtubeMusic: 1300, bandcamp: 450 },
  { month: "May", spotify: 2200, apple: 1800, youtube: 2400, tiktok: 4800, youtubeMusic: 1500, bandcamp: 500 },
  { month: "Jun", spotify: 2600, apple: 2100, youtube: 2700, tiktok: 5200, youtubeMusic: 1800, bandcamp: 550 },
]

const platformCategories = [
  {
    name: "Music Streaming",
    icon: Music,
    platforms: [
      { name: "Spotify", connected: true, status: "active" },
      { name: "Apple Music", connected: true, status: "active" },
      { name: "SoundCloud", connected: false, status: "disconnected" },
      { name: "Bandcamp", connected: true, status: "active" },
      { name: "Deezer", connected: false, status: "disconnected" },
      { name: "Amazon Music", connected: false, status: "disconnected" },
      { name: "YouTube Music", connected: true, status: "active" },
      { name: "Tidal", connected: false, status: "disconnected" },
    ],
  },
  {
    name: "Social Networks",
    icon: Share2,
    platforms: [
      { name: "Instagram", connected: true, status: "active" },
      { name: "TikTok", connected: true, status: "active" },
      { name: "Twitter/X", connected: false, status: "disconnected" },
      { name: "Facebook", connected: true, status: "active" },
      { name: "LinkedIn", connected: false, status: "disconnected" },
      { name: "Snapchat", connected: false, status: "disconnected" },
    ],
  },
  {
    name: "Video Platforms",
    icon: Video,
    platforms: [
      { name: "YouTube", connected: true, status: "active" },
      { name: "Vimeo", connected: false, status: "disconnected" },
      { name: "Twitch", connected: false, status: "disconnected" },
    ],
  },
  {
    name: "Regional Platforms",
    icon: MapPin,
    platforms: [
      { name: "Boomplay", connected: false, status: "disconnected" },
      { name: "Anghami", connected: false, status: "disconnected" },
      { name: "JioSaavn", connected: false, status: "disconnected" },
      { name: "Melon", connected: false, status: "disconnected" },
    ],
  },
]

export default function AnalyticsDashboard() {
  const [selectedPlatform, setSelectedPlatform] = useState("all")

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Analytics Dashboard</h1>
          <p className="text-muted-foreground">Track your performance across all connected platforms</p>
        </div>
        <Button asChild>
          <Link href="/connections">
            <Plus className="mr-2 h-4 w-4" />
            Connect Platform
          </Link>
        </Button>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Streams</CardTitle>
            <Radio className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">45,231</div>
            <div className="flex items-center space-x-2">
              <TrendingUp className="h-4 w-4 text-emerald-500" />
              <p className="text-xs text-emerald-500">+20.1% from last month</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Followers</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">12,543</div>
            <div className="flex items-center space-x-2">
              <TrendingUp className="h-4 w-4 text-emerald-500" />
              <p className="text-xs text-emerald-500">+12.2% from last month</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Engagement Rate</CardTitle>
            <Share2 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">5.2%</div>
            <div className="flex items-center space-x-2">
              <TrendingDown className="h-4 w-4 text-red-500" />
              <p className="text-xs text-red-500">-0.5% from last month</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Avg. Listen Time</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">2:45</div>
            <div className="flex items-center space-x-2">
              <TrendingUp className="h-4 w-4 text-emerald-500" />
              <p className="text-xs text-emerald-500">+0:12 from last month</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="col-span-4">
        <CardHeader>
          <CardTitle>Performance Across Platforms</CardTitle>
          <CardDescription>Compare your performance metrics across different platforms</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-[300px] md:h-[350px] lg:h-[400px]">
            <ChartContainer
              config={{
                spotify: {
                  label: "Spotify",
                  color: "hsl(var(--chart-1))",
                },
                apple: {
                  label: "Apple Music",
                  color: "hsl(var(--chart-2))",
                },
                youtube: {
                  label: "YouTube",
                  color: "hsl(var(--chart-3))",
                },
                tiktok: {
                  label: "TikTok",
                  color: "hsl(var(--chart-4))",
                },
                youtubeMusic: {
                  label: "YouTube Music",
                  color: "hsl(var(--chart-5))",
                },
                bandcamp: {
                  label: "Bandcamp",
                  color: "hsl(var(--chart-6))",
                },
              }}
              className="w-full h-full"
            >
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={performanceData} margin={{ top: 20, right: 30, left: 20, bottom: 60 }}>
                  <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
                  <XAxis dataKey="month" tick={{ fontSize: 12 }} tickMargin={10} />
                  <YAxis tick={{ fontSize: 12 }} tickMargin={10} width={40} />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Legend verticalAlign="bottom" height={36} wrapperStyle={{ paddingTop: "10px" }} />
                  <Line
                    type="monotone"
                    dataKey="spotify"
                    stroke="var(--color-spotify)"
                    strokeWidth={2}
                    dot={{ r: 4 }}
                    activeDot={{ r: 6 }}
                  />
                  <Line
                    type="monotone"
                    dataKey="apple"
                    stroke="var(--color-apple)"
                    strokeWidth={2}
                    dot={{ r: 4 }}
                    activeDot={{ r: 6 }}
                  />
                  <Line
                    type="monotone"
                    dataKey="youtube"
                    stroke="var(--color-youtube)"
                    strokeWidth={2}
                    dot={{ r: 4 }}
                    activeDot={{ r: 6 }}
                  />
                  <Line
                    type="monotone"
                    dataKey="tiktok"
                    stroke="var(--color-tiktok)"
                    strokeWidth={2}
                    dot={{ r: 4 }}
                    activeDot={{ r: 6 }}
                  />
                  <Line
                    type="monotone"
                    dataKey="youtubeMusic"
                    stroke="var(--color-youtubeMusic)"
                    strokeWidth={2}
                    dot={{ r: 4 }}
                    activeDot={{ r: 6 }}
                  />
                  <Line
                    type="monotone"
                    dataKey="bandcamp"
                    stroke="var(--color-bandcamp)"
                    strokeWidth={2}
                    dot={{ r: 4 }}
                    activeDot={{ r: 6 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </ChartContainer>
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-4 md:grid-cols-7">
        <Card className="md:col-span-5">
          <CardHeader>
            <CardTitle>Platform Insights</CardTitle>
            <CardDescription>Detailed analytics from your connected platforms</CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="overview" className="space-y-4">
              <TabsList>
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="streaming">Streaming</TabsTrigger>
                <TabsTrigger value="social">Social</TabsTrigger>
                <TabsTrigger value="video">Video</TabsTrigger>
                <TabsTrigger value="regional">Regional</TabsTrigger>
              </TabsList>
              <TabsContent value="overview" className="space-y-4">
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="h-2 w-2 rounded-full bg-green-500"></div>
                        <span className="text-sm font-medium">Spotify</span>
                      </div>
                      <span className="text-sm font-medium">12,432</span>
                    </div>
                    <div className="h-2 w-full rounded-full bg-muted">
                      <div className="h-2 w-[70%] rounded-full bg-green-500"></div>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="h-2 w-2 rounded-full bg-pink-500"></div>
                        <span className="text-sm font-medium">Apple Music</span>
                      </div>
                      <span className="text-sm font-medium">8,765</span>
                    </div>
                    <div className="h-2 w-full rounded-full bg-muted">
                      <div className="h-2 w-[45%] rounded-full bg-pink-500"></div>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="h-2 w-2 rounded-full bg-red-500"></div>
                        <span className="text-sm font-medium">YouTube</span>
                      </div>
                      <span className="text-sm font-medium">15,876</span>
                    </div>
                    <div className="h-2 w-full rounded-full bg-muted">
                      <div className="h-2 w-[85%] rounded-full bg-red-500"></div>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="h-2 w-2 rounded-full bg-blue-500"></div>
                        <span className="text-sm font-medium">TikTok</span>
                      </div>
                      <span className="text-sm font-medium">21,543</span>
                    </div>
                    <div className="h-2 w-full rounded-full bg-muted">
                      <div className="h-2 w-full rounded-full bg-blue-500"></div>
                    </div>
                  </div>
                </div>

                <div className="rounded-lg border p-4">
                  <h3 className="font-medium">Top Performing Content</h3>
                  <div className="mt-4 space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="h-10 w-10 rounded bg-muted"></div>
                        <div>
                          <p className="text-sm font-medium">Summer Nights (Single)</p>
                          <p className="text-xs text-muted-foreground">Spotify • 5,432 streams</p>
                        </div>
                      </div>
                      <Button variant="ghost" size="sm">
                        <ArrowUpRight className="h-4 w-4" />
                      </Button>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="h-10 w-10 rounded bg-muted"></div>
                        <div>
                          <p className="text-sm font-medium">Studio Session (Video)</p>
                          <p className="text-xs text-muted-foreground">YouTube • 12,876 views</p>
                        </div>
                      </div>
                      <Button variant="ghost" size="sm">
                        <ArrowUpRight className="h-4 w-4" />
                      </Button>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="h-10 w-10 rounded bg-muted"></div>
                        <div>
                          <p className="text-sm font-medium">Dance Challenge</p>
                          <p className="text-xs text-muted-foreground">TikTok • 45,231 views</p>
                        </div>
                      </div>
                      <Button variant="ghost" size="sm">
                        <ArrowUpRight className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              </TabsContent>
              <TabsContent value="streaming">
                <div className="rounded-lg border p-4">
                  <h3 className="font-medium">Streaming Platforms Performance</h3>
                  <p className="text-sm text-muted-foreground">Detailed metrics from music streaming services</p>

                  <div className="mt-4 space-y-4">
                    {/* Content would go here */}
                    <p className="text-sm text-muted-foreground">Detailed streaming analytics will appear here</p>
                  </div>
                </div>
              </TabsContent>
              <TabsContent value="social">
                <div className="rounded-lg border p-4">
                  <h3 className="font-medium">Social Media Performance</h3>
                  <p className="text-sm text-muted-foreground">Engagement metrics from social platforms</p>

                  <div className="mt-4 space-y-4">
                    {/* Content would go here */}
                    <p className="text-sm text-muted-foreground">Detailed social media analytics will appear here</p>
                  </div>
                </div>
              </TabsContent>
              <TabsContent value="video">
                <div className="rounded-lg border p-4">
                  <h3 className="font-medium">Video Platform Performance</h3>
                  <p className="text-sm text-muted-foreground">View and engagement metrics from video platforms</p>

                  <div className="mt-4 space-y-4">
                    {/* Content would go here */}
                    <p className="text-sm text-muted-foreground">Detailed video platform analytics will appear here</p>
                  </div>
                </div>
              </TabsContent>
              <TabsContent value="regional">
                <div className="rounded-lg border p-4">
                  <h3 className="font-medium">Regional Platform Performance</h3>
                  <p className="text-sm text-muted-foreground">Metrics from region-specific platforms</p>

                  <div className="mt-4 space-y-4">
                    {/* Content would go here */}
                    <p className="text-sm text-muted-foreground">
                      Detailed regional platform analytics will appear here
                    </p>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle>Connected Platforms</CardTitle>
            <CardDescription>Manage your platform connections</CardDescription>
          </CardHeader>
          <CardContent className="max-h-[400px] overflow-auto">
            <div className="space-y-6">
              {platformCategories.map((category) => (
                <div key={category.name} className="space-y-2">
                  <div className="flex items-center gap-2">
                    <category.icon className="h-4 w-4 text-muted-foreground" />
                    <h3 className="text-sm font-medium">{category.name}</h3>
                  </div>
                  <div className="space-y-1">
                    {category.platforms.map((platform) => (
                      <div
                        key={platform.name}
                        className="flex items-center justify-between rounded-md px-2 py-1 hover:bg-muted"
                      >
                        <span className="text-sm">{platform.name}</span>
                        {platform.connected ? (
                          <Badge variant="outline" className="bg-green-500/10 text-green-500 border-green-500/20">
                            Connected
                          </Badge>
                        ) : (
                          <Button size="sm" variant="ghost" className="h-7 text-xs">
                            Connect
                          </Button>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
