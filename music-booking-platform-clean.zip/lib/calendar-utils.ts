import type { CalendarEvent, CalendarProvider } from "@/types/calendar"

/**
 * Generate an iCalendar (.ics) file content for an event
 */
export function generateICalContent(event: CalendarEvent): string {
  const formatDate = (date: string) => {
    const d = new Date(date)
    return d
      .toISOString()
      .replace(/-/g, "")
      .replace(/:/g, "")
      .replace(/\.\d{3}/g, "")
  }

  let icsContent = [
    "BEGIN:VCALENDAR",
    "VERSION:2.0",
    "CALSCALE:GREGORIAN",
    "METHOD:PUBLISH",
    "BEGIN:VEVENT",
    `UID:${event.id}@gigmit.com`,
    `SUMMARY:${event.title}`,
    `DESCRIPTION:${event.description.replace(/\n/g, "\\n")}`,
    `LOCATION:${event.location}`,
    `DTSTART:${formatDate(event.startTime)}`,
    `DTEND:${formatDate(event.endTime)}`,
    `DTSTAMP:${formatDate(new Date().toISOString())}`,
  ]

  // Add organizer if available
  if (event.organizer) {
    icsContent.push(`ORGANIZER;CN=${event.organizer.name}:mailto:${event.organizer.email}`)
  }

  // Add attendees if available
  if (event.attendees && event.attendees.length > 0) {
    event.attendees.forEach((attendee) => {
      icsContent.push(`ATTENDEE;CN=${attendee.name}:mailto:${attendee.email}`)
    })
  }

  icsContent = icsContent.concat(["END:VEVENT", "END:VCALENDAR"])

  return icsContent.join("\r\n")
}

/**
 * Generate calendar URLs for different providers
 */
export function getCalendarUrls(event: CalendarEvent): Record<CalendarProvider, string> {
  // Format dates for URL parameters
  const formatDateForUrl = (date: string) => {
    return new Date(date).toISOString().replace(/-|:|\.\d{3}/g, "")
  }

  const startTime = formatDateForUrl(event.startTime)
  const endTime = formatDateForUrl(event.endTime)

  // Encode text for URL parameters
  const title = encodeURIComponent(event.title)
  const description = encodeURIComponent(event.description)
  const location = encodeURIComponent(event.location)

  // Google Calendar URL
  const googleUrl = `https://calendar.google.com/calendar/render?action=TEMPLATE&text=${title}&dates=${startTime}/${endTime}&details=${description}&location=${location}&sf=true&output=xml`

  // Outlook Web URL
  const outlookUrl = `https://outlook.office.com/calendar/0/deeplink/compose?subject=${title}&body=${description}&location=${location}&startdt=${event.startTime}&enddt=${event.endTime}`

  // Apple Calendar uses .ics file
  const icalData = generateICalContent(event)
  const icalBlob = new Blob([icalData], { type: "text/calendar;charset=utf-8" })
  const appleUrl = URL.createObjectURL(icalBlob)

  // iCal generic URL (same as Apple but with different naming)
  const icalUrl = appleUrl

  return {
    google: googleUrl,
    outlook: outlookUrl,
    apple: appleUrl,
    ical: icalUrl,
  }
}

/**
 * Download an iCalendar file
 */
export function downloadICalFile(event: CalendarEvent): void {
  const icalContent = generateICalContent(event)
  const blob = new Blob([icalContent], { type: "text/calendar;charset=utf-8" })
  const url = URL.createObjectURL(blob)

  const link = document.createElement("a")
  link.href = url
  link.setAttribute("download", `${event.title.replace(/\s+/g, "-")}.ics`)
  document.body.appendChild(link)
  link.click()
  document.body.removeChild(link)

  // Clean up the URL object
  setTimeout(() => URL.revokeObjectURL(url), 100)
}
