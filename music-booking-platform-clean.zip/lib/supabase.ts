import { createClient } from "@supabase/supabase-js"
import { cookies } from "next/headers"
import type { Database } from "@/types/supabase"

// Re-export createClient to fix deployment error
export { createClient } from "@supabase/supabase-js"

// Get environment variables with error handling
const getSupabaseUrl = () => {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL
  if (!url) {
    console.error("Missing environment variable: NEXT_PUBLIC_SUPABASE_URL")
    return "https://placeholder-url.supabase.co" // Fallback for client-side to prevent crashes
  }
  return url
}

const getSupabaseAnonKey = () => {
  const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY
  if (!key) {
    console.error("Missing environment variable: NEXT_PUBLIC_SUPABASE_ANON_KEY")
    return "placeholder-key" // Fallback for client-side to prevent crashes
  }
  return key
}

// Create a Supabase client for server components
export function createServerClient() {
  try {
    const cookieStore = cookies()

    return createClient<Database>(getSupabaseUrl(), getSupabaseAnonKey(), {
      auth: {
        persistSession: false,
        autoRefreshToken: false,
      },
      cookies: {
        get(name) {
          return cookieStore.get(name)?.value
        },
      },
    })
  } catch (error) {
    console.error("Error creating server client:", error)
    throw error
  }
}

// Create a singleton Supabase client for client-side usage
let clientSingleton: ReturnType<typeof createClient<Database>>

export function getSupabaseBrowserClient() {
  if (typeof window === "undefined") {
    console.warn("getSupabaseBrowserClient called in server environment")
    // Return a mock client for SSR to prevent errors
    return {
      auth: {
        getSession: () => Promise.resolve({ data: { session: null }, error: null }),
        onAuthStateChange: () => ({ data: { subscription: { unsubscribe: () => {} } } }),
      },
    } as any
  }

  try {
    if (clientSingleton) {
      return clientSingleton
    }

    const url = getSupabaseUrl()
    const key = getSupabaseAnonKey()

    if (!url || !key || url.includes("placeholder") || key.includes("placeholder")) {
      console.error("Invalid Supabase credentials:", { url, key: key ? "[REDACTED]" : "missing" })
      throw new Error("Invalid Supabase configuration")
    }

    clientSingleton = createClient<Database>(url, key, {
      auth: {
        persistSession: true,
        storageKey: "gigmit-auth-token",
        autoRefreshToken: true,
      },
    })

    return clientSingleton
  } catch (error) {
    console.error("Error creating browser client:", error)
    throw error
  }
}

// Get a Supabase client for server components and server actions
export function getSupabaseServerClient() {
  try {
    const url = getSupabaseUrl()
    const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY || getSupabaseAnonKey()

    return createClient<Database>(url, serviceKey, {
      auth: {
        persistSession: false,
      },
    })
  } catch (error) {
    console.error("Error creating server client with service role:", error)
    throw error
  }
}
