import { type NextRequest, NextResponse } from "next/server"
import { getSupabaseServerClient } from "./supabase"

export async function withErrorHandling(
  req: NextRequest,
  handler: (supabase: ReturnType<typeof getSupabaseServerClient>) => Promise<NextResponse>,
) {
  try {
    const supabase = getSupabaseServerClient()
    return await handler(supabase)
  } catch (error: any) {
    console.error("API error:", error)
    return NextResponse.json({ error: error.message || "An unexpected error occurred" }, { status: 500 })
  }
}
