"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { createGigListing } from "@/app/actions/gig-listings"
import { useToast } from "@/hooks/use-toast"
import { MultiSelect } from "@/components/multi-select"

// Updated to include African music genres
const genreOptions = [
  // African genres
  { label: "Afrobeat", value: "afrobeat" },
  { label: "Highlife", value: "highlife" },
  { label: "Afro-fusion", value: "afro-fusion" },
  { label: "Amapiano", value: "amapiano" },
  { label: "Soukous", value: "soukous" },
  { label: "Mbalax", value: "mbalax" },
  { label: "Bongo Flava", value: "bongo-flava" },
  { label: "Kwaito", value: "kwaito" },
  { label: "Jùjú", value: "juju" },
  { label: "Fuji", value: "fuji" },
  { label: "Afro-jazz", value: "afro-jazz" },
  { label: "Gnawa", value: "gnawa" },
  { label: "Rai", value: "rai" },
  { label: "Chimurenga", value: "chimurenga" },
  { label: "Benga", value: "benga" },
  { label: "Ethio-jazz", value: "ethio-jazz" },
  { label: "Taarab", value: "taarab" },
  { label: "Afro-house", value: "afro-house" },
  { label: "Coupe-Decale", value: "coupe-decale" },
  { label: "Ndombolo", value: "ndombolo" },
  // Other global genres
  { label: "Pop", value: "pop" },
  { label: "Hip Hop", value: "hip-hop" },
  { label: "R&B", value: "r&b" },
  { label: "Jazz", value: "jazz" },
  { label: "Reggae", value: "reggae" },
]

const currencyOptions = [
  { label: "EUR (€)", value: "EUR" },
  { label: "USD ($)", value: "USD" },
  { label: "GBP (£)", value: "GBP" },
  { label: "NGN (₦)", value: "NGN" },
  { label: "ZAR (R)", value: "ZAR" },
  { label: "KES (KSh)", value: "KES" },
  { label: "GHS (GH₵)", value: "GHS" },
  { label: "EGP (E£)", value: "EGP" },
  { label: "MAD (DH)", value: "MAD" },
]

interface CreateGigFormProps {
  promoterId: string
}

export function CreateGigForm({ promoterId }: CreateGigFormProps) {
  const [isLoading, setIsLoading] = useState(false)
  const [selectedGenres, setSelectedGenres] = useState<string[]>([])
  const router = useRouter()
  const { toast } = useToast()

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setIsLoading(true)

    const formData = new FormData(e.currentTarget)
    const title = formData.get("title") as string
    const description = formData.get("description") as string
    const eventDate = formData.get("eventDate") as string
    const applicationDeadline = formData.get("applicationDeadline") as string
    const location = formData.get("location") as string
    const venue = formData.get("venue") as string
    const feeMin = Number.parseInt(formData.get("feeMin") as string)
    const feeMax = Number.parseInt(formData.get("feeMax") as string)
    const feeCurrency = formData.get("feeCurrency") as string
    const audienceSize = formData.get("audienceSize")
      ? Number.parseInt(formData.get("audienceSize") as string)
      : undefined
    const duration = formData.get("duration") ? Number.parseInt(formData.get("duration") as string) : undefined
    const requirements = formData.get("requirements") as string
    const perks = formData.get("perks") as string

    const result = await createGigListing(
      {
        title,
        description,
        eventDate,
        applicationDeadline,
        location,
        venue,
        genres: selectedGenres,
        feeMin,
        feeMax,
        feeCurrency,
        audienceSize,
        duration,
        requirements,
        perks,
      },
      promoterId,
    )

    setIsLoading(false)

    if (result.success) {
      toast({
        title: "Success",
        description: "Your gig listing has been created.",
      })
      router.push("/promoter")
    } else {
      toast({
        title: "Error",
        description: result.error || "Failed to create gig listing.",
        variant: "destructive",
      })
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Create New Gig Listing</CardTitle>
        <CardDescription>Fill in the details to create a new gig opportunity for African artists</CardDescription>
      </CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="title">Gig Title</Label>
            <Input id="title" name="title" placeholder="e.g. Weekend Festival Slot" required />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              name="description"
              placeholder="Describe the gig opportunity in detail"
              rows={4}
              required
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="eventDate">Event Date</Label>
              <Input id="eventDate" name="eventDate" type="date" required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="applicationDeadline">Application Deadline</Label>
              <Input id="applicationDeadline" name="applicationDeadline" type="date" required />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="location">Location</Label>
              <Input id="location" name="location" placeholder="e.g. Lagos, Nigeria" required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="venue">Venue</Label>
              <Input id="venue" name="venue" placeholder="e.g. Club XYZ" />
            </div>
          </div>

          <div className="space-y-2">
            <Label>African Music Genres</Label>
            <MultiSelect
              options={genreOptions}
              selected={selectedGenres}
              onChange={setSelectedGenres}
              placeholder="Select genres"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="feeMin">Minimum Fee</Label>
              <Input id="feeMin" name="feeMin" type="number" min="0" required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="feeMax">Maximum Fee</Label>
              <Input id="feeMax" name="feeMax" type="number" min="0" required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="feeCurrency">Currency</Label>
              <Select name="feeCurrency" defaultValue="USD">
                <SelectTrigger>
                  <SelectValue placeholder="Select currency" />
                </SelectTrigger>
                <SelectContent>
                  {currencyOptions.map((option) => (
                    <SelectItem key={option.value} value={option.value}>
                      {option.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="audienceSize">Expected Audience Size</Label>
              <Input id="audienceSize" name="audienceSize" type="number" min="0" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="duration">Performance Duration (minutes)</Label>
              <Input id="duration" name="duration" type="number" min="0" />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="requirements">Technical Requirements</Label>
            <Textarea
              id="requirements"
              name="requirements"
              placeholder="List any technical requirements for the artist"
              rows={3}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="perks">Perks</Label>
            <Textarea
              id="perks"
              name="perks"
              placeholder="List any additional perks for the artist (accommodation, food, etc.)"
              rows={3}
            />
          </div>
        </CardContent>
        <CardFooter>
          <Button type="submit" className="w-full" disabled={isLoading}>
            {isLoading ? "Creating..." : "Create Gig Listing"}
          </Button>
        </CardFooter>
      </form>
    </Card>
  )
}
