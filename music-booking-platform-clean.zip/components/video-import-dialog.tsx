"use client"

import { useState } from "react"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import * as z from "zod"
import { LinkIcon } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { importVideo } from "@/app/actions/profile-actions"

const videoUrlSchema = z.object({
  title: z.string().min(2, "Title is required"),
  videoUrl: z
    .string()
    .url("Please enter a valid URL")
    .refine(
      (url) => {
        // YouTube URL validation
        const youtubeRegex =
          /^(https?:\/\/)?(www\.)?(youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([a-zA-Z0-9_-]{11})(.*)$/
        // Vimeo URL validation
        const vimeoRegex = /^(https?:\/\/)?(www\.)?(vimeo\.com\/|player\.vimeo\.com\/video\/)(\d+)(.*)$/
        return youtubeRegex.test(url) || vimeoRegex.test(url)
      },
      {
        message: "Please enter a valid YouTube or Vimeo URL",
      },
    ),
})

type FormValues = z.infer<typeof videoUrlSchema>

interface VideoImportDialogProps {
  buttonLabel?: string
  buttonVariant?: "default" | "outline" | "secondary" | "ghost" | "link" | "destructive"
  buttonSize?: "default" | "sm" | "lg" | "icon"
  className?: string
  onSuccess?: (url: string, title: string, platform: string) => void
}

export function VideoImportDialog({
  buttonLabel = "Import Video",
  buttonVariant = "outline",
  buttonSize = "default",
  className,
  onSuccess,
}: VideoImportDialogProps) {
  const [open, setOpen] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const { toast } = useToast()

  const form = useForm<FormValues>({
    resolver: zodResolver(videoUrlSchema),
    defaultValues: {
      title: "",
      videoUrl: "",
    },
  })

  function getPlatform(url: string): string {
    if (url.includes("youtube") || url.includes("youtu.be")) {
      return "youtube"
    } else if (url.includes("vimeo")) {
      return "vimeo"
    }
    return "unknown"
  }

  function getVideoId(url: string, platform: string): string {
    if (platform === "youtube") {
      const match = url.match(
        /^(https?:\/\/)?(www\.)?(youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([a-zA-Z0-9_-]{11})/,
      )
      return match ? match[4] : ""
    } else if (platform === "vimeo") {
      const match = url.match(/^(https?:\/\/)?(www\.)?(vimeo\.com\/|player\.vimeo\.com\/video\/)(\d+)/)
      return match ? match[4] : ""
    }
    return ""
  }

  function getEmbedUrl(url: string): string {
    const platform = getPlatform(url)
    const videoId = getVideoId(url, platform)

    if (platform === "youtube" && videoId) {
      return `https://www.youtube.com/embed/${videoId}`
    } else if (platform === "vimeo" && videoId) {
      return `https://player.vimeo.com/video/${videoId}`
    }

    return url
  }

  function getThumbnailUrl(url: string): string {
    const platform = getPlatform(url)
    const videoId = getVideoId(url, platform)

    if (platform === "youtube" && videoId) {
      return `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`
    } else if (platform === "vimeo" && videoId) {
      // Vimeo doesn't have a direct thumbnail URL, we'd need to use their API
      // For now, return a placeholder
      return `/placeholder.svg?height=180&width=320&query=vimeo video thumbnail`
    }

    return `/placeholder.svg?height=180&width=320&query=video thumbnail`
  }

  async function onSubmit(data: FormValues) {
    setIsSubmitting(true)

    try {
      const platform = getPlatform(data.videoUrl)
      const embedUrl = getEmbedUrl(data.videoUrl)
      const thumbnailUrl = getThumbnailUrl(data.videoUrl)

      const result = await importVideo({
        title: data.title,
        videoUrl: data.videoUrl,
        embedUrl,
        thumbnailUrl,
        platform,
      })

      if (result.error) {
        toast({
          title: "Error",
          description: result.error,
          variant: "destructive",
        })
      } else {
        toast({
          title: "Video Imported",
          description: `Your video has been imported successfully.`,
        })
        setOpen(false)
        form.reset()

        if (onSuccess) {
          onSuccess(embedUrl, data.title, platform)
        }
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "An unexpected error occurred. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant={buttonVariant} size={buttonSize} className={className}>
          {buttonLabel}
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Import Video</DialogTitle>
          <DialogDescription>Import videos from YouTube or Vimeo to showcase your performances.</DialogDescription>
        </DialogHeader>
        <Tabs defaultValue="url">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="url">Video URL</TabsTrigger>
            <TabsTrigger value="help">Help</TabsTrigger>
          </TabsList>
          <TabsContent value="url" className="pt-4">
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="title"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Title*</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g. Live at Jazz Festival" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="videoUrl"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Video URL*</FormLabel>
                      <FormControl>
                        <div className="flex items-center">
                          <Input
                            {...field}
                            placeholder="https://youtube.com/watch?v=... or https://vimeo.com/..."
                            className="flex-1"
                          />
                          <LinkIcon className="ml-2 h-4 w-4 text-muted-foreground" />
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <DialogFooter className="pt-4">
                  <Button type="button" variant="outline" onClick={() => setOpen(false)}>
                    Cancel
                  </Button>
                  <Button type="submit" disabled={isSubmitting}>
                    {isSubmitting ? "Importing..." : "Import Video"}
                  </Button>
                </DialogFooter>
              </form>
            </Form>
          </TabsContent>
          <TabsContent value="help" className="pt-4 space-y-4">
            <div>
              <h3 className="font-medium mb-2">Supported Platforms</h3>
              <ul className="list-disc pl-5 space-y-1">
                <li>YouTube (youtube.com, youtu.be)</li>
                <li>Vimeo (vimeo.com)</li>
              </ul>
            </div>
            <div>
              <h3 className="font-medium mb-2">How to Find Your Video URL</h3>
              <p className="text-sm text-muted-foreground mb-2">For YouTube:</p>
              <ol className="list-decimal pl-5 space-y-1 text-sm">
                <li>Go to the video on YouTube</li>
                <li>Click the "Share" button below the video</li>
                <li>Copy the URL provided</li>
              </ol>
              <p className="text-sm text-muted-foreground mt-2 mb-2">For Vimeo:</p>
              <ol className="list-decimal pl-5 space-y-1 text-sm">
                <li>Go to the video on Vimeo</li>
                <li>Copy the URL from your browser's address bar</li>
              </ol>
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  )
}
