"use client"

import type React from "react"

import { useState } from "react"
import { useSupabase } from "@/contexts/supabase-context"
import { useSupabaseQuery } from "@/hooks/use-supabase-query"
import { useSupabaseMutation } from "@/hooks/use-supabase-mutation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useToast } from "@/hooks/use-toast"
import { ErrorBoundary } from "@/components/error-boundary"

export function ExampleSupabaseUsage() {
  const { isReady } = useSupabase()
  const { toast } = useToast()
  const [newItemName, setNewItemName] = useState("")

  // Example query
  const {
    data: items,
    isLoading,
    error,
    refetch,
  } = useSupabaseQuery({
    table: "example_items",
    orderBy: { column: "created_at", ascending: false },
    enabled: isReady,
  })

  // Example mutation
  const { insert, isLoading: isInserting } = useSupabaseMutation({
    table: "example_items",
    onSuccess: () => {
      toast({ title: "Item created successfully" })
      setNewItemName("")
      refetch()
    },
    onError: (error) => {
      toast({
        title: "Failed to create item",
        description: error.message,
        variant: "destructive",
      })
    },
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!newItemName.trim()) return

    await insert({ name: newItemName.trim() })
  }

  if (!isReady) {
    return (
      <Card>
        <CardContent className="pt-6">
          <p className="text-center text-muted-foreground">Initializing database connection...</p>
        </CardContent>
      </Card>
    )
  }

  return (
    <ErrorBoundary>
      <Card>
        <CardHeader>
          <CardTitle>Example Items</CardTitle>
          <CardDescription>Demonstrating Supabase context usage</CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="py-8 flex justify-center">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
            </div>
          ) : error ? (
            <div className="py-4 text-destructive">Error loading items: {error.message}</div>
          ) : items?.length === 0 ? (
            <p className="text-center py-4 text-muted-foreground">No items found</p>
          ) : (
            <ul className="space-y-2">
              {items?.map((item: any) => (
                <li key={item.id} className="p-3 border rounded-md">
                  {item.name}
                </li>
              ))}
            </ul>
          )}

          <form onSubmit={handleSubmit} className="mt-6 space-y-4">
            <div className="space-y-2">
              <Label htmlFor="item-name">New Item</Label>
              <Input
                id="item-name"
                value={newItemName}
                onChange={(e) => setNewItemName(e.target.value)}
                placeholder="Enter item name"
                disabled={isInserting}
              />
            </div>
            <Button type="submit" disabled={isInserting || !newItemName.trim()}>
              {isInserting ? "Creating..." : "Create Item"}
            </Button>
          </form>
        </CardContent>
      </Card>
    </ErrorBoundary>
  )
}
