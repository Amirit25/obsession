import Link from "next/link"
import { Music, Calendar, MapPin, Users } from "lucide-react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"

interface GigListingCardProps {
  id: string
  title: string
  description: string
  location: string
  eventDate: string
  genres: string[]
  feeRange: {
    min: number
    max: number
    currency: string
  }
  audienceSize?: number
  promoterName: string
  isArtist?: boolean
}

export function GigListingCard({
  id,
  title,
  description,
  location,
  eventDate,
  genres,
  feeRange,
  audienceSize,
  promoterName,
  isArtist = true,
}: GigListingCardProps) {
  const formattedDate = new Date(eventDate)
  const dateString = formattedDate.toLocaleDateString("en-US", {
    year: "numeric",
    month: "long",
    day: "numeric",
  })

  const audienceSizeText = audienceSize
    ? audienceSize > 1000
      ? `${Math.floor(audienceSize / 1000)}k+ audience`
      : `${audienceSize}+ audience`
    : "Audience size not specified"

  return (
    <Card>
      <CardHeader className="pb-2">
        <div className="flex justify-between">
          <CardTitle>{title}</CardTitle>
          <span className="text-sm font-medium text-green-600 dark:text-green-400">
            {feeRange.currency === "EUR" ? "€" : feeRange.currency === "USD" ? "$" : "£"}
            {feeRange.min}-{feeRange.max}
          </span>
        </div>
        <CardDescription className="flex items-center">
          <MapPin className="w-4 h-4 mr-1" /> {location}
        </CardDescription>
      </CardHeader>
      <CardContent className="pb-2">
        <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground mb-2">
          <div className="flex items-center">
            <Calendar className="w-4 h-4 mr-1" />
            {dateString}
          </div>
          <div className="flex items-center">
            <Music className="w-4 h-4 mr-1" />
            {genres.length > 0 ? genres.join(", ") : "Various genres"}
          </div>
          {audienceSize && (
            <div className="flex items-center">
              <Users className="w-4 h-4 mr-1" />
              {audienceSizeText}
            </div>
          )}
        </div>
        <p className="text-sm line-clamp-2">{description}</p>
        <div className="mt-2 flex flex-wrap gap-1">
          {genres.map((genre) => (
            <Badge key={genre} variant="outline" className="text-xs">
              {genre}
            </Badge>
          ))}
        </div>
      </CardContent>
      <CardFooter className="flex justify-between">
        <div className="text-sm text-muted-foreground">
          By <span className="font-medium text-foreground">{promoterName}</span>
        </div>
        <div>
          {isArtist ? (
            <Button variant="default" size="sm" asChild>
              <Link href={`/artist/apply/${id}`}>Apply Now</Link>
            </Button>
          ) : (
            <Button variant="default" size="sm" asChild>
              <Link href={`/promoter/gigs/${id}`}>View Details</Link>
            </Button>
          )}
        </div>
      </CardFooter>
    </Card>
  )
}
