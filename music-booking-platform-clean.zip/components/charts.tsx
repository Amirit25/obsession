"use client"

import {
  AreaChart as RechartsAreaChart,
  Area,
  BarChart as RechartsBarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
  LineChart as RechartsLineChart,
  Line,
} from "recharts"

const areaChartData = [
  { name: "Jan", spotify: 4000, apple: 2400, youtube: 1800, total: 8200 },
  { name: "Feb", spotify: 4200, apple: 2600, youtube: 2000, total: 8800 },
  { name: "Mar", spotify: 4500, apple: 2900, youtube: 2200, total: 9600 },
  { name: "Apr", spotify: 4800, apple: 3100, youtube: 2400, total: 10300 },
  { name: "May", spotify: 5100, apple: 3400, youtube: 2700, total: 11200 },
  { name: "Jun", spotify: 5400, apple: 3700, youtube: 3000, total: 12100 },
]

const lineChartData = [
  { name: "Jan", bookings: 5, views: 240 },
  { name: "Feb", bookings: 8, views: 320 },
  { name: "Mar", bookings: 12, views: 450 },
  { name: "Apr", bookings: 10, views: 380 },
  { name: "May", bookings: 15, views: 520 },
  { name: "Jun", bookings: 18, views: 610 },
]

const barChartData = [
  { name: "Spotify", streams: 5400, followers: 2400, engagement: 1800, revenue: 1200 },
  { name: "Apple Music", streams: 3700, followers: 1800, engagement: 1400, revenue: 900 },
  { name: "YouTube Music", streams: 3000, followers: 2200, engagement: 2000, revenue: 600 },
  { name: "TikTok", streams: 2200, followers: 3800, engagement: 3200, revenue: 400 },
  { name: "Instagram", streams: 1800, followers: 3200, engagement: 2800, revenue: 300 },
]

const donutChartData = [
  { name: "Spotify", value: 45 },
  { name: "Apple Music", value: 25 },
  { name: "YouTube Music", value: 15 },
  { name: "TikTok", value: 10 },
  { name: "Instagram", value: 5 },
]

const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042", "#8884d8"]

interface ChartProps {
  className?: string
}

export function AreaChart({ className }: ChartProps) {
  return (
    <div className={className}>
      <ResponsiveContainer width="100%" height="100%">
        <RechartsAreaChart
          data={areaChartData}
          margin={{
            top: 10,
            right: 30,
            left: 0,
            bottom: 0,
          }}
        >
          <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
          <XAxis dataKey="name" />
          <YAxis />
          <Tooltip />
          <Area type="monotone" dataKey="spotify" stackId="1" stroke="#1DB954" fill="#1DB954" fillOpacity={0.6} />
          <Area type="monotone" dataKey="apple" stackId="1" stroke="#FC3C44" fill="#FC3C44" fillOpacity={0.6} />
          <Area type="monotone" dataKey="youtube" stackId="1" stroke="#FF0000" fill="#FF0000" fillOpacity={0.6} />
        </RechartsAreaChart>
      </ResponsiveContainer>
    </div>
  )
}

// Add the missing LineChart export
export function LineChart({ className }: ChartProps) {
  return (
    <div className={className}>
      <ResponsiveContainer width="100%" height="100%">
        <RechartsLineChart
          data={lineChartData}
          margin={{
            top: 10,
            right: 30,
            left: 0,
            bottom: 0,
          }}
        >
          <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
          <XAxis dataKey="name" />
          <YAxis yAxisId="left" />
          <YAxis yAxisId="right" orientation="right" />
          <Tooltip />
          <Legend />
          <Line
            yAxisId="left"
            type="monotone"
            dataKey="bookings"
            stroke="#8884d8"
            activeDot={{ r: 8 }}
            strokeWidth={2}
          />
          <Line yAxisId="right" type="monotone" dataKey="views" stroke="#82ca9d" strokeWidth={2} />
        </RechartsLineChart>
      </ResponsiveContainer>
    </div>
  )
}

export function BarChart({ className }: ChartProps) {
  return (
    <div className={className}>
      <ResponsiveContainer width="100%" height="100%">
        <RechartsBarChart
          data={barChartData}
          margin={{
            top: 20,
            right: 30,
            left: 20,
            bottom: 5,
          }}
        >
          <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
          <XAxis dataKey="name" />
          <YAxis />
          <Tooltip />
          <Legend />
          <Bar dataKey="streams" fill="#0088FE" />
          <Bar dataKey="followers" fill="#00C49F" />
          <Bar dataKey="engagement" fill="#FFBB28" />
        </RechartsBarChart>
      </ResponsiveContainer>
    </div>
  )
}

export function DonutChart({ className }: ChartProps) {
  return (
    <div className={className}>
      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <Pie
            data={donutChartData}
            cx="50%"
            cy="50%"
            innerRadius={60}
            outerRadius={80}
            fill="#8884d8"
            paddingAngle={5}
            dataKey="value"
            label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
          >
            {donutChartData.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
            ))}
          </Pie>
          <Tooltip />
          <Legend />
        </PieChart>
      </ResponsiveContainer>
    </div>
  )
}

export const Charts = () => {
  return (
    <div>
      <AreaChart />
      <BarChart />
      <DonutChart />
    </div>
  )
}
