"use client"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { X } from "lucide-react"

interface MobileMenuProps {
  isOpen: boolean
  onClose: () => void
}

export function MobileMenu({ isOpen, onClose }: MobileMenuProps) {
  if (!isOpen) return null

  return (
    <div className="fixed inset-0 z-50 bg-black/95 backdrop-blur-sm flex flex-col">
      <div className="flex justify-end p-4">
        <Button variant="ghost" size="icon" onClick={onClose} className="text-white">
          <X className="h-6 w-6" />
        </Button>
      </div>
      <div className="flex flex-col items-center justify-center flex-1 gap-8">
        <Link href="#features" className="text-xl text-white hover:text-yellow-400 transition-colors" onClick={onClose}>
          Features
        </Link>
        <Link href="#benefits" className="text-xl text-white hover:text-yellow-400 transition-colors" onClick={onClose}>
          Benefits
        </Link>
        <Link
          href="#testimonials"
          className="text-xl text-white hover:text-yellow-400 transition-colors"
          onClick={onClose}
        >
          Testimonials
        </Link>
        <Link
          href="/auth/login"
          className="text-xl text-white hover:text-yellow-400 transition-colors"
          onClick={onClose}
        >
          Log In
        </Link>
        <Button asChild size="lg" className="bg-yellow-400 hover:bg-yellow-500 text-black mt-4">
          <Link href="/auth/register" onClick={onClose}>
            Sign Up
          </Link>
        </Button>
      </div>
    </div>
  )
}
