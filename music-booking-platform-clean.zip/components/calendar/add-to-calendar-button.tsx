"use client"

import { useState } from "react"
import { Calendar, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import type { CalendarEvent } from "@/types/calendar"
import { downloadICalFile, getCalendarUrls } from "@/lib/calendar-utils"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { QRCodeSVG } from "qrcode.react"

interface AddToCalendarButtonProps {
  event: CalendarEvent
  variant?: "default" | "outline" | "secondary" | "ghost" | "link" | "destructive"
  size?: "default" | "sm" | "lg" | "icon"
  className?: string
}

export function AddToCalendarButton({
  event,
  variant = "outline",
  size = "default",
  className,
}: AddToCalendarButtonProps) {
  const [isQrDialogOpen, setIsQrDialogOpen] = useState(false)
  const [selectedProvider, setSelectedProvider] = useState<string | null>(null)

  const calendarUrls = getCalendarUrls(event)

  const handleCalendarSelect = (provider: string) => {
    if (provider === "apple" || provider === "ical") {
      downloadICalFile(event)
    } else if (provider === "qrcode") {
      setIsQrDialogOpen(true)
      setSelectedProvider("google") // Default to Google for QR code
    } else {
      window.open(calendarUrls[provider as keyof typeof calendarUrls], "_blank")
    }
  }

  return (
    <>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant={variant} size={size} className={className}>
            <Calendar className="mr-2 h-4 w-4" />
            Add to Calendar
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end">
          <DropdownMenuItem onClick={() => handleCalendarSelect("google")}>Google Calendar</DropdownMenuItem>
          <DropdownMenuItem onClick={() => handleCalendarSelect("outlook")}>Outlook Calendar</DropdownMenuItem>
          <DropdownMenuItem onClick={() => handleCalendarSelect("apple")}>Apple Calendar</DropdownMenuItem>
          <DropdownMenuItem onClick={() => handleCalendarSelect("ical")}>Download .ics File</DropdownMenuItem>
          <DropdownMenuItem onClick={() => handleCalendarSelect("qrcode")}>Show QR Code</DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>

      <Dialog open={isQrDialogOpen} onOpenChange={setIsQrDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center justify-between">
              <span>Scan with your phone</span>
              <Button variant="ghost" size="sm" className="h-8 w-8 p-0" onClick={() => setIsQrDialogOpen(false)}>
                <X className="h-4 w-4" />
              </Button>
            </DialogTitle>
          </DialogHeader>
          <div className="flex flex-col items-center justify-center p-4">
            <div className="mb-4">
              <select
                className="w-full rounded-md border border-input bg-background px-3 py-2"
                value={selectedProvider || "google"}
                onChange={(e) => setSelectedProvider(e.target.value)}
              >
                <option value="google">Google Calendar</option>
                <option value="outlook">Outlook Calendar</option>
              </select>
            </div>
            <div className="bg-white p-2 rounded-md">
              <QRCodeSVG
                value={calendarUrls[selectedProvider as keyof typeof calendarUrls] || calendarUrls.google}
                size={200}
                level="H"
              />
            </div>
            <p className="mt-4 text-sm text-center text-muted-foreground">
              Scan this QR code with your phone camera to add this event to your calendar
            </p>
          </div>
        </DialogContent>
      </Dialog>
    </>
  )
}
