"use client"

import { useState } from "react"
import type { CalendarIntegrationProps } from "@/types/calendar"
import { AddToCalendarButton } from "./add-to-calendar-button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Calendar, Check, Copy } from "lucide-react"

export function CalendarIntegration({ event, className }: CalendarIntegrationProps) {
  const [copied, setCopied] = useState(false)

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleString("en-US", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
      hour: "numeric",
      minute: "numeric",
    })
  }

  const copyEventDetails = () => {
    const eventDetails = `
Event: ${event.title}
Date: ${formatDate(event.startTime)}
Location: ${event.location}
Description: ${event.description}
    `.trim()

    navigator.clipboard.writeText(eventDetails)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <Card className={className}>
      <CardHeader>
        <CardTitle className="flex items-center">
          <Calendar className="mr-2 h-5 w-5" />
          Event Details
        </CardTitle>
        <CardDescription>Sync this event with your calendar</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <div className="font-medium">{event.title}</div>
          <div className="text-sm text-muted-foreground">
            {formatDate(event.startTime)} - {formatDate(event.endTime)}
          </div>
          <div className="text-sm">{event.location}</div>
        </div>

        <div className="flex flex-wrap gap-2">
          <AddToCalendarButton event={event} />

          <Button variant="outline" size="default" onClick={copyEventDetails}>
            {copied ? (
              <>
                <Check className="mr-2 h-4 w-4" />
                Copied
              </>
            ) : (
              <>
                <Copy className="mr-2 h-4 w-4" />
                Copy Details
              </>
            )}
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
