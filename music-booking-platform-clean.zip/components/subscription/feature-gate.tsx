"use client"

import { type ReactNode, useState, useEffect } from "react"
import { useSubscription } from "@/hooks/use-subscription"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Loader2, Lock } from "lucide-react"
import Link from "next/link"

interface FeatureGateProps {
  /**
   * The feature key to check access for
   */
  featureKey: string
  /**
   * The content to render if the user has access
   */
  children: ReactNode
  /**
   * Optional fallback content to render if the user doesn't have access
   */
  fallback?: ReactNode
  /**
   * Whether to show an upgrade prompt if the user doesn't have access
   */
  showUpgradePrompt?: boolean
}

export function FeatureGate({ featureKey, children, fallback, showUpgradePrompt = true }: FeatureGateProps) {
  const { checkAccess, isLoading: subscriptionLoading } = useSubscription()
  const [hasAccess, setHasAccess] = useState<boolean | null>(null)
  const [accessData, setAccessData] = useState<any>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const checkFeatureAccess = async () => {
      if (subscriptionLoading) return

      try {
        setIsLoading(true)
        const result = await checkAccess(featureKey)
        setHasAccess(result.hasAccess)
        setAccessData(result)
      } catch (error) {
        console.error("Error checking feature access:", error)
        setHasAccess(false)
      } finally {
        setIsLoading(false)
      }
    }

    checkFeatureAccess()
  }, [featureKey, checkAccess, subscriptionLoading])

  if (isLoading || subscriptionLoading) {
    return (
      <div className="flex justify-center items-center p-8">
        <Loader2 className="h-6 w-6 animate-spin text-primary" />
      </div>
    )
  }

  if (hasAccess) {
    return <>{children}</>
  }

  if (fallback) {
    return <>{fallback}</>
  }

  if (showUpgradePrompt) {
    return (
      <div className="p-6 border rounded-lg bg-gray-50 dark:bg-gray-900">
        <Alert className="mb-4">
          <Lock className="h-4 w-4" />
          <AlertTitle>Premium Feature</AlertTitle>
          <AlertDescription>{accessData?.reason || "This feature requires a premium subscription."}</AlertDescription>
        </Alert>
        <div className="text-center">
          <p className="mb-4">Upgrade your plan to unlock this feature and many more.</p>
          <Button asChild>
            <Link href="/upgrade">Upgrade Now</Link>
          </Button>
        </div>
      </div>
    )
  }

  return null
}
