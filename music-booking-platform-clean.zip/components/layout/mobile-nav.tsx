"use client"

import Link from "next/link"
import { useState } from "react"
import { usePathname, useRouter } from "next/navigation"
import { Menu, LogOut } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { useAuth } from "@/contexts/auth-context"
import { cn } from "@/lib/utils"

export function MobileNav() {
  const [open, setOpen] = useState(false)
  const pathname = usePathname()
  const router = useRouter()
  const { profile, signOut } = useAuth()

  // Handle logout
  const handleLogout = async () => {
    await signOut()
    router.push("/auth/login")
  }

  const routes = [
    {
      href: profile?.role === "artist" ? "/artist" : profile?.role === "promoter" ? "/promoter" : "/dashboard",
      label: "Dashboard",
      active: pathname === "/artist" || pathname === "/promoter" || pathname === "/dashboard",
    },
    {
      href: "/bookings",
      label: "Bookings",
      active: pathname === "/bookings",
    },
    {
      href: "/connections",
      label: "Connections",
      active: pathname === "/connections",
    },
    {
      href: "/messages",
      label: "Messages",
      active: pathname === "/messages" || pathname.startsWith("/messages/"),
    },
    {
      href: "/resources",
      label: "Resources",
      active: pathname === "/resources",
    },
    {
      href: "/upgrade",
      label: "Upgrade",
      active: pathname === "/upgrade",
    },
  ]

  return (
    <div className="md:hidden">
      <Sheet open={open} onOpenChange={setOpen}>
        <SheetTrigger asChild>
          <Button
            variant="ghost"
            size="icon"
            className="mr-2 px-0 text-base hover:bg-transparent focus-visible:bg-transparent focus-visible:ring-0 focus-visible:ring-offset-0"
          >
            <Menu className="h-5 w-5" />
            <span className="sr-only">Toggle Menu</span>
          </Button>
        </SheetTrigger>
        <SheetContent side="left" className="pr-0">
          <div className="px-7">
            <Link href="/" className="flex items-center">
              <span className="font-bold">obsession</span>
            </Link>
          </div>
          <div className="mt-6 px-1">
            <nav className="grid gap-2 text-lg font-medium">
              {routes.map((route) => (
                <Link
                  key={route.href}
                  href={route.href}
                  onClick={() => setOpen(false)}
                  className={cn(
                    "flex w-full items-center rounded-md px-6 py-3 hover:bg-muted",
                    route.active ? "bg-muted" : "",
                  )}
                >
                  {route.label}
                </Link>
              ))}
              <Button
                variant="ghost"
                className="flex w-full items-center rounded-md px-6 py-3 hover:bg-muted justify-start font-medium text-lg"
                onClick={handleLogout}
              >
                <LogOut className="mr-2 h-5 w-5" />
                Log out
              </Button>
            </nav>
          </div>
        </SheetContent>
      </Sheet>
    </div>
  )
}
