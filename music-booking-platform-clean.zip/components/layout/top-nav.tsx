"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { usePathname, useRouter } from "next/navigation"
import Image from "next/image"
import { ChevronLeft, User, LogOut, MessageSquare } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { useAuth } from "@/contexts/auth-context"

export function TopNav() {
  const pathname = usePathname()
  const router = useRouter()
  const { user, profile, isAuthenticated, signOut } = useAuth()
  const [mounted, setMounted] = useState(false)

  // Set mounted to true on client side
  useEffect(() => {
    setMounted(true)
  }, [])

  // Get user's initials for avatar fallback
  const getInitials = () => {
    if (profile?.full_name) {
      return profile.full_name
        .split(" ")
        .map((name) => name[0])
        .join("")
        .toUpperCase()
        .substring(0, 2)
    }
    return user?.email?.substring(0, 2).toUpperCase() || "U"
  }

  // Handle logout
  const handleLogout = async () => {
    await signOut()
    router.push("/auth/login")
  }

  // Handle profile click
  const handleProfileClick = () => {
    router.push("/artist/profile")
  }

  // Determine if we should show the back button
  const showBackButton =
    mounted && isAuthenticated && pathname !== "/artist" && pathname !== "/promoter" && pathname !== "/dashboard"

  // Determine where the logo should link to
  const logoLinkDestination =
    mounted && isAuthenticated
      ? profile?.role === "artist"
        ? "/artist"
        : profile?.role === "promoter"
          ? "/promoter"
          : "/dashboard"
      : "/"

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center gap-4">
          <Link href={logoLinkDestination} className="flex items-center">
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Logo%20Obsession%20white-gt2eyG7QbbKZZry2usxMftMZcMl7Pr.png"
              alt="Obsession Logo"
              width={150}
              height={40}
              className="h-8 w-auto"
            />
          </Link>

          {showBackButton && (
            <Button
              variant="ghost"
              size="sm"
              className="gap-1 hidden sm:flex"
              onClick={() => {
                if (profile?.role === "artist") {
                  router.push("/artist")
                } else if (profile?.role === "promoter") {
                  router.push("/promoter")
                } else {
                  router.push("/dashboard")
                }
              }}
            >
              <ChevronLeft className="h-4 w-4" />
              Back to Dashboard
            </Button>
          )}
        </div>

        {mounted && isAuthenticated && (
          <div className="flex items-center gap-4">
            <Link href="/upgrade" className="hidden sm:block">
              <Button variant="outline" size="sm">
                Upgrade
              </Button>
            </Link>

            <Link href="/messages" className="hidden sm:flex">
              <Button variant="ghost" size="icon" className="relative">
                <MessageSquare className="h-5 w-5" />
                {/* Notification indicator - show when there are unread messages */}
                <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-red-500 text-[10px] text-white">
                  {/* This will be replaced with actual unread count */}
                </span>
              </Button>
            </Link>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="rounded-full" onClick={(e) => e.preventDefault()}>
                  <Avatar className="h-8 w-8">
                    <AvatarImage src={profile?.avatar_url || ""} alt={profile?.full_name || "User"} />
                    <AvatarFallback>{getInitials()}</AvatarFallback>
                  </Avatar>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <div className="flex items-center justify-start gap-2 p-2">
                  <div className="flex flex-col space-y-1 leading-none">
                    {profile?.full_name && <p className="font-medium">{profile.full_name}</p>}
                    {user?.email && <p className="text-sm text-muted-foreground">{user.email}</p>}
                  </div>
                </div>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleProfileClick}>
                  <User className="mr-2 h-4 w-4" />
                  <span>Profile</span>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/upgrade">
                    <span className="flex w-full items-center sm:hidden">
                      <svg className="mr-2 h-4 w-4" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path
                          d="M16 16V8H8V16H16Z"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        />
                        <path
                          d="M12 20V16"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        />
                        <path
                          d="M12 8V4"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        />
                        <path
                          d="M16 12H20"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        />
                        <path
                          d="M4 12H8"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        />
                      </svg>
                      Upgrade
                    </span>
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleLogout}>
                  <LogOut className="mr-2 h-4 w-4" />
                  <span>Log out</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        )}

        {mounted && !isAuthenticated && (
          <div className="flex items-center gap-2">
            <Link href="/auth/login">
              <Button variant="ghost" size="sm">
                Log in
              </Button>
            </Link>
            <Link href="/auth/register">
              <Button size="sm">Sign up</Button>
            </Link>
          </div>
        )}
      </div>

      {/* Mobile back button */}
      {showBackButton && (
        <div className="sm:hidden px-4 py-2 border-t">
          <Button
            variant="ghost"
            size="sm"
            className="gap-1 w-full justify-start"
            onClick={() => {
              if (profile?.role === "artist") {
                router.push("/artist")
              } else if (profile?.role === "promoter") {
                router.push("/promoter")
              } else {
                router.push("/dashboard")
              }
            }}
          >
            <ChevronLeft className="h-4 w-4" />
            Back to Dashboard
          </Button>
        </div>
      )}
    </header>
  )
}
