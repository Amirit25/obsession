"use client"

import type React from "react"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { useAuth } from "@/contexts/auth-context"
import {
  BarChart3,
  Calendar,
  Home,
  Music2,
  Settings,
  User,
  Users,
  Headphones,
  Ticket,
  MessageSquare,
} from "lucide-react"

interface SidebarProps extends React.HTMLAttributes<HTMLDivElement> {}

export function Sidebar({ className, ...props }: SidebarProps) {
  const pathname = usePathname()
  const { profile } = useAuth()

  const isArtist = profile?.role === "artist"
  const isPromoter = profile?.role === "promoter"

  const routes = [
    {
      label: "Dashboard",
      icon: Home,
      href: isArtist ? "/artist" : isPromoter ? "/promoter" : "/dashboard",
      active: pathname === "/artist" || pathname === "/promoter" || pathname === "/dashboard",
    },
    {
      label: "Analytics",
      icon: BarChart3,
      href: "/analytics",
      active: pathname === "/analytics",
    },
    {
      label: "Bookings",
      icon: Calendar,
      href: "/bookings",
      active: pathname === "/bookings",
    },
    {
      label: "Profile",
      icon: User,
      href: "/profile",
      active: pathname === "/profile",
    },
    ...(isArtist
      ? [
          {
            label: "Artist Profile",
            icon: Music2,
            href: "/artist/profile",
            active: pathname === "/artist/profile",
          },
        ]
      : []),
    ...(isPromoter
      ? [
          {
            label: "Create Gig",
            icon: Ticket,
            href: "/promoter/create-gig",
            active: pathname === "/promoter/create-gig",
          },
        ]
      : []),
    {
      label: "Connections",
      icon: Headphones,
      href: "/connections",
      active: pathname === "/connections",
    },
    {
      label: "Messages",
      icon: MessageSquare,
      href: "/messages",
      active: pathname === "/messages" || pathname.startsWith("/messages/"),
    },
    {
      label: "Resources",
      icon: Users,
      href: "/resources",
      active: pathname === "/resources",
    },
    {
      label: "Settings",
      icon: Settings,
      href: "/settings",
      active: pathname === "/settings",
    },
  ]

  return (
    <div className={cn("pb-12 w-64 border-r bg-background", className)} {...props}>
      <div className="space-y-4 py-4">
        <div className="px-4 py-2">
          <Link href="/" className="flex items-center">
            <span className="text-xl font-bold">obsession</span>
          </Link>
        </div>
        <div className="px-3">
          <ScrollArea className="h-[calc(100vh-8rem)]">
            <div className="space-y-1">
              {routes.map((route) => (
                <Link key={route.href} href={route.href}>
                  <Button
                    variant={route.active ? "secondary" : "ghost"}
                    className={cn("w-full justify-start", route.active ? "bg-secondary" : "")}
                  >
                    <route.icon className="mr-2 h-4 w-4" />
                    {route.label}
                  </Button>
                </Link>
              ))}
            </div>
            <div className="mt-6">
              <Link href="/upgrade">
                <Button className="w-full" variant="outline">
                  Upgrade to Pro
                </Button>
              </Link>
            </div>
          </ScrollArea>
        </div>
      </div>
    </div>
  )
}
