"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { usePathname } from "next/navigation"
import { useAuth } from "@/contexts/auth-context"
import { MobileNav } from "./mobile-nav"
import { Sidebar } from "./sidebar"

export function DashboardLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname()
  const { isAuthenticated, isLoading } = useAuth()
  const [mounted, setMounted] = useState(false)

  // Set mounted to true on client side
  useEffect(() => {
    setMounted(true)
  }, [])

  // Check if we're on an auth page
  const isAuthPage = pathname?.startsWith("/auth") || pathname === "/"

  // Don't render sidebar for auth pages or if not authenticated
  if (!mounted || isLoading || isAuthPage || !isAuthenticated) {
    return <>{children}</>
  }

  return (
    <div className="flex min-h-screen flex-col">
      <div className="flex flex-1">
        <Sidebar className="hidden md:flex" />
        <main className="flex-1">
          <div className="flex items-center md:hidden">
            <MobileNav />
          </div>
          <div className="container py-6">{children}</div>
        </main>
      </div>
    </div>
  )
}
