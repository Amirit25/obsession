import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { AlertTriangle, CheckCircle, Shield, Activity } from "lucide-react"

interface AdminSectionProps {
  profileData: any
}

export function AdminSection({ profileData }: AdminSectionProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <Shield className="mr-2 h-5 w-5" />
          Admin Controls
        </CardTitle>
        <CardDescription>Advanced settings and controls for administrators</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="users">
          <TabsList className="mb-4">
            <TabsTrigger value="users">User Management</TabsTrigger>
            <TabsTrigger value="platform">Platform Settings</TabsTrigger>
            <TabsTrigger value="reports">Reports</TabsTrigger>
          </TabsList>

          <TabsContent value="users">
            <div className="space-y-4">
              <div className="flex items-center justify-between space-x-2">
                <div className="flex flex-col space-y-1">
                  <Label htmlFor="verify-users" className="font-medium">
                    Auto-Verify New Users
                  </Label>
                  <p className="text-sm text-muted-foreground">
                    Automatically verify new user accounts upon registration
                  </p>
                </div>
                <Switch id="verify-users" defaultChecked />
              </div>

              <div className="flex items-center justify-between space-x-2">
                <div className="flex flex-col space-y-1">
                  <Label htmlFor="manual-approval" className="font-medium">
                    Manual Artist Approval
                  </Label>
                  <p className="text-sm text-muted-foreground">Require manual approval for artist profiles</p>
                </div>
                <Switch id="manual-approval" defaultChecked />
              </div>

              <div className="flex items-center justify-between space-x-2">
                <div className="flex flex-col space-y-1">
                  <Label htmlFor="restrict-signups" className="font-medium">
                    Restrict New Signups
                  </Label>
                  <p className="text-sm text-muted-foreground">Temporarily disable new user registrations</p>
                </div>
                <Switch id="restrict-signups" />
              </div>

              <div className="mt-6">
                <h3 className="text-sm font-medium mb-3">Pending Approvals</h3>
                <div className="rounded-md border">
                  <div className="p-4 flex justify-between items-center">
                    <div>
                      <p className="font-medium">John Doe</p>
                      <p className="text-sm text-muted-foreground">Artist Profile - Submitted 2 days ago</p>
                    </div>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm">
                        Reject
                      </Button>
                      <Button size="sm">Approve</Button>
                    </div>
                  </div>
                  <div className="border-t p-4 flex justify-between items-center">
                    <div>
                      <p className="font-medium">Jane Smith</p>
                      <p className="text-sm text-muted-foreground">Promoter Profile - Submitted 1 day ago</p>
                    </div>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm">
                        Reject
                      </Button>
                      <Button size="sm">Approve</Button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="platform">
            <div className="space-y-4">
              <div className="flex items-center justify-between space-x-2">
                <div className="flex flex-col space-y-1">
                  <Label htmlFor="maintenance-mode" className="font-medium">
                    Maintenance Mode
                  </Label>
                  <p className="text-sm text-muted-foreground">Put the platform in maintenance mode</p>
                </div>
                <Switch id="maintenance-mode" />
              </div>

              <div className="flex items-center justify-between space-x-2">
                <div className="flex flex-col space-y-1">
                  <Label htmlFor="feature-flags" className="font-medium">
                    Enable Beta Features
                  </Label>
                  <p className="text-sm text-muted-foreground">Enable upcoming beta features for all users</p>
                </div>
                <Switch id="feature-flags" />
              </div>

              <div className="mt-6">
                <h3 className="text-sm font-medium mb-3">System Status</h3>
                <div className="space-y-2">
                  <div className="flex items-center justify-between p-3 bg-green-50 dark:bg-green-900/20 rounded-md">
                    <div className="flex items-center">
                      <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                      <span>API Services</span>
                    </div>
                    <Badge className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100">
                      Operational
                    </Badge>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-green-50 dark:bg-green-900/20 rounded-md">
                    <div className="flex items-center">
                      <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                      <span>Database</span>
                    </div>
                    <Badge className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100">
                      Operational
                    </Badge>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-yellow-50 dark:bg-yellow-900/20 rounded-md">
                    <div className="flex items-center">
                      <AlertTriangle className="h-5 w-5 text-yellow-500 mr-2" />
                      <span>Storage Services</span>
                    </div>
                    <Badge className="bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-100">
                      Degraded
                    </Badge>
                  </div>
                </div>
              </div>

              <div className="mt-6 flex justify-end gap-2">
                <Button variant="outline">Reset Cache</Button>
                <Button>Update System</Button>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="reports">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-medium">Reported Content</h3>
                <Badge variant="outline" className="ml-2">
                  3 New
                </Badge>
              </div>

              <div className="rounded-md border">
                <div className="p-4 border-b">
                  <div className="flex justify-between items-start">
                    <div>
                      <div className="flex items-center">
                        <Badge variant="destructive" className="mr-2">
                          Review
                        </Badge>
                        <p className="font-medium">Inappropriate Content</p>
                      </div>
                      <p className="text-sm text-muted-foreground mt-1">Reported 2 hours ago</p>
                      <p className="mt-2 text-sm">"This review contains offensive language and personal attacks..."</p>
                    </div>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm">
                        Dismiss
                      </Button>
                      <Button variant="destructive" size="sm">
                        Remove
                      </Button>
                    </div>
                  </div>
                </div>

                <div className="p-4 border-b">
                  <div className="flex justify-between items-start">
                    <div>
                      <div className="flex items-center">
                        <Badge variant="destructive" className="mr-2">
                          Profile
                        </Badge>
                        <p className="font-medium">Misleading Information</p>
                      </div>
                      <p className="text-sm text-muted-foreground mt-1">Reported 1 day ago</p>
                      <p className="mt-2 text-sm">
                        "This profile contains false credentials and misleading information..."
                      </p>
                    </div>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm">
                        Dismiss
                      </Button>
                      <Button variant="destructive" size="sm">
                        Flag Account
                      </Button>
                    </div>
                  </div>
                </div>

                <div className="p-4">
                  <div className="flex justify-between items-start">
                    <div>
                      <div className="flex items-center">
                        <Badge variant="destructive" className="mr-2">
                          Listing
                        </Badge>
                        <p className="font-medium">Fraudulent Listing</p>
                      </div>
                      <p className="text-sm text-muted-foreground mt-1">Reported 3 days ago</p>
                      <p className="mt-2 text-sm">
                        "This gig listing appears to be fraudulent and is asking for upfront payments..."
                      </p>
                    </div>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm">
                        Dismiss
                      </Button>
                      <Button variant="destructive" size="sm">
                        Remove
                      </Button>
                    </div>
                  </div>
                </div>
              </div>

              <div className="mt-6 flex justify-end">
                <Button>
                  <Activity className="mr-2 h-4 w-4" />
                  View All Reports
                </Button>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}
