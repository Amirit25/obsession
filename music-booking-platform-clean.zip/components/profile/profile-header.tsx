import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Edit, Share2 } from "lucide-react"
import Link from "next/link"

interface ProfileHeaderProps {
  name: string
  role: string
  avatarUrl: string
  email: string
}

export function ProfileHeader({ name, role, avatarUrl, email }: ProfileHeaderProps) {
  const getRoleBadgeColor = (role: string) => {
    switch (role) {
      case "artist":
        return "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300"
      case "promoter":
        return "bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-300"
      case "admin":
        return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300"
    }
  }

  const getPublicProfileLink = () => {
    if (role === "artist") {
      return "/artist/profile"
    } else if (role === "promoter") {
      return "/promoter/profile"
    }
    return "#"
  }

  const getEditProfileLink = () => {
    if (role === "artist") {
      return "/artist/profile/edit"
    } else if (role === "promoter") {
      return "/promoter/profile/edit"
    }
    return "/profile/edit"
  }

  return (
    <div className="flex flex-col md:flex-row items-center md:items-start gap-6">
      <Avatar className="h-24 w-24">
        <AvatarImage src={avatarUrl || "/placeholder.svg?height=96&width=96"} alt={name} />
        <AvatarFallback>{name.charAt(0)}</AvatarFallback>
      </Avatar>

      <div className="space-y-2 text-center md:text-left">
        <div className="flex flex-col md:flex-row md:items-center gap-2">
          <h1 className="text-2xl font-bold">{name}</h1>
          <Badge className={`${getRoleBadgeColor(role)} capitalize`}>{role}</Badge>
        </div>

        <p className="text-muted-foreground">{email}</p>

        <div className="flex flex-wrap gap-2 justify-center md:justify-start">
          <Button variant="outline" size="sm" asChild>
            <Link href={getEditProfileLink()}>
              <Edit className="mr-2 h-4 w-4" />
              Edit Profile
            </Link>
          </Button>

          {(role === "artist" || role === "promoter") && (
            <Button variant="outline" size="sm" asChild>
              <Link href={getPublicProfileLink()}>
                <Share2 className="mr-2 h-4 w-4" />
                View Public Profile
              </Link>
            </Button>
          )}
        </div>
      </div>
    </div>
  )
}
