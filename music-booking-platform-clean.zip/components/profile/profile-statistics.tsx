import type React from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { BarChart, LineChart } from "@/components/charts"
import { Eye, Calendar, Music, Users, Star, TrendingUp } from "lucide-react"

interface ProfileStatisticsProps {
  statistics: any
  userRole: string
}

export function ProfileStatistics({ statistics, userRole }: ProfileStatisticsProps) {
  // Default statistics if none are provided
  const stats = {
    profile_views: statistics?.profile_views || 0,
    booking_requests: statistics?.booking_requests || 0,
    confirmed_bookings: statistics?.confirmed_bookings || 0,
    gigs_posted: statistics?.gigs_posted || 0,
    applications_received: statistics?.applications_received || 0,
    average_rating: statistics?.average_rating || 0,
    total_reviews: statistics?.total_reviews || 0,
    ...statistics,
  }

  // Mock data for charts
  const viewsData = [
    { name: "Jan", total: 125 },
    { name: "Feb", total: 156 },
    { name: "Mar", total: 218 },
    { name: "Apr", total: 289 },
    { name: "May", total: 345 },
    { name: "Jun", total: 412 },
    { name: "Jul", total: 478 },
    { name: "Aug", total: 523 },
    { name: "Sep", total: 589 },
    { name: "Oct", total: 645 },
    { name: "Nov", total: 678 },
    { name: "Dec", total: 712 },
  ]

  const bookingsData = [
    { name: "Jan", total: 5 },
    { name: "Feb", total: 8 },
    { name: "Mar", total: 12 },
    { name: "Apr", total: 15 },
    { name: "May", total: 18 },
    { name: "Jun", total: 22 },
    { name: "Jul", total: 25 },
    { name: "Aug", total: 28 },
    { name: "Sep", total: 32 },
    { name: "Oct", total: 35 },
    { name: "Nov", total: 38 },
    { name: "Dec", total: 42 },
  ]

  const ratingsData = [
    { name: "Jan", total: 4.2 },
    { name: "Feb", total: 4.3 },
    { name: "Mar", total: 4.1 },
    { name: "Apr", total: 4.4 },
    { name: "May", total: 4.5 },
    { name: "Jun", total: 4.6 },
    { name: "Jul", total: 4.7 },
    { name: "Aug", total: 4.8 },
    { name: "Sep", total: 4.7 },
    { name: "Oct", total: 4.8 },
    { name: "Nov", total: 4.9 },
    { name: "Dec", total: 4.9 },
  ]

  return (
    <Card>
      <CardHeader>
        <CardTitle>Profile Statistics</CardTitle>
        <CardDescription>View your profile performance and analytics</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <StatCard
            title="Profile Views"
            value={stats.profile_views}
            icon={<Eye className="h-4 w-4 text-muted-foreground" />}
            description="Total profile views"
          />

          {userRole === "artist" ? (
            <>
              <StatCard
                title="Booking Requests"
                value={stats.booking_requests}
                icon={<Calendar className="h-4 w-4 text-muted-foreground" />}
                description="Total booking requests received"
              />
              <StatCard
                title="Confirmed Bookings"
                value={stats.confirmed_bookings}
                icon={<Music className="h-4 w-4 text-muted-foreground" />}
                description="Successfully confirmed bookings"
              />
            </>
          ) : userRole === "promoter" ? (
            <>
              <StatCard
                title="Gigs Posted"
                value={stats.gigs_posted}
                icon={<Calendar className="h-4 w-4 text-muted-foreground" />}
                description="Total gigs you've posted"
              />
              <StatCard
                title="Applications"
                value={stats.applications_received}
                icon={<Users className="h-4 w-4 text-muted-foreground" />}
                description="Applications received"
              />
            </>
          ) : (
            <>
              <StatCard
                title="Activity"
                value={stats.activity || 0}
                icon={<TrendingUp className="h-4 w-4 text-muted-foreground" />}
                description="Recent platform activity"
              />
              <StatCard
                title="Connections"
                value={stats.connections || 0}
                icon={<Users className="h-4 w-4 text-muted-foreground" />}
                description="Total platform connections"
              />
            </>
          )}
        </div>

        <Tabs defaultValue="views">
          <TabsList className="mb-4">
            <TabsTrigger value="views">Profile Views</TabsTrigger>
            <TabsTrigger value="bookings">
              {userRole === "artist" ? "Bookings" : userRole === "promoter" ? "Gigs" : "Activity"}
            </TabsTrigger>
            {userRole === "artist" && <TabsTrigger value="ratings">Ratings</TabsTrigger>}
          </TabsList>

          <TabsContent value="views">
            <div className="h-[300px]">
              <LineChart
                data={viewsData}
                title="Profile Views Over Time"
                description="Monthly profile view statistics"
              />
            </div>
          </TabsContent>

          <TabsContent value="bookings">
            <div className="h-[300px]">
              <BarChart
                data={bookingsData}
                title={userRole === "artist" ? "Bookings Over Time" : "Gigs Over Time"}
                description={userRole === "artist" ? "Monthly booking statistics" : "Monthly gig statistics"}
              />
            </div>
          </TabsContent>

          {userRole === "artist" && (
            <TabsContent value="ratings">
              <div className="h-[300px]">
                <LineChart data={ratingsData} title="Rating Trends" description="Monthly average rating" />
              </div>
              <div className="mt-4 flex items-center justify-center">
                <div className="text-center">
                  <div className="flex items-center justify-center">
                    <Star className="h-6 w-6 text-yellow-400 fill-yellow-400" />
                    <span className="text-2xl font-bold ml-2">{stats.average_rating.toFixed(1)}</span>
                  </div>
                  <p className="text-sm text-muted-foreground mt-1">
                    Average rating from {stats.total_reviews} reviews
                  </p>
                </div>
              </div>
            </TabsContent>
          )}
        </Tabs>
      </CardContent>
    </Card>
  )
}

function StatCard({
  title,
  value,
  icon,
  description,
}: { title: string; value: number; icon: React.ReactNode; description: string }) {
  return (
    <div className="rounded-lg border bg-card text-card-foreground shadow-sm p-6">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-medium">{title}</h3>
        {icon}
      </div>
      <div className="mt-2">
        <p className="text-3xl font-bold">{value.toLocaleString()}</p>
        <p className="text-xs text-muted-foreground mt-1">{description}</p>
      </div>
    </div>
  )
}
