"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Calendar, Check, Clock, X, MessageSquare, ExternalLink } from "lucide-react"
import Link from "next/link"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { updateBookingStatus } from "@/app/actions/booking-actions"
import { useToast } from "@/hooks/use-toast"

interface BookingHistoryProps {
  bookings: any[]
  userRole: string
}

export function BookingHistory({ bookings, userRole }: BookingHistoryProps) {
  const [localBookings, setLocalBookings] = useState(bookings)
  const [isUpdating, setIsUpdating] = useState<string | null>(null)
  const { toast } = useToast()

  // Filter bookings by status
  const pendingBookings = localBookings.filter((booking) => booking.status === "pending")
  const upcomingBookings = localBookings.filter(
    (booking) => booking.status === "accepted" && new Date(booking.event_date) > new Date(),
  )
  const pastBookings = localBookings.filter(
    (booking) =>
      (booking.status === "accepted" && new Date(booking.event_date) <= new Date()) || booking.status === "completed",
  )
  const cancelledBookings = localBookings.filter(
    (booking) => booking.status === "rejected" || booking.status === "cancelled",
  )

  // Determine if the user is the artist or the requester for each booking
  const isArtist = (booking: any) => {
    if (userRole === "artist") {
      return booking.artist?.profile_id === booking.artist_id
    }
    return false
  }

  const handleUpdateStatus = async (id: string, status: "accepted" | "rejected" | "cancelled" | "completed") => {
    setIsUpdating(id)

    try {
      const result = await updateBookingStatus(id, status)

      if (result.error) {
        throw new Error(result.error)
      }

      toast({
        title: "Status Updated",
        description: `Booking has been ${status}`,
      })

      // Update the local state
      setLocalBookings(localBookings.map((booking) => (booking.id === id ? { ...booking, status } : booking)))
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to update booking status",
        variant: "destructive",
      })
    } finally {
      setIsUpdating(null)
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return (
          <Badge variant="outline" className="flex items-center">
            <Clock className="mr-1 h-3 w-3" />
            Pending
          </Badge>
        )
      case "accepted":
        return (
          <Badge className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100 flex items-center">
            <Check className="mr-1 h-3 w-3" />
            Accepted
          </Badge>
        )
      case "completed":
        return (
          <Badge className="bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-100 flex items-center">
            <Check className="mr-1 h-3 w-3" />
            Completed
          </Badge>
        )
      case "rejected":
        return (
          <Badge variant="destructive" className="flex items-center">
            <X className="mr-1 h-3 w-3" />
            Rejected
          </Badge>
        )
      case "cancelled":
        return (
          <Badge variant="destructive" className="flex items-center">
            <X className="mr-1 h-3 w-3" />
            Cancelled
          </Badge>
        )
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  const renderBookingCard = (booking: any) => {
    const isPending = booking.status === "pending"
    const isAccepted = booking.status === "accepted"
    const isUserArtist = isArtist(booking)

    return (
      <Card key={booking.id} className="mb-4">
        <CardHeader className="pb-2">
          <div className="flex justify-between items-start">
            <div>
              <CardTitle>{booking.event_name}</CardTitle>
              <CardDescription>
                {new Date(booking.event_date).toLocaleDateString("en-US", {
                  weekday: "long",
                  year: "numeric",
                  month: "long",
                  day: "numeric",
                })}
              </CardDescription>
            </div>
            {getStatusBadge(booking.status)}
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Location</p>
                <p>{booking.event_location}</p>
                {booking.event_venue && <p className="text-sm">{booking.event_venue}</p>}
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground">{isUserArtist ? "Requested by" : "Artist"}</p>
                <div className="flex items-center gap-2">
                  <Avatar className="h-6 w-6">
                    <AvatarImage
                      src={
                        isUserArtist
                          ? booking.requester?.avatar_url || "/placeholder.svg?height=24&width=24"
                          : booking.artist?.profiles?.avatar_url || "/placeholder.svg?height=24&width=24"
                      }
                      alt="Profile"
                    />
                    <AvatarFallback>
                      {isUserArtist
                        ? booking.requester?.full_name?.charAt(0) || "U"
                        : booking.artist?.profiles?.full_name?.charAt(0) || "A"}
                    </AvatarFallback>
                  </Avatar>
                  <p>
                    {isUserArtist
                      ? booking.requester?.full_name || "Unknown"
                      : booking.artist?.artist_name || booking.artist?.profiles?.full_name || "Unknown"}
                  </p>
                </div>
              </div>
            </div>

            {booking.event_description && (
              <div>
                <p className="text-sm font-medium text-muted-foreground">Description</p>
                <p className="text-sm">{booking.event_description}</p>
              </div>
            )}

            {booking.budget && (
              <div>
                <p className="text-sm font-medium text-muted-foreground">Budget</p>
                <p>{booking.budget}</p>
              </div>
            )}

            <div className="flex justify-end space-x-2">
              {isPending && isUserArtist && (
                <>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleUpdateStatus(booking.id, "rejected")}
                    disabled={isUpdating === booking.id}
                  >
                    <X className="mr-2 h-4 w-4" />
                    Decline
                  </Button>
                  <Button
                    variant="default"
                    size="sm"
                    onClick={() => handleUpdateStatus(booking.id, "accepted")}
                    disabled={isUpdating === booking.id}
                  >
                    <Check className="mr-2 h-4 w-4" />
                    Accept
                  </Button>
                </>
              )}

              {isPending && !isUserArtist && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleUpdateStatus(booking.id, "cancelled")}
                  disabled={isUpdating === booking.id}
                >
                  <X className="mr-2 h-4 w-4" />
                  Cancel Request
                </Button>
              )}

              {isAccepted && (
                <>
                  <Button variant="outline" size="sm" asChild>
                    <Link href={`/messages?booking=${booking.id}`}>
                      <MessageSquare className="mr-2 h-4 w-4" />
                      Message
                    </Link>
                  </Button>

                  {new Date(booking.event_date) <= new Date() && (
                    <Button
                      variant="default"
                      size="sm"
                      onClick={() => handleUpdateStatus(booking.id, "completed")}
                      disabled={isUpdating === booking.id || booking.status === "completed"}
                    >
                      <Check className="mr-2 h-4 w-4" />
                      Mark as Completed
                    </Button>
                  )}
                </>
              )}

              <Button variant="outline" size="sm" asChild>
                <Link href={`/bookings/${booking.id}`}>
                  <ExternalLink className="mr-2 h-4 w-4" />
                  View Details
                </Link>
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Booking History</CardTitle>
        <CardDescription>View and manage your booking requests</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="pending">
          <TabsList className="mb-4">
            <TabsTrigger value="pending">
              Pending
              {pendingBookings.length > 0 && (
                <Badge variant="secondary" className="ml-2">
                  {pendingBookings.length}
                </Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="upcoming">
              Upcoming
              {upcomingBookings.length > 0 && (
                <Badge variant="secondary" className="ml-2">
                  {upcomingBookings.length}
                </Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="past">Past</TabsTrigger>
            <TabsTrigger value="cancelled">Cancelled</TabsTrigger>
          </TabsList>

          <TabsContent value="pending">
            {pendingBookings.length === 0 ? (
              <div className="text-center py-8">
                <Calendar className="mx-auto h-12 w-12 text-muted-foreground opacity-50" />
                <h3 className="mt-4 text-lg font-medium">No pending bookings</h3>
                <p className="mt-2 text-sm text-muted-foreground">
                  You don't have any pending booking requests at the moment.
                </p>
              </div>
            ) : (
              <div>{pendingBookings.map(renderBookingCard)}</div>
            )}
          </TabsContent>

          <TabsContent value="upcoming">
            {upcomingBookings.length === 0 ? (
              <div className="text-center py-8">
                <Calendar className="mx-auto h-12 w-12 text-muted-foreground opacity-50" />
                <h3 className="mt-4 text-lg font-medium">No upcoming bookings</h3>
                <p className="mt-2 text-sm text-muted-foreground">
                  You don't have any upcoming bookings at the moment.
                </p>
              </div>
            ) : (
              <div>{upcomingBookings.map(renderBookingCard)}</div>
            )}
          </TabsContent>

          <TabsContent value="past">
            {pastBookings.length === 0 ? (
              <div className="text-center py-8">
                <Calendar className="mx-auto h-12 w-12 text-muted-foreground opacity-50" />
                <h3 className="mt-4 text-lg font-medium">No past bookings</h3>
                <p className="mt-2 text-sm text-muted-foreground">You don't have any past bookings yet.</p>
              </div>
            ) : (
              <div>{pastBookings.map(renderBookingCard)}</div>
            )}
          </TabsContent>

          <TabsContent value="cancelled">
            {cancelledBookings.length === 0 ? (
              <div className="text-center py-8">
                <Calendar className="mx-auto h-12 w-12 text-muted-foreground opacity-50" />
                <h3 className="mt-4 text-lg font-medium">No cancelled bookings</h3>
                <p className="mt-2 text-sm text-muted-foreground">You don't have any cancelled or rejected bookings.</p>
              </div>
            ) : (
              <div>{cancelledBookings.map(renderBookingCard)}</div>
            )}
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}
