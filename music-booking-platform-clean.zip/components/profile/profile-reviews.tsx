"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Star, ThumbsUp, Flag, MessageSquare } from "lucide-react"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/hooks/use-toast"
import { replyToReview, reportReview } from "@/app/actions/profile-actions"

interface ProfileReviewsProps {
  reviews: any[]
  userRole: string
}

export function ProfileReviews({ reviews, userRole }: ProfileReviewsProps) {
  const [expandedReviews, setExpandedReviews] = useState<string[]>([])
  const [replyText, setReplyText] = useState<Record<string, string>>({})
  const [isSubmitting, setIsSubmitting] = useState<string | null>(null)
  const { toast } = useToast()

  const toggleExpand = (reviewId: string) => {
    setExpandedReviews((prev) => (prev.includes(reviewId) ? prev.filter((id) => id !== reviewId) : [...prev, reviewId]))
  }

  const handleReplyChange = (reviewId: string, text: string) => {
    setReplyText((prev) => ({ ...prev, [reviewId]: text }))
  }

  const handleReplySubmit = async (reviewId: string) => {
    if (!replyText[reviewId]?.trim()) return

    setIsSubmitting(reviewId)

    try {
      const result = await replyToReview({
        reviewId,
        replyText: replyText[reviewId],
      })

      if (result.error) {
        throw new Error(result.error)
      }

      toast({
        title: "Reply Submitted",
        description: "Your reply has been posted successfully.",
      })

      // Clear the reply text
      setReplyText((prev) => ({ ...prev, [reviewId]: "" }))
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to submit reply. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(null)
    }
  }

  const handleReportReview = async (reviewId: string) => {
    try {
      const result = await reportReview({
        reviewId,
      })

      if (result.error) {
        throw new Error(result.error)
      }

      toast({
        title: "Review Reported",
        description: "This review has been reported to our moderation team.",
      })
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to report review. Please try again.",
        variant: "destructive",
      })
    }
  }

  // If user is not an artist, show a message
  if (userRole !== "artist" && reviews.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Reviews</CardTitle>
          <CardDescription>Reviews are only available for artist profiles</CardDescription>
        </CardHeader>
        <CardContent className="text-center py-8">
          <MessageSquare className="mx-auto h-12 w-12 text-muted-foreground opacity-50" />
          <h3 className="mt-4 text-lg font-medium">No reviews available</h3>
          <p className="mt-2 text-sm text-muted-foreground">Reviews are only displayed for artist profiles.</p>
        </CardContent>
      </Card>
    )
  }

  // If user is an artist but has no reviews
  if (userRole === "artist" && reviews.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Reviews</CardTitle>
          <CardDescription>See what others are saying about you</CardDescription>
        </CardHeader>
        <CardContent className="text-center py-8">
          <Star className="mx-auto h-12 w-12 text-muted-foreground opacity-50" />
          <h3 className="mt-4 text-lg font-medium">No reviews yet</h3>
          <p className="mt-2 text-sm text-muted-foreground">
            You haven't received any reviews yet. Reviews will appear here after you complete bookings.
          </p>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Reviews</CardTitle>
        <CardDescription>See what others are saying about you</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {reviews.map((review) => (
            <div key={review.id} className="border-b pb-6 last:border-0 last:pb-0">
              <div className="flex justify-between items-start">
                <div className="flex items-start gap-3">
                  <Avatar className="h-10 w-10">
                    <AvatarImage
                      src={review.reviewer?.avatar_url || "/placeholder.svg?height=40&width=40"}
                      alt={review.reviewer?.full_name || "Reviewer"}
                    />
                    <AvatarFallback>{review.reviewer?.full_name?.charAt(0) || "R"}</AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="flex items-center">
                      <h4 className="font-medium">{review.reviewer?.full_name || "Anonymous"}</h4>
                      <span className="text-xs text-muted-foreground ml-2">
                        {new Date(review.created_at).toLocaleDateString("en-US", {
                          year: "numeric",
                          month: "short",
                          day: "numeric",
                        })}
                      </span>
                    </div>
                    <div className="flex mt-1">
                      {Array.from({ length: 5 }).map((_, i) => (
                        <Star
                          key={i}
                          className={`h-4 w-4 ${
                            i < review.rating ? "text-yellow-400 fill-yellow-400" : "text-gray-300"
                          }`}
                        />
                      ))}
                    </div>
                    <p className="mt-2">{review.content}</p>

                    {review.event_name && (
                      <p className="text-xs text-muted-foreground mt-1">For event: {review.event_name}</p>
                    )}

                    {review.reply && (
                      <div className="mt-3 pl-4 border-l-2 border-gray-200 dark:border-gray-700">
                        <div className="flex items-center">
                          <span className="font-medium">Your reply</span>
                          <span className="text-xs text-muted-foreground ml-2">
                            {new Date(review.reply_date).toLocaleDateString("en-US", {
                              year: "numeric",
                              month: "short",
                              day: "numeric",
                            })}
                          </span>
                        </div>
                        <p className="mt-1 text-sm">{review.reply}</p>
                      </div>
                    )}
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button variant="ghost" size="icon" onClick={() => handleReportReview(review.id)}>
                    <Flag className="h-4 w-4" />
                    <span className="sr-only">Report</span>
                  </Button>
                  <Button variant="ghost" size="icon">
                    <ThumbsUp className="h-4 w-4" />
                    <span className="sr-only">Helpful</span>
                  </Button>
                </div>
              </div>

              {!review.reply && (
                <div className="mt-4">
                  <Button variant="outline" size="sm" onClick={() => toggleExpand(review.id)}>
                    {expandedReviews.includes(review.id) ? "Cancel Reply" : "Reply"}
                  </Button>

                  {expandedReviews.includes(review.id) && (
                    <div className="mt-3">
                      <Textarea
                        placeholder="Write your reply..."
                        value={replyText[review.id] || ""}
                        onChange={(e) => handleReplyChange(review.id, e.target.value)}
                        className="min-h-[100px]"
                      />
                      <div className="mt-2 flex justify-end">
                        <Button
                          size="sm"
                          onClick={() => handleReplySubmit(review.id)}
                          disabled={!replyText[review.id]?.trim() || isSubmitting === review.id}
                        >
                          {isSubmitting === review.id ? "Submitting..." : "Submit Reply"}
                        </Button>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
