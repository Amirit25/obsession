"use client"

import { useEffect, useRef } from "react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import type { Message } from "@/types/messaging"
import { format } from "date-fns"
import { useAuth } from "@/contexts/auth-context"

interface MessageListProps {
  messages: Message[]
}

export function MessageList({ messages }: MessageListProps) {
  const { user } = useAuth()
  const endOfMessagesRef = useRef<HTMLDivElement>(null)

  // Scroll to bottom when messages change
  useEffect(() => {
    if (endOfMessagesRef.current) {
      endOfMessagesRef.current.scrollIntoView({ behavior: "smooth" })
    }
  }, [messages])

  if (messages.length === 0) {
    return (
      <div className="flex-1 flex items-center justify-center p-4">
        <p className="text-muted-foreground">No messages yet. Start the conversation!</p>
      </div>
    )
  }

  // Group messages by date
  const messagesByDate: { [date: string]: Message[] } = {}

  messages.forEach((message) => {
    const date = format(new Date(message.created_at), "MMMM d, yyyy")
    if (!messagesByDate[date]) {
      messagesByDate[date] = []
    }
    messagesByDate[date].push(message)
  })

  return (
    <div className="flex-1 overflow-y-auto p-4 space-y-6">
      {Object.entries(messagesByDate).map(([date, dateMessages]) => (
        <div key={date} className="space-y-4">
          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t"></div>
            </div>
            <div className="relative flex justify-center">
              <span className="bg-background px-2 text-xs text-muted-foreground">{date}</span>
            </div>
          </div>

          {dateMessages.map((message) => {
            const isCurrentUser = message.sender_id === user?.id

            return (
              <div key={message.id} className={`flex items-start gap-2 ${isCurrentUser ? "flex-row-reverse" : ""}`}>
                <Avatar className="h-8 w-8 mt-0.5">
                  <AvatarImage src={message.sender?.avatar_url || undefined} />
                  <AvatarFallback>{message.sender?.full_name.charAt(0) || "?"}</AvatarFallback>
                </Avatar>

                <div className={`max-w-[75%] ${isCurrentUser ? "items-end" : "items-start"}`}>
                  <div
                    className={`px-4 py-2 rounded-lg ${
                      isCurrentUser ? "bg-primary text-primary-foreground" : "bg-muted"
                    }`}
                  >
                    <p className="text-sm">{message.content}</p>
                  </div>
                  <span className="text-xs text-muted-foreground mt-1">
                    {format(new Date(message.created_at), "h:mm a")}
                  </span>
                </div>
              </div>
            )
          })}
        </div>
      ))}

      <div ref={endOfMessagesRef} />
    </div>
  )
}
