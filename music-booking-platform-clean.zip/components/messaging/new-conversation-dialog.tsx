"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { createConversation } from "@/app/actions/messaging-actions"
import { useToast } from "@/hooks/use-toast"
import { MessageSquarePlus } from "lucide-react"
import { useSupabaseQuery } from "@/hooks/use-supabase-query"

export function NewConversationDialog() {
  const [open, setOpen] = useState(false)
  const [recipientId, setRecipientId] = useState("")
  const [message, setMessage] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const router = useRouter()
  const { toast } = useToast()

  // Fetch potential recipients (all users except current user)
  const { data: recipients, isLoading } = useSupabaseQuery<any[]>({
    table: "profiles",
    columns: "id, full_name, role, avatar_url",
    orderBy: { column: "full_name" },
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!recipientId || !message.trim()) {
      toast({
        title: "Missing information",
        description: "Please select a recipient and enter a message",
        variant: "destructive",
      })
      return
    }

    try {
      setIsSubmitting(true)
      const result = await createConversation({
        recipient_id: recipientId,
        initial_message: message.trim(),
      })

      if (result.error) {
        toast({
          title: "Error creating conversation",
          description: result.error,
          variant: "destructive",
        })
      } else {
        toast({
          title: "Conversation started",
          description: "Your message has been sent",
        })
        setOpen(false)
        router.push(`/messages/${result.data.id}`)
      }
    } catch (error) {
      toast({
        title: "Error creating conversation",
        description: "Please try again later",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="gap-2">
          <MessageSquarePlus className="h-4 w-4" />
          New Message
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>New Conversation</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4 mt-4">
          <div className="space-y-2">
            <Label htmlFor="recipient">Recipient</Label>
            <select
              id="recipient"
              value={recipientId}
              onChange={(e) => setRecipientId(e.target.value)}
              className="w-full rounded-md border border-input bg-background px-3 py-2"
              required
            >
              <option value="">Select a recipient</option>
              {recipients?.map((recipient) => (
                <option key={recipient.id} value={recipient.id}>
                  {recipient.full_name} ({recipient.role})
                </option>
              ))}
            </select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="message">Message</Label>
            <Textarea
              id="message"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Type your message..."
              required
              className="min-h-[100px]"
            />
          </div>

          <div className="flex justify-end gap-2">
            <Button type="button" variant="outline" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting ? "Sending..." : "Send Message"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  )
}
