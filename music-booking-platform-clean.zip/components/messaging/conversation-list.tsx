"use client"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Input } from "@/components/ui/input"
import type { Conversation } from "@/types/messaging"
import { formatDistanceToNow } from "date-fns"
import { Search } from "lucide-react"
import { Badge } from "@/components/ui/badge"

interface ConversationListProps {
  conversations: Conversation[]
}

export function ConversationList({ conversations }: ConversationListProps) {
  const pathname = usePathname()
  const [searchQuery, setSearchQuery] = useState("")

  // Filter conversations based on search query
  const filteredConversations = conversations.filter((conversation) => {
    const otherParticipant = conversation.participants.find((p) =>
      p.profile.full_name.toLowerCase().includes(searchQuery.toLowerCase()),
    )
    return otherParticipant !== undefined
  })

  return (
    <div className="h-full flex flex-col border-r">
      <div className="p-4 border-b">
        <h2 className="text-xl font-semibold mb-4">Messages</h2>
        <div className="relative">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Search conversations..."
            className="pl-8"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </div>

      <div className="flex-1 overflow-auto">
        {filteredConversations.length === 0 ? (
          <div className="p-4 text-center text-muted-foreground">
            {searchQuery ? "No conversations match your search" : "No conversations yet"}
          </div>
        ) : (
          <ul className="divide-y">
            {filteredConversations.map((conversation) => {
              // Find the other participant (not the current user)
              const otherParticipant = conversation.participants[0]

              // Format the date
              const lastMessageTime = conversation.lastMessage?.created_at || conversation.updated_at
              const timeAgo = formatDistanceToNow(new Date(lastMessageTime), { addSuffix: true })

              // Check if this conversation is active
              const isActive = pathname === `/messages/${conversation.id}`

              return (
                <li key={conversation.id}>
                  <Link href={`/messages/${conversation.id}`}>
                    <div className={`flex items-start p-4 gap-3 hover:bg-muted/50 ${isActive ? "bg-muted" : ""}`}>
                      <Avatar className="h-10 w-10">
                        <AvatarImage src={otherParticipant.profile.avatar_url || undefined} />
                        <AvatarFallback>{otherParticipant.profile.full_name.charAt(0)}</AvatarFallback>
                      </Avatar>

                      <div className="flex-1 min-w-0">
                        <div className="flex justify-between items-start">
                          <h3 className="font-medium truncate">{otherParticipant.profile.full_name}</h3>
                          <span className="text-xs text-muted-foreground whitespace-nowrap ml-2">{timeAgo}</span>
                        </div>

                        <div className="flex items-center justify-between mt-1">
                          <p className="text-sm text-muted-foreground truncate">
                            {conversation.lastMessage?.content || "No messages yet"}
                          </p>

                          {conversation.unreadCount && conversation.unreadCount > 0 ? (
                            <Badge variant="default" className="ml-2">
                              {conversation.unreadCount}
                            </Badge>
                          ) : null}
                        </div>
                      </div>
                    </div>
                  </Link>
                </li>
              )
            })}
          </ul>
        )}
      </div>
    </div>
  )
}
